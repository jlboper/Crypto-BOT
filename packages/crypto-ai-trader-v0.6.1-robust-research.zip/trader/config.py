from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _load_env_file(path: Path) -> None:
    if not path.is_file():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def load_environment() -> None:
    candidates = [
        PROJECT_ROOT / ".env.local",
        PROJECT_ROOT / ".env",
        PROJECT_ROOT.parent / ".env.local",
        PROJECT_ROOT.parent / ".env",
        Path.cwd() / ".env.local",
        Path.cwd() / ".env",
    ]
    seen: set[Path] = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved not in seen:
            seen.add(resolved)
            _load_env_file(resolved)


@dataclass(frozen=True)
class BotSettings:
    mode: str
    cycle_seconds: int
    timeframe: str
    universe_size: int
    max_parallel_requests: int
    database_path: Path
    kill_switch_path: Path


@dataclass(frozen=True)
class PaperSettings:
    initial_cash_usdt: float
    fee_rate: float
    slippage_rate: float


@dataclass(frozen=True)
class RiskSettings:
    max_positions: int
    max_position_pct: float
    max_total_exposure_pct: float
    risk_per_trade_pct: float
    daily_loss_limit_pct: float
    weekly_loss_limit_pct: float
    stop_atr_multiple: float
    minimum_stop_pct: float
    reward_to_risk: float
    trailing_atr_multiple: float
    max_consecutive_errors: int


@dataclass(frozen=True)
class StrategySettings:
    minimum_score: int
    ema_fast: int
    ema_slow: int
    rsi_period: int
    atr_period: int
    breakout_period: int
    volume_period: int


@dataclass(frozen=True)
class AISettings:
    enabled: bool
    model: str
    max_reviews_per_cycle: int
    minimum_confidence: float
    fail_closed: bool
    timeout_seconds: int


@dataclass(frozen=True)
class DashboardSettings:
    host: str
    port: int


@dataclass(frozen=True)
class ResearchSettings:
    symbols: tuple[str, ...]
    history_candles: int
    train_bars: int
    test_bars: int
    report_path: Path


@dataclass(frozen=True)
class AppConfig:
    bot: BotSettings
    paper: PaperSettings
    risk: RiskSettings
    strategy: StrategySettings
    ai: AISettings
    dashboard: DashboardSettings
    research: ResearchSettings


def _project_path(raw: str) -> Path:
    path = Path(raw)
    return path if path.is_absolute() else PROJECT_ROOT / path


def load_config(path: str | Path | None = None) -> AppConfig:
    load_environment()
    config_path = Path(path) if path else PROJECT_ROOT / "config.toml"
    with config_path.open("rb") as handle:
        raw = tomllib.load(handle)

    bot = raw["bot"]
    paper = raw["paper"]
    risk = raw["risk"]
    strategy = raw["strategy"]
    ai = raw["ai"]
    dashboard = raw["dashboard"]
    research = raw.get("research", {})

    mode = str(bot.get("mode", "paper")).lower()
    if mode != "paper":
        raise ValueError("Phase 1 is locked to paper mode. Testnet/live execution is not enabled yet.")

    return AppConfig(
        bot=BotSettings(
            mode=mode,
            cycle_seconds=int(bot["cycle_seconds"]),
            timeframe=str(bot["timeframe"]),
            universe_size=int(bot["universe_size"]),
            max_parallel_requests=int(bot["max_parallel_requests"]),
            database_path=_project_path(str(bot["database_path"])),
            kill_switch_path=_project_path(str(bot["kill_switch_path"])),
        ),
        paper=PaperSettings(**paper),
        risk=RiskSettings(**risk),
        strategy=StrategySettings(**strategy),
        ai=AISettings(
            enabled=bool(ai["enabled"]),
            model=os.getenv("OPENAI_MODEL", str(ai["model"])),
            max_reviews_per_cycle=int(ai["max_reviews_per_cycle"]),
            minimum_confidence=float(ai["minimum_confidence"]),
            fail_closed=bool(ai["fail_closed"]),
            timeout_seconds=int(ai["timeout_seconds"]),
        ),
        dashboard=DashboardSettings(host=str(dashboard["host"]), port=int(dashboard["port"])),
        research=ResearchSettings(
            symbols=tuple(str(symbol).upper() for symbol in research.get(
                "symbols", ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"]
            )),
            history_candles=int(research.get("history_candles", 5000)),
            train_bars=int(research.get("train_bars", 1200)),
            test_bars=int(research.get("test_bars", 400)),
            report_path=_project_path(str(research.get("report_path", "data/research/latest.json"))),
        ),
    )
