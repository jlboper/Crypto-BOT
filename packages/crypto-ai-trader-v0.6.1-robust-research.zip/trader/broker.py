from __future__ import annotations

from datetime import UTC, datetime

from .config import PaperSettings, RiskSettings
from .database import Database
from .domain import Position, Signal


class PaperBroker:
    def __init__(self, database: Database, settings: PaperSettings, risk: RiskSettings) -> None:
        self.db = database
        self.settings = settings
        self.risk = risk
        self.db.initialize_cash(settings.initial_cash_usdt)

    def equity(self, prices: dict[str, float]) -> tuple[float, float, float]:
        cash = self.db.cash()
        exposure = sum(position.quantity * prices.get(position.symbol, position.entry_price) for position in self.db.positions())
        return cash + exposure, cash, exposure

    def buy(self, signal: Signal, quantity: float, reason: str) -> Position:
        if self.db.position(signal.symbol):
            raise ValueError(f"position already exists for {signal.symbol}")
        fill_price = signal.price * (1.0 + self.settings.slippage_rate)
        gross = fill_price * quantity
        fee = gross * self.settings.fee_rate
        cash = self.db.cash()
        if gross + fee > cash:
            raise ValueError("insufficient paper cash")
        if signal.stop_price is None or signal.take_profit is None:
            raise ValueError("buy signal has no protection levels")
        position = Position(
            symbol=signal.symbol,
            quantity=quantity,
            entry_price=fill_price,
            stop_price=signal.stop_price,
            take_profit=signal.take_profit,
            high_water=fill_price,
            atr=signal.atr,
            entry_fee=fee,
            opened_at=datetime.now(UTC).isoformat(),
        )
        self.db.set_cash(cash - gross - fee)
        self.db.upsert_position(position)
        self.db.record_trade(signal.symbol, "BUY", quantity, fill_price, fee, 0.0, reason)
        return position

    def sell(self, position: Position, market_price: float, reason: str) -> float:
        fill_price = market_price * (1.0 - self.settings.slippage_rate)
        gross = fill_price * position.quantity
        fee = gross * self.settings.fee_rate
        pnl = (fill_price - position.entry_price) * position.quantity - position.entry_fee - fee
        self.db.set_cash(self.db.cash() + gross - fee)
        self.db.delete_position(position.symbol)
        self.db.record_trade(position.symbol, "SELL", position.quantity, fill_price, fee, pnl, reason)
        return pnl

    def protect(self, position: Position, price: float, atr_value: float) -> tuple[Position | None, str | None]:
        if price <= position.stop_price:
            self.sell(position, price, "protective stop")
            return None, "protective stop"
        if price >= position.take_profit:
            self.sell(position, price, "take profit")
            return None, "take profit"
        high_water = max(position.high_water, price)
        initial_risk = max(position.entry_price - position.stop_price, 0.0)
        stop_price = position.stop_price
        if initial_risk > 0 and price >= position.entry_price + initial_risk:
            stop_price = max(stop_price, position.entry_price, high_water - self.risk.trailing_atr_multiple * atr_value)
        updated = Position(
            symbol=position.symbol,
            quantity=position.quantity,
            entry_price=position.entry_price,
            stop_price=stop_price,
            take_profit=position.take_profit,
            high_water=high_water,
            atr=atr_value,
            entry_fee=position.entry_fee,
            opened_at=position.opened_at,
        )
        self.db.upsert_position(updated)
        return updated, None

