from __future__ import annotations

import math
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import UTC, datetime, timedelta

from .ai_advisor import AIAdvisor
from .broker import PaperBroker
from .config import AppConfig
from .database import Database
from .domain import Candle, Signal
from .exchange import BinanceClient
from .indicators import atr
from .strategy import SwingStrategy


class TradingEngine:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.db = Database(config.bot.database_path)
        self.exchange = BinanceClient()
        self.strategy = SwingStrategy(config.strategy, config.risk)
        self.broker = PaperBroker(self.db, config.paper, config.risk)
        self.ai = AIAdvisor(config.ai)
        self._errors = 0

    def killed(self) -> bool:
        return self.config.bot.kill_switch_path.exists()

    def cycle(self) -> dict:
        try:
            symbols = self.exchange.top_usdt_symbols(self.config.bot.universe_size)
            held_symbols = [position.symbol for position in self.db.positions()]
            monitored_symbols = list(dict.fromkeys([*symbols, *held_symbols, "BTCUSDT"]))
            candle_map = self._fetch_candles(monitored_symbols)
            if "BTCUSDT" not in candle_map:
                raise RuntimeError("BTC regime data unavailable")
            btc_bullish = self.strategy.btc_regime(candle_map["BTCUSDT"])

            closed_prices = {symbol: candles[-1].close for symbol, candles in candle_map.items() if candles}
            try:
                prices = {**closed_prices, **self.exchange.latest_prices(set(monitored_symbols))}
            except Exception as exc:
                prices = closed_prices
                self.db.event("WARN", f"Live prices unavailable; using closed candles: {type(exc).__name__}")
            self.db.record_market_snapshot(prices)
            self._manage_positions(candle_map, prices)
            positions = self.db.positions()
            equity, cash, exposure = self.broker.equity(prices)
            if self.killed():
                self.db.record_equity(equity, cash, exposure)
                self.db.event("WARN", "Kill switch active: protections monitored, new entries blocked")
                self._errors = 0
                return {"status": "killed", "equity": equity, "cash": cash, "exposure": exposure}
            if self._risk_halt(equity):
                self.db.record_equity(equity, cash, exposure)
                return {"status": "risk_halt", "equity": equity}

            held = {position.symbol for position in positions}
            candidates: list[Signal] = []
            for symbol, candles in candle_map.items():
                if symbol in held:
                    continue
                signal = self.strategy.evaluate(symbol, candles, btc_bullish)
                if signal.action == "BUY" or signal.score >= self.config.strategy.minimum_score - 10:
                    self.db.record_signal(signal)
                if signal.action == "BUY":
                    candidates.append(signal)
            candidates.sort(key=lambda signal: signal.score, reverse=True)

            reviews = 0
            opened: list[str] = []
            for signal in candidates:
                positions = self.db.positions()
                equity, cash, exposure = self.broker.equity(prices)
                if len(positions) >= self.config.risk.max_positions:
                    break
                if equity <= 0 or exposure / equity >= self.config.risk.max_total_exposure_pct:
                    break
                if reviews >= self.config.ai.max_reviews_per_cycle:
                    break
                context = {
                    "equity_usdt": round(equity, 4),
                    "cash_usdt": round(cash, 4),
                    "exposure_pct": round(exposure / equity if equity else 0.0, 6),
                    "open_positions": float(len(positions)),
                }
                review = self.ai.review(signal, btc_bullish, context)
                reviews += 1
                self.db.record_ai_review(signal.symbol, review)
                if review.verdict == "REJECT" or review.risk_multiplier <= 0:
                    continue
                quantity = self._position_size(signal, equity, cash, exposure, review.risk_multiplier)
                if quantity <= 0:
                    continue
                self.broker.buy(signal, quantity, f"score={signal.score}; AI={review.verdict}: {review.reason}")
                opened.append(signal.symbol)

            equity, cash, exposure = self.broker.equity(prices)
            self.db.record_equity(equity, cash, exposure)
            self.db.event("INFO", f"Cycle complete: {len(symbols)} symbols, {len(candidates)} buys, opened {len(opened)}")
            self._errors = 0
            return {
                "status": "ok",
                "symbols": len(symbols),
                "buy_candidates": len(candidates),
                "opened": opened,
                "equity": equity,
                "cash": cash,
                "exposure": exposure,
                "btc_bullish": btc_bullish,
            }
        except Exception as exc:
            self._errors += 1
            self.db.event("ERROR", f"Cycle failed: {type(exc).__name__}: {exc}")
            if self._errors >= self.config.risk.max_consecutive_errors:
                self.config.bot.kill_switch_path.parent.mkdir(parents=True, exist_ok=True)
                self.config.bot.kill_switch_path.write_text("automatic halt after consecutive errors\n", encoding="utf-8")
                self.db.event("CRITICAL", "Kill switch activated after consecutive errors")
            raise

    def _fetch_candles(self, symbols: list[str]) -> dict[str, list[Candle]]:
        result: dict[str, list[Candle]] = {}
        with ThreadPoolExecutor(max_workers=self.config.bot.max_parallel_requests) as pool:
            futures = {
                pool.submit(self.exchange.candles, symbol, self.config.bot.timeframe, 250): symbol for symbol in symbols
            }
            for future in as_completed(futures):
                symbol = futures[future]
                try:
                    candles = future.result()
                    if len(candles) >= self.config.strategy.ema_slow + 5:
                        result[symbol] = candles
                except Exception as exc:
                    self.db.event("WARN", f"{symbol} data skipped: {type(exc).__name__}")
        return result

    def _manage_positions(self, candle_map: dict[str, list[Candle]], prices: dict[str, float]) -> None:
        for position in self.db.positions():
            candles = candle_map.get(position.symbol)
            if not candles:
                continue
            price = prices.get(position.symbol, candles[-1].close)
            current_atr = atr(
                [candle.high for candle in candles],
                [candle.low for candle in candles],
                [candle.close for candle in candles],
                self.config.strategy.atr_period,
            )
            updated, exit_reason = self.broker.protect(position, price, current_atr)
            if updated is None:
                self.db.event("INFO", f"{position.symbol} closed: {exit_reason}")
                continue
            should_exit, reason = self.strategy.should_exit(candles)
            if should_exit:
                self.broker.sell(updated, price, reason)

    def _position_size(self, signal: Signal, equity: float, cash: float, exposure: float, multiplier: float) -> float:
        if signal.stop_price is None or signal.price <= signal.stop_price:
            return 0.0
        risk_budget = equity * self.config.risk.risk_per_trade_pct * multiplier
        by_risk = risk_budget / (signal.price - signal.stop_price)
        by_position_cap = (equity * self.config.risk.max_position_pct) / signal.price
        remaining_exposure = max(0.0, equity * self.config.risk.max_total_exposure_pct - exposure)
        by_exposure = remaining_exposure / signal.price
        by_cash = (cash / (1.0 + self.config.paper.fee_rate + self.config.paper.slippage_rate)) / signal.price
        quantity = min(by_risk, by_position_cap, by_exposure, by_cash)
        return math.floor(quantity * 1_000_000) / 1_000_000

    def _risk_halt(self, equity: float) -> bool:
        now = datetime.now(UTC)
        day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_start = day_start - timedelta(days=day_start.weekday())
        day_base = self.db.first_equity_since(day_start.isoformat()) or equity
        week_base = self.db.first_equity_since(week_start.isoformat()) or equity
        daily_return = (equity / day_base - 1.0) if day_base else 0.0
        weekly_return = (equity / week_base - 1.0) if week_base else 0.0
        if daily_return <= -self.config.risk.daily_loss_limit_pct:
            self.db.event("CRITICAL", f"Daily loss limit reached: {daily_return:.2%}")
            return True
        if weekly_return <= -self.config.risk.weekly_loss_limit_pct:
            self.db.event("CRITICAL", f"Weekly loss limit reached: {weekly_return:.2%}")
            return True
        return False

    def run_forever(self) -> None:
        self.db.event("INFO", "Trading engine started in PAPER mode")
        while True:
            started = time.monotonic()
            try:
                self.cycle()
            except KeyboardInterrupt:
                raise
            except Exception:
                pass
            elapsed = time.monotonic() - started
            time.sleep(max(1.0, self.config.bot.cycle_seconds - elapsed))
