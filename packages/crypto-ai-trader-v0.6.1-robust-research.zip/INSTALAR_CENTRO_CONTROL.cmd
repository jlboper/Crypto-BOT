@echo off
setlocal
set "TARGET=%USERPROFILE%\Desktop\crypto-ai-trading-bot"

if not exist "%TARGET%\config.toml" (
  echo No se encontro la instalacion en:
  echo %TARGET%
  echo.
  echo Abre PowerShell en la carpeta del bot y usa el procedimiento manual del README.
  pause
  exit /b 1
)

if not exist "%TARGET%\scripts" mkdir "%TARGET%\scripts"
copy /Y "%~dp0scripts\update_windows.ps1" "%TARGET%\scripts\update_windows.ps1" >nul
copy /Y "%~dp0scripts\manager_windows.ps1" "%TARGET%\scripts\manager_windows.ps1" >nul
copy /Y "%~dp0ACTUALIZAR_BOT.cmd" "%TARGET%\ACTUALIZAR_BOT.cmd" >nul
copy /Y "%~dp0Crypto AI Trader.vbs" "%TARGET%\Crypto AI Trader.vbs" >nul

echo Centro de Control preparado.
echo Selecciona ahora el ZIP que descargaste y confirma la instalacion.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TARGET%\scripts\update_windows.ps1"

if errorlevel 1 (
  echo.
  echo La instalacion no termino correctamente.
  pause
  exit /b 1
)

echo.
echo Instalacion completada. Abriendo Crypto AI Trader...
wscript.exe "%TARGET%\Crypto AI Trader.vbs"
timeout /t 3 /nobreak >nul
endlocal
