# Crypto AI Trading Bot — Binance Spot

Bot de capital para swing trading de varios días/semanas, **sin apalancamiento** y **solo en simulación**. Consume precios reales de Binance Spot, crea señales cuantitativas y utiliza OpenAI como una segunda barrera de riesgo. La versión 0.6 incorpora un laboratorio independiente para comparar activos y estrategias sin modificar el motor operativo.

La IA no puede inventar compras, aumentar el tamaño de una posición, eliminar stops ni cambiar límites. Únicamente puede `ALLOW`, `REJECT` o `REDUCE` una entrada que ya pasó las reglas cuantitativas.

## Límites iniciales

- Capital simulado: 1,000 USDT.
- Máximo 5 posiciones.
- Máximo 15% por posición y 60% de exposición total.
- Riesgo objetivo: 0.75% del portafolio por operación.
- Detención diaria: −2%; semanal: −5%.
- Stops por ATR, objetivo 2R y trailing stop después de alcanzar 1R.
- Sin futuros, margen, cortos ni promedio de pérdidas.
- Kill switch manual y automático después de tres errores consecutivos. Bloquea entradas nuevas, pero el motor continúa vigilando stops y salidas de posiciones existentes.

Todos estos valores están en `config.toml`.

## Requisitos

- Windows 10/11 o Linux.
- Python 3.11 o superior.
- Conexión estable a internet.
- No requiere instalar paquetes de Python: usa únicamente la biblioteca estándar.

## Inicio rápido en Windows

1. Descomprime el proyecto.
2. Abre PowerShell dentro de la carpeta.
3. Coloca `OPENAI_API_KEY` en `.env.local`. No compartas ese archivo ni lo subas a Git.
4. Ejecuta:

```powershell
.\scripts\start_windows.ps1
```

5. Abre `http://127.0.0.1:8765`.

La clave creada durante esta sesión está guardada de forma segura en el entorno actual; no se incluye dentro del ZIP. Para instalar el bot en otra PC, configura allí la credencial mediante un canal seguro.

## Inicio rápido en Linux

```bash
chmod +x scripts/start_linux.sh
./scripts/start_linux.sh
```

## Comandos útiles

```bash
# Ejecutar un solo ciclo
python -m trader once

# Motor continuo + dashboard
python -m trader run

# Solo dashboard
python -m trader dashboard

# Estado local
python -m trader status

# Backtest conservador con hasta 10,000 velas cerradas de Binance
python -m trader backtest BTCUSDT --limit 2000

# Research Lab: BTC, ETH, SOL, BNB y XRP
python -m trader research

# Emergencia / reanudación
python -m trader kill
python -m trader resume

# Verificar credenciales Binance Spot Testnet sin operar
python -m trader check-testnet
```

## Binance Testnet (preparado, no activado)

`BINANCE_API_KEY` y `BINANCE_API_SECRET` pueden añadirse a `.env.local`. El comando `check-testnet` consulta la cuenta de Testnet y no envía órdenes. La activación de órdenes se hará solo después de validar backtests y varias semanas de paper trading.

Las claves de Binance deben pertenecer a una subcuenta separada, permitir únicamente lectura/trading, tener retiros desactivados y estar restringidas a la IP fija del servidor.

## Qué hace cada ciclo

1. Selecciona los pares USDT con mayor volumen y excluye stablecoins y tokens apalancados.
2. Descarga únicamente velas cerradas de 4 horas.
3. Calcula EMA 20/50, RSI 14, ATR 14, volumen, momentum y breakout de 20 velas.
4. Penaliza nuevas entradas cuando el régimen de BTC es bajista.
5. Revisa stops, objetivos y trailing stops de posiciones existentes.
6. Envía como máximo tres candidatos a la IA.
7. Dimensiona cada entrada según la distancia al stop y los límites globales.
8. Registra señales, revisiones, operaciones y equity en SQLite.

## Monitorización remota

La versión 0.2 añade:

- Semáforo del motor basado en la hora real del último ciclo exitoso.
- Estados `OPERATIVO`, `RETRASADO` y `SIN ACTIVIDAD`.
- Precio spot, valor de mercado y P&L no realizado estimado de cada posición.
- Vigilancia de posiciones abiertas aunque salgan temporalmente del top de volumen.
- Stops y objetivos evaluados contra el precio spot más reciente disponible, mientras las señales técnicas continúan usando velas cerradas.
- Panel de errores y advertencias recientes.
- `/health` devuelve HTTP 200 cuando el ciclo está al día y HTTP 503 cuando falta actividad.

El dashboard continúa escuchando exclusivamente en localhost. Para acceso remoto usa una VPN privada como Tailscale Serve; no abras el puerto 8765 en el router.

## Research Lab v0.6

El portal incluye un laboratorio multi-cripto para `BTCUSDT`, `ETHUSDT`, `SOLUSDT`, `BNBUSDT` y `XRPUSDT`. Por cada activo compara cinco familias: tendencia base, momentum rápido, tendencia conservadora, pullback en tendencia y reversión a la media.

Cada ejecución descarga hasta 5,000 velas cerradas por activo y aplica:

- Señal al cierre y ejecución en la apertura de la vela siguiente, evitando anticipación de datos.
- Comisión y slippage en entradas y salidas.
- Stops y objetivos intravela; cuando el orden es ambiguo, supone primero el stop.
- Walk-forward rodante con selección en entrenamiento y evaluación fuera de muestra.
- Ranking ajustado por Sharpe, Calmar, drawdown, exceso frente a buy-and-hold, rotación y número de operaciones.
- Heurística de sobreajuste basada en el rango fuera de muestra de la estrategia seleccionada.
- 1,000 simulaciones Monte Carlo de las operaciones fuera de muestra.
- Auditoría de duplicados y huecos en las velas.
- Separación de resultados en regímenes alcistas, laterales y bajistas.
- Backtest conjunto del portafolio y matriz de correlaciones entre activos.
- Sensibilidad del candidato ante cambios pequeños del umbral de entrada.

El cálculo se ejecuta en un proceso independiente para no bloquear el motor ni el portal. Pulsa una fila del informe para ver el diagnóstico del activo o utiliza `Exportar CSV` para conservar el resumen.

Los resultados son `RESEARCH_ONLY`: ni el ganador ni sus parámetros se transfieren al motor automáticamente. Un candidato debe revisarse y superar validaciones adicionales antes de entrar siquiera a paper trading. Consulta `RESEARCH_METHODOLOGY.md` para límites y criterios.

El portal es instalable desde Edge/Chrome como aplicación web y conserva una vista básica sin conexión. Las APIs de trading nunca se guardan en caché. El acceso remoto recomendado continúa siendo Tailscale, de modo que el portal no se publica en Internet.

## Actualizaciones automáticas asistidas en Windows

Desde la versión 0.5, el Centro de Control consulta el canal estable al abrirse y cada seis horas. Cuando existe una versión nueva, el botón cambia a `Actualizar a vX.Y.Z`. Al pulsarlo:

1. Muestra las novedades y solicita confirmación.
2. Descarga el paquete exclusivamente por HTTPS desde el canal configurado.
3. Comprueba origen, tamaño y huella SHA-256.
4. Crea un respaldo, instala, ejecuta las pruebas y reinicia el motor.

Las actualizaciones nunca se instalan silenciosamente. Si la conexión o la validación fallan, el bot continúa con la versión existente.

`ACTUALIZAR_BOT.cmd` y `Instalar actualización local...` en el menú del indicador permanecen disponibles para recuperación manual. El actualizador preserva `data`, `.env.local` y `config.toml`; si algo falla después de comenzar la instalación, restaura el código anterior.

## Centro de control de Windows

Haz doble clic en `Crypto AI Trader.vbs` para abrir una aplicación gráfica sin consola. Desde allí puedes comprobar el estado, equity, rendimiento, efectivo, exposición, posiciones y último ciclo; abrir el portal local o remoto; reiniciar el motor; activar/reanudar el kill switch; configurar el inicio automático y buscar actualizaciones. Al minimizar o cerrar la ventana, el indicador continúa en el área de notificaciones de Windows y cambia de color según el estado del motor: verde operativo, amarillo retrasado o iniciando y rojo detenido o sin actividad. `ACTUALIZAR_BOT.cmd` permanece disponible como alternativa de recuperación técnica.

## Seguridad operacional

- El dashboard escucha solo en `127.0.0.1`; no abras el puerto 8765 en el router.
- Si cambias el host para acceder remotamente, define `DASHBOARD_TOKEN` y usa una VPN privada.
- Conserva `mode = "paper"`. Esta versión rechaza cualquier otro modo deliberadamente.
- Una simulación favorable no garantiza resultados reales: existen slippage, gaps, cambios de régimen, fallas de conectividad y riesgo de contraparte del exchange.

## Pruebas locales

```bash
python -m unittest discover -s tests -v
```

La siguiente fase debe comenzar solo tras revisar resultados fuera de muestra, costos, drawdown, estabilidad por activo y comportamiento durante varias semanas en simulación.
