@echo off
setlocal
cd /d "%~dp0"
title Crypto AI Trader - Actualizador seguro
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\update_windows.ps1"
echo.
pause
endlocal
