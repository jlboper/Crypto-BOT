﻿param([switch]$Minimized)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$DashboardUrl = "http://127.0.0.1:8765"
$UpdateScript = Join-Path $PSScriptRoot "update_windows.ps1"
$KillSwitchPath = Join-Path $ProjectRoot "data\KILL_SWITCH"
$StartupFolder = [Environment]::GetFolderPath("Startup")
$StartupShortcut = Join-Path $StartupFolder "Crypto AI Trader.lnk"
$ManagerLauncher = Join-Path $ProjectRoot "Crypto AI Trader.vbs"
$OperationalIconPath = Join-Path $ProjectRoot "web\crypto-ai-trader.ico"
$WarningIconPath = Join-Path $ProjectRoot "web\crypto-ai-trader-warning.ico"
$OfflineIconPath = Join-Path $ProjectRoot "web\crypto-ai-trader-offline.ico"
$HeaderLogoPath = Join-Path $ProjectRoot "web\crypto-ai-trader-icon.png"
$UpdateManifestUrl = "https://raw.githubusercontent.com/jlboper/Crypto-BOT/main/latest.json"
$UpdateRepositoryPath = "/jlboper/Crypto-BOT/"
$UpdateCheckInterval = [TimeSpan]::FromHours(6)
$script:LastUpdateCheck = [datetime]::MinValue
$script:AvailableUpdate = $null
$script:LastAnnouncedVersion = $null

function Get-InstalledVersion {
    $projectFile = Join-Path $ProjectRoot "pyproject.toml"
    if (-not (Test-Path $projectFile)) { return "desconocida" }
    $match = Select-String -Path $projectFile -Pattern '^version\s*=\s*"([^"]+)"' | Select-Object -First 1
    if ($match) { return $match.Matches[0].Groups[1].Value }
    return "desconocida"
}

function Get-RemoteDashboardUrl {
    $tailscale = Join-Path $env:ProgramFiles "Tailscale\tailscale.exe"
    if (-not (Test-Path $tailscale)) { return $null }
    try {
        $status = (& $tailscale status --json 2>$null) | ConvertFrom-Json
        $dnsName = [string]$status.Self.DNSName
        if ($dnsName) { return "https://" + $dnsName.TrimEnd(".") + "/" }
    }
    catch { return $null }
    return $null
}

function Get-RemoteUpdate {
    $manifestUri = [uri]$UpdateManifestUrl
    if ($manifestUri.Scheme -ne "https") {
        throw "El canal de actualizaciones no usa una conexión HTTPS segura."
    }

    $manifest = Invoke-RestMethod `
        -Uri $manifestUri.AbsoluteUri `
        -Method Get `
        -UseBasicParsing `
        -TimeoutSec 10 `
        -Headers @{ "Cache-Control" = "no-cache" }

    if ([string]$manifest.app -ne "crypto-ai-trading-bot") {
        throw "El manifiesto no pertenece a Crypto AI Trader."
    }
    try {
        $remoteVersion = [version]([string]$manifest.version)
        $installedVersion = [version](Get-InstalledVersion)
    }
    catch {
        throw "El canal publicó un número de versión inválido."
    }

    $hash = ([string]$manifest.sha256).Trim().ToLowerInvariant()
    if ($hash -notmatch '^[a-f0-9]{64}$') {
        throw "La actualización no incluye una huella SHA-256 válida."
    }

    try {
        $packageUri = [uri]([string]$manifest.package_url)
    }
    catch {
        throw "La dirección del paquete de actualización no es válida."
    }
    if (-not $packageUri.IsAbsoluteUri -or $packageUri.Scheme -ne "https") {
        throw "La actualización no proviene de una dirección HTTPS absoluta."
    }
    if (
        $packageUri.Host -ne $manifestUri.Host -or
        -not $packageUri.AbsolutePath.StartsWith($UpdateRepositoryPath, [System.StringComparison]::OrdinalIgnoreCase)
    ) {
        throw "El paquete no proviene del canal oficial configurado."
    }

    if ($remoteVersion -le $installedVersion) { return $null }
    return [PSCustomObject]@{
        Version = $remoteVersion.ToString()
        PackageUrl = $packageUri.AbsoluteUri
        Sha256 = $hash
        SizeBytes = [long]$manifest.size_bytes
        Notes = @($manifest.notes | ForEach-Object { [string]$_ })
    }
}

function Update-UpdateButton {
    if ($script:AvailableUpdate) {
        $updateButton.Text = "↓   Actualizar a v" + $script:AvailableUpdate.Version
    }
    else {
        $updateButton.Text = "↻   Buscar actualizaciones"
    }
}

function Check-ForUpdates {
    param([switch]$Silent)

    $script:LastUpdateCheck = Get-Date
    try {
        $available = Get-RemoteUpdate
        $script:AvailableUpdate = $available
        Update-UpdateButton
        if ($available) {
            if ($script:LastAnnouncedVersion -ne $available.Version) {
                $script:LastAnnouncedVersion = $available.Version
                $notifyIcon.ShowBalloonTip(
                    5000,
                    "Actualización disponible",
                    "Crypto AI Trader v$($available.Version) está lista para instalar.",
                    [System.Windows.Forms.ToolTipIcon]::Info
                )
            }
            return $available
        }
        if (-not $Silent) {
            [System.Windows.Forms.MessageBox]::Show(
                "Ya tienes la versión más reciente de Crypto AI Trader.",
                "Sin actualizaciones",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
    }
    catch {
        if (-not $Silent) {
            [System.Windows.Forms.MessageBox]::Show(
                "No fue posible consultar el canal de actualizaciones.`r`n`r`n$($_.Exception.Message)`r`n`r`nEl bot continuará funcionando con la versión instalada.",
                "Actualizaciones no disponibles",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
        }
    }
    return $null
}

function Get-TradingProcesses {
    return @(
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -like "*-m trader run*" }
    )
}

function Start-TradingBot {
    if ((Get-TradingProcesses).Count -gt 0) { return }
    $launcher = (Get-Command py -ErrorAction Stop).Source
    Start-Process `
        -FilePath $launcher `
        -ArgumentList @("-3", "-m", "trader", "run") `
        -WorkingDirectory $ProjectRoot `
        -WindowStyle Hidden
}

function Stop-TradingBot {
    foreach ($process in (Get-TradingProcesses)) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

function Get-ProjectStartupShortcuts {
    $shell = New-Object -ComObject WScript.Shell
    return @(
        Get-ChildItem -LiteralPath $StartupFolder -Filter "*.lnk" -ErrorAction SilentlyContinue |
            Where-Object {
                try {
                    $shortcut = $shell.CreateShortcut($_.FullName)
                    ($shortcut.TargetPath + " " + $shortcut.Arguments) -like ("*" + $ProjectRoot + "*")
                }
                catch { $false }
            }
    )
}

function Test-CanonicalStartup {
    if (-not (Test-Path $StartupShortcut)) { return $false }
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($StartupShortcut)
        $expectedTarget = Join-Path $env:WINDIR "System32\wscript.exe"
        return (
            $shortcut.TargetPath -eq $expectedTarget -and
            $shortcut.Arguments -like ("*" + $ManagerLauncher + "*") -and
            $shortcut.Arguments -like "*/minimized*"
        )
    }
    catch { return $false }
}

function Enable-AutomaticStartup {
    foreach ($oldShortcut in (Get-ProjectStartupShortcuts)) {
        Remove-Item -LiteralPath $oldShortcut.FullName -Force -ErrorAction SilentlyContinue
    }
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($StartupShortcut)
    $shortcut.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
    $shortcut.Arguments = '"' + $ManagerLauncher + '" /minimized'
    $shortcut.WorkingDirectory = $ProjectRoot
    $shortcut.Description = "Inicia Crypto AI Trader y su indicador en segundo plano"
    $shortcut.Save()
}

function Disable-AutomaticStartup {
    foreach ($shortcut in (Get-ProjectStartupShortcuts)) {
        Remove-Item -LiteralPath $shortcut.FullName -Force -ErrorAction SilentlyContinue
    }
}

function New-AppButton {
    param(
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$Width = 330,
        [string]$Tone = "Default"
    )
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Location = New-Object System.Drawing.Point($X, $Y)
    $button.Size = New-Object System.Drawing.Size($Width, 46)
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(47, 67, 94)
    $button.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(29, 46, 72)
    $button.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(12, 24, 42)
    $button.BackColor = [System.Drawing.Color]::FromArgb(20, 33, 54)
    $button.ForeColor = [System.Drawing.Color]::FromArgb(236, 242, 255)
    if ($Tone -eq "Accent") {
        $button.BackColor = [System.Drawing.Color]::FromArgb(14, 52, 48)
        $button.ForeColor = [System.Drawing.Color]::FromArgb(77, 239, 187)
        $button.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(37, 112, 94)
    }
    elseif ($Tone -eq "Danger") {
        $button.BackColor = [System.Drawing.Color]::FromArgb(55, 24, 35)
        $button.ForeColor = [System.Drawing.Color]::FromArgb(255, 147, 164)
        $button.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(120, 48, 66)
    }
    $button.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    return $button
}

function New-KpiCard {
    param([string]$Title, [int]$X, [int]$Y)
    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location = New-Object System.Drawing.Point($X, $Y)
    $panel.Size = New-Object System.Drawing.Size(166, 106)
    $panel.BackColor = [System.Drawing.Color]::FromArgb(16, 27, 45)

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = $Title.ToUpperInvariant()
    $titleLabel.Location = New-Object System.Drawing.Point(14, 12)
    $titleLabel.Size = New-Object System.Drawing.Size(138, 18)
    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8)
    $titleLabel.ForeColor = [System.Drawing.Color]::FromArgb(124, 151, 188)
    $panel.Controls.Add($titleLabel)

    $valueLabel = New-Object System.Windows.Forms.Label
    $valueLabel.Text = "—"
    $valueLabel.Location = New-Object System.Drawing.Point(13, 36)
    $valueLabel.Size = New-Object System.Drawing.Size(143, 31)
    $valueLabel.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
    $valueLabel.ForeColor = [System.Drawing.Color]::FromArgb(240, 246, 255)
    $panel.Controls.Add($valueLabel)

    $noteLabel = New-Object System.Windows.Forms.Label
    $noteLabel.Text = "Comprobando"
    $noteLabel.Location = New-Object System.Drawing.Point(14, 76)
    $noteLabel.Size = New-Object System.Drawing.Size(138, 18)
    $noteLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $noteLabel.ForeColor = [System.Drawing.Color]::FromArgb(116, 139, 171)
    $panel.Controls.Add($noteLabel)

    return [PSCustomObject]@{ Panel = $panel; Value = $valueLabel; Note = $noteLabel }
}

function Select-LocalUpdatePackage {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = "Selecciona la actualización de Crypto AI Trader"
    $dialog.Filter = "Actualizaciones Crypto AI Trader (*.zip)|*.zip"
    $dialog.CheckFileExists = $true
    $downloads = Join-Path $env:USERPROFILE "Downloads"
    if (Test-Path $downloads) { $dialog.InitialDirectory = $downloads }
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.FileName
    }
    return $null
}

function Install-UpdatePackage {
    param(
        [Parameter(Mandatory = $true)][string]$PackagePath,
        [string]$Version = "seleccionada"
    )

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "Se instalará la versión $Version. El bot creará un respaldo, ejecutará sus pruebas y se reiniciará. ¿Continuar?",
        "Confirmar actualización",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

    $updateButton.Enabled = $false
    $statusLabel.Text = "Actualizando..."
    $statusDescription.Text = "El motor se detendrá temporalmente. No cierres esta ventana."
    $form.Refresh()
    $restartManager = $false
    try {
        $logFolder = Join-Path $ProjectRoot "data"
        New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
        $logStamp = Get-Date -Format "yyyyMMdd-HHmmss"
        $outputLog = Join-Path $logFolder ("update-" + $logStamp + ".log")
        $errorLog = Join-Path $logFolder ("update-" + $logStamp + "-error.log")
        $escapedPackage = '"' + $PackagePath + '"'
        $escapedScript = '"' + $UpdateScript + '"'
        $process = Start-Process `
            -FilePath "powershell.exe" `
            -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File $escapedScript -PackagePath $escapedPackage -SkipConfirmation" `
            -WindowStyle Hidden `
            -RedirectStandardOutput $outputLog `
            -RedirectStandardError $errorLog `
            -PassThru
        $process.WaitForExit()
        $process.Refresh()
        $updateSucceeded = $process.ExitCode -eq 0
        if (-not $updateSucceeded -and (Test-Path $outputLog)) {
            $updateSucceeded = Select-String `
                -LiteralPath $outputLog `
                -SimpleMatch "ACTUALIZACION COMPLETADA CORRECTAMENTE" `
                -Quiet
        }
        if ($updateSucceeded) {
            [System.Windows.Forms.MessageBox]::Show(
                "Actualización completada correctamente. El Centro de Control se reiniciará para cargar la versión nueva.",
                "Crypto AI Trader",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            $restartManager = $true
        }
        else {
            [System.Windows.Forms.MessageBox]::Show(
                "La actualización no se completó. El actualizador intentó restaurar la versión anterior.`r`n`r`nRegistro: $outputLog`r`nErrores: $errorLog",
                "Crypto AI Trader",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.Message,
            "Error de actualización",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    finally {
        if ($restartManager) {
            Start-Process -FilePath "wscript.exe" -ArgumentList ('"' + $ManagerLauncher + '"')
            $script:AllowExit = $true
            $form.Close()
        }
        else {
            $updateButton.Enabled = $true
            Update-UpdateButton
            Update-ManagerStatus
        }
    }
}

function Install-RemoteUpdate {
    param([Parameter(Mandatory = $true)]$Update)

    $tempFolder = Join-Path ([IO.Path]::GetTempPath()) "CryptoAITrader"
    $packagePath = Join-Path $tempFolder ("crypto-ai-trader-v" + $Update.Version + ".zip")
    try {
        New-Item -ItemType Directory -Path $tempFolder -Force | Out-Null
        $updateButton.Enabled = $false
        $updateButton.Text = "↓   Descargando v" + $Update.Version + "..."
        $statusDescription.Text = "Descargando la actualización segura. El motor continúa funcionando."
        $form.Refresh()

        Invoke-WebRequest `
            -Uri $Update.PackageUrl `
            -UseBasicParsing `
            -TimeoutSec 180 `
            -OutFile $packagePath

        if (-not (Test-Path -LiteralPath $packagePath)) {
            throw "La descarga no produjo un archivo."
        }
        $actualSize = (Get-Item -LiteralPath $packagePath).Length
        if ($Update.SizeBytes -gt 0 -and $actualSize -ne $Update.SizeBytes) {
            throw "El tamaño del paquete no coincide con el publicado."
        }
        $actualHash = (Get-FileHash -LiteralPath $packagePath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne $Update.Sha256) {
            throw "La huella SHA-256 no coincide. La instalación fue bloqueada."
        }

        Install-UpdatePackage -PackagePath $packagePath -Version $Update.Version
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "La actualización no se descargó ni se instaló.`r`n`r`n$($_.Exception.Message)`r`n`r`nEl bot continúa funcionando sin cambios.",
            "Actualización bloqueada",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
    }
    finally {
        Remove-Item -LiteralPath $packagePath -Force -ErrorAction SilentlyContinue
        if (-not $script:AllowExit) {
            $updateButton.Enabled = $true
            Update-UpdateButton
            Update-ManagerStatus
        }
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "Crypto AI Trader"
$form.Size = New-Object System.Drawing.Size(760, 680)
$form.MinimumSize = New-Object System.Drawing.Size(760, 680)
$form.MaximumSize = New-Object System.Drawing.Size(760, 680)
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$form.BackColor = [System.Drawing.Color]::FromArgb(8, 13, 24)
$form.ForeColor = [System.Drawing.Color]::FromArgb(236, 242, 255)
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$form.MaximizeBox = $false

$script:OperationalIcon = if (Test-Path $OperationalIconPath) { New-Object System.Drawing.Icon($OperationalIconPath, 16, 16) } else { [System.Drawing.SystemIcons]::Information }
$script:WarningIcon = if (Test-Path $WarningIconPath) { New-Object System.Drawing.Icon($WarningIconPath, 16, 16) } else { [System.Drawing.SystemIcons]::Warning }
$script:OfflineIcon = if (Test-Path $OfflineIconPath) { New-Object System.Drawing.Icon($OfflineIconPath, 16, 16) } else { [System.Drawing.SystemIcons]::Error }
$script:FormIcon = if (Test-Path $OperationalIconPath) { New-Object System.Drawing.Icon($OperationalIconPath, 32, 32) } else { [System.Drawing.SystemIcons]::Information }
$form.Icon = $script:FormIcon

$logo = New-Object System.Windows.Forms.PictureBox
$logo.Location = New-Object System.Drawing.Point(28, 22)
$logo.Size = New-Object System.Drawing.Size(58, 58)
$logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
if (Test-Path $HeaderLogoPath) {
    $temporaryLogo = [System.Drawing.Image]::FromFile($HeaderLogoPath)
    $script:LogoBitmap = New-Object System.Drawing.Bitmap($temporaryLogo)
    $temporaryLogo.Dispose()
}
else {
    $script:LogoBitmap = $script:FormIcon.ToBitmap()
}
$logo.Image = $script:LogoBitmap
$form.Controls.Add($logo)

$title = New-Object System.Windows.Forms.Label
$title.Text = "Crypto AI Trader"
$title.Location = New-Object System.Drawing.Point(100, 20)
$title.Size = New-Object System.Drawing.Size(470, 40)
$title.Font = New-Object System.Drawing.Font("Segoe UI", 22, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(236, 242, 255)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "Centro de control local y monitor de inversión"
$subtitle.Location = New-Object System.Drawing.Point(103, 59)
$subtitle.Size = New-Object System.Drawing.Size(460, 22)
$subtitle.ForeColor = [System.Drawing.Color]::FromArgb(132, 153, 184)
$form.Controls.Add($subtitle)

$modeBadge = New-Object System.Windows.Forms.Label
$modeBadge.Text = "PAPER"
$modeBadge.Location = New-Object System.Drawing.Point(625, 30)
$modeBadge.Size = New-Object System.Drawing.Size(91, 32)
$modeBadge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$modeBadge.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$modeBadge.BackColor = [System.Drawing.Color]::FromArgb(14, 52, 48)
$modeBadge.ForeColor = [System.Drawing.Color]::FromArgb(60, 232, 175)
$form.Controls.Add($modeBadge)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object System.Drawing.Point(28, 102)
$statusPanel.Size = New-Object System.Drawing.Size(688, 92)
$statusPanel.BackColor = [System.Drawing.Color]::FromArgb(14, 38, 42)
$form.Controls.Add($statusPanel)

$statusDot = New-Object System.Windows.Forms.Label
$statusDot.Text = "●"
$statusDot.Location = New-Object System.Drawing.Point(20, 17)
$statusDot.Size = New-Object System.Drawing.Size(24, 27)
$statusDot.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$statusDot.ForeColor = [System.Drawing.Color]::FromArgb(45, 226, 166)
$statusPanel.Controls.Add($statusDot)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "Comprobando..."
$statusLabel.Location = New-Object System.Drawing.Point(51, 15)
$statusLabel.Size = New-Object System.Drawing.Size(390, 29)
$statusLabel.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$statusPanel.Controls.Add($statusLabel)

$statusDescription = New-Object System.Windows.Forms.Label
$statusDescription.Text = "Validando el motor y el portal..."
$statusDescription.Location = New-Object System.Drawing.Point(53, 50)
$statusDescription.Size = New-Object System.Drawing.Size(390, 22)
$statusDescription.ForeColor = [System.Drawing.Color]::FromArgb(157, 181, 202)
$statusPanel.Controls.Add($statusDescription)

$lastCycleLabel = New-Object System.Windows.Forms.Label
$lastCycleLabel.Text = "ÚLTIMO CICLO`r`nComprobando..."
$lastCycleLabel.Location = New-Object System.Drawing.Point(469, 19)
$lastCycleLabel.Size = New-Object System.Drawing.Size(197, 52)
$lastCycleLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$lastCycleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lastCycleLabel.ForeColor = [System.Drawing.Color]::FromArgb(139, 169, 190)
$statusPanel.Controls.Add($lastCycleLabel)

$equityCard = New-KpiCard "Equity" 28 210
$returnCard = New-KpiCard "Rendimiento" 202 210
$cashCard = New-KpiCard "Efectivo" 376 210
$exposureCard = New-KpiCard "Exposición" 550 210
foreach ($card in @($equityCard, $returnCard, $cashCard, $exposureCard)) {
    $form.Controls.Add($card.Panel)
}

$actionsLabel = New-Object System.Windows.Forms.Label
$actionsLabel.Text = "ACCIONES RÁPIDAS"
$actionsLabel.Location = New-Object System.Drawing.Point(29, 335)
$actionsLabel.Size = New-Object System.Drawing.Size(250, 22)
$actionsLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
$actionsLabel.ForeColor = [System.Drawing.Color]::FromArgb(113, 139, 176)
$form.Controls.Add($actionsLabel)

$openLocalButton = New-AppButton "⌂   Abrir portal local" 28 365
$openLocalButton.Add_Click({ Start-Process $DashboardUrl })
$form.Controls.Add($openLocalButton)

$openRemoteButton = New-AppButton "↗   Abrir portal remoto" 386 365
$openRemoteButton.Add_Click({
    $remoteUrl = Get-RemoteDashboardUrl
    if ($remoteUrl) {
        Start-Process $remoteUrl
    }
    else {
        [System.Windows.Forms.MessageBox]::Show(
            "Tailscale no está conectado o no fue posible obtener la dirección remota.",
            "Crypto AI Trader",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
    }
})
$form.Controls.Add($openRemoteButton)

$restartButton = New-AppButton "↻   Reiniciar motor" 28 421
$restartButton.Add_Click({
    $answer = [System.Windows.Forms.MessageBox]::Show(
        "¿Quieres reiniciar el motor ahora? El portal dejará de responder durante unos segundos.",
        "Confirmar reinicio",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
        Stop-TradingBot
        Start-Sleep -Seconds 2
        Start-TradingBot
        Start-Sleep -Seconds 3
        Update-ManagerStatus
    }
})
$form.Controls.Add($restartButton)

$killButton = New-AppButton "⚠   Activar kill switch" 386 421 330 "Danger"
$killButton.Add_Click({
    if (Test-Path $KillSwitchPath) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "¿Reanudar la evaluación de nuevas operaciones?",
            "Confirmar reanudación",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
            Remove-Item -LiteralPath $KillSwitchPath -Force
        }
    }
    else {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Esto bloqueará nuevas entradas. Las posiciones existentes seguirán protegidas. ¿Continuar?",
            "Activar kill switch",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
            New-Item -ItemType Directory -Path (Split-Path $KillSwitchPath) -Force | Out-Null
            Set-Content -LiteralPath $KillSwitchPath -Value "manual kill switch from manager"
        }
    }
    Update-ManagerStatus
})
$form.Controls.Add($killButton)

$updateButton = New-AppButton "↻   Buscar actualizaciones" 28 477 330 "Accent"
$updateButton.Add_Click({
    $available = Check-ForUpdates
    if ($available) {
        $notes = if ($available.Notes.Count -gt 0) {
            "`r`n`r`nNovedades:`r`n• " + ($available.Notes -join "`r`n• ")
        }
        else { "" }
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Está disponible Crypto AI Trader v$($available.Version).$notes`r`n`r`n¿Descargarla e instalarla ahora?",
            "Actualización disponible",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
            Install-RemoteUpdate -Update $available
        }
    }
})
$form.Controls.Add($updateButton)

$startupButton = New-AppButton "⚙   Activar inicio automático" 386 477
$startupButton.Add_Click({
    if (Test-CanonicalStartup) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "¿Desactivar el inicio automático del bot y su indicador?",
            "Inicio automático",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
            Disable-AutomaticStartup
        }
    }
    else {
        Enable-AutomaticStartup
        [System.Windows.Forms.MessageBox]::Show(
            "El bot arrancará oculto después de iniciar sesión en Windows. El indicador quedará en el área de notificaciones.",
            "Inicio automático activado",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    Update-ManagerStatus
})
$form.Controls.Add($startupButton)

$footerPanel = New-Object System.Windows.Forms.Panel
$footerPanel.Location = New-Object System.Drawing.Point(28, 546)
$footerPanel.Size = New-Object System.Drawing.Size(688, 66)
$footerPanel.BackColor = [System.Drawing.Color]::FromArgb(11, 20, 34)
$form.Controls.Add($footerPanel)

$protectionLabel = New-Object System.Windows.Forms.Label
$protectionLabel.Text = "✓  Protecciones activas  ·  Simulación sin dinero real"
$protectionLabel.Location = New-Object System.Drawing.Point(16, 12)
$protectionLabel.Size = New-Object System.Drawing.Size(470, 22)
$protectionLabel.ForeColor = [System.Drawing.Color]::FromArgb(92, 215, 171)
$footerPanel.Controls.Add($protectionLabel)

$footerHint = New-Object System.Windows.Forms.Label
$footerHint.Text = "Al cerrar, el indicador continúa junto al reloj de Windows."
$footerHint.Location = New-Object System.Drawing.Point(17, 36)
$footerHint.Size = New-Object System.Drawing.Size(480, 20)
$footerHint.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$footerHint.ForeColor = [System.Drawing.Color]::FromArgb(104, 128, 158)
$footerPanel.Controls.Add($footerHint)

$versionLabel = New-Object System.Windows.Forms.Label
$versionLabel.Text = "VERSIÓN " + (Get-InstalledVersion)
$versionLabel.Location = New-Object System.Drawing.Point(520, 20)
$versionLabel.Size = New-Object System.Drawing.Size(148, 24)
$versionLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$versionLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8)
$versionLabel.ForeColor = [System.Drawing.Color]::FromArgb(113, 139, 176)
$footerPanel.Controls.Add($versionLabel)

function Update-ManagerStatus {
    $processCount = (Get-TradingProcesses).Count
    try {
        $status = Invoke-RestMethod -Uri ($DashboardUrl + "/api/status") -TimeoutSec 3
        $state = [string]$status.activity.state
        if ($state -eq "operational") {
            $statusLabel.Text = "Motor operativo"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(45, 226, 166)
            $statusDot.ForeColor = [System.Drawing.Color]::FromArgb(45, 226, 166)
            $statusPanel.BackColor = [System.Drawing.Color]::FromArgb(14, 38, 42)
            $statusDescription.Text = "Todos los servicios responden correctamente."
            $notifyIcon.Icon = $script:OperationalIcon
            $trayStatusItem.Text = "● Motor operativo"
            $trayStatusItem.ForeColor = [System.Drawing.Color]::FromArgb(45, 226, 166)
        }
        elseif ($state -eq "delayed") {
            $statusLabel.Text = "Motor retrasado"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
            $statusDot.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
            $statusPanel.BackColor = [System.Drawing.Color]::FromArgb(44, 37, 24)
            $statusDescription.Text = "El último ciclo está tardando más de lo esperado."
            $notifyIcon.Icon = $script:WarningIcon
            $trayStatusItem.Text = "● Motor retrasado"
            $trayStatusItem.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
        }
        else {
            $statusLabel.Text = "Motor sin actividad"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 93, 115)
            $statusDot.ForeColor = [System.Drawing.Color]::FromArgb(255, 93, 115)
            $statusPanel.BackColor = [System.Drawing.Color]::FromArgb(48, 25, 34)
            $statusDescription.Text = "No se registra un ciclo reciente. Revisa el motor."
            $notifyIcon.Icon = $script:OfflineIcon
            $trayStatusItem.Text = "● Motor sin actividad"
            $trayStatusItem.ForeColor = [System.Drawing.Color]::FromArgb(255, 93, 115)
        }
        $lastCycle = "sin ciclos"
        if ($status.activity.last_cycle_at) {
            $lastCycle = ([datetime]$status.activity.last_cycle_at).ToLocalTime().ToString("dd/MM/yyyy HH:mm:ss")
        }
        $equity = [math]::Round([double]$status.equity, 2)
        $returnPct = [math]::Round([double]$status.return_pct, 2)
        $cash = [math]::Round([double]$status.cash, 2)
        $exposure = [math]::Round([double]$status.exposure, 2)
        $equityCard.Value.Text = $equity.ToString("N2")
        $equityCard.Note.Text = "USDT de capital total"
        $returnPrefix = if ($returnPct -ge 0) { "+" } else { "" }
        $returnCard.Value.Text = $returnPrefix + $returnPct.ToString("N2") + "%"
        $returnCard.Value.ForeColor = if ($returnPct -ge 0) { [System.Drawing.Color]::FromArgb(45, 226, 166) } else { [System.Drawing.Color]::FromArgb(255, 120, 140) }
        $returnCard.Note.Text = "Desde el inicio"
        $cashCard.Value.Text = $cash.ToString("N2")
        $cashCard.Note.Text = "USDT disponibles"
        $exposureCard.Value.Text = $exposure.ToString("N2")
        $exposureCard.Note.Text = "$($status.positions) de $($status.max_positions) posiciones"
        $lastCycleLabel.Text = "ÚLTIMO CICLO`r`n$lastCycle"
        $notifyIcon.Text = "Crypto AI Trader - $equity USDT"
    }
    catch {
        if ($processCount -gt 0) {
            $statusLabel.Text = "Motor iniciando"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
            $statusDot.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
            $statusPanel.BackColor = [System.Drawing.Color]::FromArgb(44, 37, 24)
            $statusDescription.Text = "El proceso está activo, pero el portal todavía no responde."
            $notifyIcon.Text = "Crypto AI Trader - iniciando"
            $notifyIcon.Icon = $script:WarningIcon
            $trayStatusItem.Text = "● Motor iniciando"
            $trayStatusItem.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
        }
        else {
            $statusLabel.Text = "Motor detenido"
            $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 93, 115)
            $statusDot.ForeColor = [System.Drawing.Color]::FromArgb(255, 93, 115)
            $statusPanel.BackColor = [System.Drawing.Color]::FromArgb(48, 25, 34)
            $statusDescription.Text = "No se encontró el proceso automático. Usa Reiniciar motor."
            $notifyIcon.Text = "Crypto AI Trader - detenido"
            $notifyIcon.Icon = $script:OfflineIcon
            $trayStatusItem.Text = "● Motor detenido"
            $trayStatusItem.ForeColor = [System.Drawing.Color]::FromArgb(255, 93, 115)
        }
        $lastCycleLabel.Text = "ÚLTIMO CICLO`r`nSin conexión"
        foreach ($card in @($equityCard, $returnCard, $cashCard, $exposureCard)) {
            $card.Value.Text = "—"
            $card.Note.Text = "Datos no disponibles"
        }
    }
    if (Test-Path $KillSwitchPath) {
        $killButton.Text = "▶   Reanudar nuevas entradas"
        $killButton.BackColor = [System.Drawing.Color]::FromArgb(14, 52, 48)
        $killButton.ForeColor = [System.Drawing.Color]::FromArgb(77, 239, 187)
        $killButton.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(37, 112, 94)
        $protectionLabel.Text = "⚠  Kill switch activo  ·  No se abrirán nuevas posiciones"
        $protectionLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
    }
    else {
        $killButton.Text = "⚠   Activar kill switch"
        $killButton.BackColor = [System.Drawing.Color]::FromArgb(55, 24, 35)
        $killButton.ForeColor = [System.Drawing.Color]::FromArgb(255, 147, 164)
        $killButton.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(120, 48, 66)
        $protectionLabel.Text = "✓  Protecciones activas  ·  Simulación sin dinero real"
        $protectionLabel.ForeColor = [System.Drawing.Color]::FromArgb(92, 215, 171)
    }
    if (Test-CanonicalStartup) {
        $startupButton.Text = "✓   Inicio automático activado"
    }
    elseif ((Get-ProjectStartupShortcuts).Count -gt 0) {
        $startupButton.Text = "⚙   Actualizar inicio automático"
    }
    else {
        $startupButton.Text = "⚙   Activar inicio automático"
    }
    $versionLabel.Text = "VERSIÓN " + (Get-InstalledVersion)
}

$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$notifyIcon.Icon = $script:WarningIcon
$notifyIcon.Text = "Crypto AI Trader - comprobando"
$notifyIcon.Visible = $true

$notifyMenu = New-Object System.Windows.Forms.ContextMenuStrip
$notifyMenu.BackColor = [System.Drawing.Color]::FromArgb(16, 27, 45)
$notifyMenu.ForeColor = [System.Drawing.Color]::FromArgb(236, 242, 255)
$notifyMenu.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$notifyMenu.ShowImageMargin = $true
$trayStatusItem = $notifyMenu.Items.Add("● Comprobando estado")
$trayStatusItem.Enabled = $false
$trayStatusItem.ForeColor = [System.Drawing.Color]::FromArgb(255, 204, 102)
$notifyMenu.Items.Add("-") | Out-Null
$showManagerItem = $notifyMenu.Items.Add("Abrir centro de control")
$script:MenuBitmap = $script:OperationalIcon.ToBitmap()
$showManagerItem.Image = $script:MenuBitmap
$showManagerItem.Add_Click({
    $form.Show()
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Activate()
})
$openPortalItem = $notifyMenu.Items.Add("Abrir portal")
$openPortalItem.Add_Click({ Start-Process $DashboardUrl })
$checkUpdatesItem = $notifyMenu.Items.Add("Buscar actualizaciones")
$checkUpdatesItem.Add_Click({
    $form.Show()
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Activate()
    $updateButton.PerformClick()
})
$localUpdateItem = $notifyMenu.Items.Add("Instalar actualización local...")
$localUpdateItem.Add_Click({
    $form.Show()
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Activate()
    $package = Select-LocalUpdatePackage
    if ($package) { Install-UpdatePackage -PackagePath $package }
})
$notifyMenu.Items.Add("-") | Out-Null
$exitItem = $notifyMenu.Items.Add("Salir del indicador")
$script:AllowExit = $false
$exitItem.Add_Click({
    $script:AllowExit = $true
    $form.Close()
})
$notifyIcon.ContextMenuStrip = $notifyMenu
$notifyIcon.Add_DoubleClick({
    $form.Show()
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Activate()
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 15000
$timer.Add_Tick({
    Update-ManagerStatus
    if (((Get-Date) - $script:LastUpdateCheck) -ge $UpdateCheckInterval) {
        Check-ForUpdates -Silent | Out-Null
    }
})
$form.Add_Shown({
    if ($Minimized) {
        Start-TradingBot
    }
    Update-ManagerStatus
    $timer.Start()
    if ($Minimized) { $form.Hide() }
    Check-ForUpdates -Silent | Out-Null
})
$form.Add_Resize({
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
        $form.Hide()
    }
})
$form.Add_FormClosing({
    param($sender, $eventArgs)
    if (-not $script:AllowExit) {
        $eventArgs.Cancel = $true
        $form.Hide()
        $notifyIcon.ShowBalloonTip(
            2500,
            "Crypto AI Trader",
            "El indicador continuará funcionando en segundo plano.",
            [System.Windows.Forms.ToolTipIcon]::Info
        )
    }
})
$form.Add_FormClosed({
    $timer.Stop()
    $notifyIcon.Visible = $false
    $notifyIcon.Dispose()
    $script:LogoBitmap.Dispose()
    $script:MenuBitmap.Dispose()
})

[void]$form.ShowDialog()
