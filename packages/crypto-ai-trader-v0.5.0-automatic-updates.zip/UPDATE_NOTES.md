# Actualización 0.5.0 — canal automático seguro

## Cambios principales

- El Centro de Control consulta automáticamente el canal estable al abrirse y cada seis horas.
- El botón de actualización descarga el paquete correcto sin pedir que el usuario busque un ZIP.
- Cada descarga se valida por HTTPS, origen, tamaño y huella SHA-256 antes de instalarse.
- La instalación siempre requiere confirmación: nunca se aplican cambios silenciosos.
- Si la red o la verificación fallan, el bot continúa ejecutando la versión instalada.
- El menú del área de notificaciones permite buscar actualizaciones o instalar un ZIP local de recuperación.
- Corrige el logotipo distorsionado del encabezado cargándolo desde PNG.
- Evita el falso aviso de error cuando el registro confirma que la actualización terminó correctamente.
- Rediseña completamente el Centro de Control con una interfaz más limpia y consistente con el portal.
- Añade tarjetas independientes para equity, rendimiento, efectivo, exposición y posiciones.
- Incorpora iconos visuales en las acciones principales.
- Añade un icono propio de Crypto AI Trader en la ventana y barra de tareas.
- El icono del área de notificaciones cambia entre verde, amarillo y rojo según el estado del motor.
- El menú del indicador muestra el estado operativo sin necesidad de abrir la aplicación.
- Corrige los caracteres españoles, acentos y símbolos en Windows PowerShell 5.1.
- Corrige el bloqueo del Centro de Control al esperar que termine el motor reiniciado.
- Reinicia automáticamente la aplicación después de instalar una versión nueva.
- Guarda registros de cada actualización dentro de `data` para facilitar diagnósticos.
- Semáforo de actividad basado en el último ciclo exitoso.
- Hora real del último ciclo, en vez de la hora de actualización del navegador.
- Precio spot y P&L no realizado estimado por posición.
- Equity calculado con el precio spot más reciente disponible.
- Stops y objetivos revisados con precio spot; las señales siguen usando velas cerradas.
- Las posiciones abiertas se vigilan aunque salgan del top de volumen.
- Panel con errores y advertencias recientes.
- Endpoint `/health` para integrar alertas externas posteriormente.

## Actualización segura en Windows

La carpeta `data` y el archivo `.env.local` no forman parte de este paquete. Al actualizar, consérvalos en la instalación existente: contienen el estado paper y las credenciales locales.

1. Detén el proceso actual `py -m trader run`.
2. Copia las carpetas `trader` y `web` de esta versión sobre las existentes.
3. Copia `tests`, `README.md` y `pyproject.toml`.
4. No reemplaces ni elimines `data`, `.env.local` o `config.toml`.
5. Ejecuta `py -m unittest discover -s tests -v`.
6. Reinicia con `py -m trader run` o vuelve a iniciar sesión para usar el arranque automático existente.

Tailscale Serve no necesita cambios: continuará apuntando a `127.0.0.1:8765`.

## Actualizador automático asistido

La versión 0.5.0 incorpora un canal estable en línea. El Centro de Control avisa cuando existe una versión nueva y puede descargarla, verificarla e instalarla con autorización del usuario. `ACTUALIZAR_BOT.cmd` y la opción de paquete local siguen disponibles como mecanismos de recuperación.

## Aplicación gráfica

`Crypto AI Trader.vbs` abre un centro de control sin mostrar PowerShell. Incluye estado, resumen de inversión, último ciclo y botones para abrir los portales, reiniciar, manejar el kill switch, configurar el inicio automático e instalar actualizaciones. Al minimizarlo queda como indicador en el área de notificaciones. El actualizador continúa disponible por consola como mecanismo alternativo de recuperación.
