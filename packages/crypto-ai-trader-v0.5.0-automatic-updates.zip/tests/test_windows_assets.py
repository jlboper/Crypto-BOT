import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class WindowsAssetTests(unittest.TestCase):
    def test_windows_scripts_keep_utf8_bom(self):
        for relative in ("scripts/manager_windows.ps1", "scripts/update_windows.ps1"):
            with self.subTest(relative=relative):
                self.assertTrue((PROJECT_ROOT / relative).read_bytes().startswith(b"\xef\xbb\xbf"))

    def test_status_icons_are_valid_ico_files(self):
        for name in (
            "crypto-ai-trader.ico",
            "crypto-ai-trader-warning.ico",
            "crypto-ai-trader-offline.ico",
        ):
            with self.subTest(name=name):
                payload = (PROJECT_ROOT / "web" / name).read_bytes()
                self.assertTrue(payload.startswith(b"\x00\x00\x01\x00"))
                self.assertGreater(len(payload), 1024)

    def test_manager_waits_only_for_the_updater_process(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("$process.WaitForExit()", source)
        self.assertIn("$process.Refresh()", source)
        self.assertIn("ACTUALIZACION COMPLETADA CORRECTAMENTE", source)
        self.assertNotIn("-Wait `", source)

    def test_manager_uses_public_github_update_channel(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        self.assertIn(
            "https://raw.githubusercontent.com/jlboper/Crypto-BOT/main/latest.json",
            source,
        )
        self.assertIn('$UpdateRepositoryPath = "/jlboper/Crypto-BOT/"', source)
        self.assertIn("Install-RemoteUpdate -Update $available", source)
        self.assertIn("Get-FileHash -LiteralPath $packagePath -Algorithm SHA256", source)

    def test_header_logo_is_a_valid_png(self):
        payload = (PROJECT_ROOT / "web" / "crypto-ai-trader-icon.png").read_bytes()
        self.assertTrue(payload.startswith(b"\x89PNG\r\n\x1a\n"))

    def test_manager_uses_verified_remote_update_channel(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("https://raw.githubusercontent.com/jlboper/Crypto-BOT/main/latest.json", source)
        self.assertIn("Get-FileHash -LiteralPath $packagePath -Algorithm SHA256", source)
        self.assertIn("$packageUri.Host -ne $manifestUri.Host", source)
        self.assertIn("[TimeSpan]::FromHours(6)", source)
        self.assertIn("Instalar actualización local...", source)


if __name__ == "__main__":
    unittest.main()
