"""Supervised USDⓈ-M Futures Testnet lab.

This is intentionally separate from the automatic Spot engine. It supports
readiness checks and a small reversible LONG/SHORT smoke round trip using
1x/2x/3x isolated leverage. It has no production host and no LIVE mode.
"""
from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_DOWN
import math
import secrets
import time

from .futures_testnet_ledger import FuturesTestnetLedger
from .futures_testnet_transport import (
    FuturesTestnetExecutionError,
    public_request,
    signed_request,
)


def _decimal(value) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise FuturesTestnetExecutionError("Invalid Futures Testnet numeric value") from None
    if not result.is_finite():
        raise FuturesTestnetExecutionError("Invalid Futures Testnet numeric value")
    return result


def _floor_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise FuturesTestnetExecutionError("Invalid Futures Testnet quantity step")
    return (value / step).to_integral_value(rounding=ROUND_DOWN) * step


class FuturesTestnetLab:
    SYMBOLS = ("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT")
    # Each quantity is validated with /order/test immediately before use.
    # BTCUSDT 0.001 is already used by Verificar Futures and therefore known
    # to be accepted by the current Demo account without executing an order.
    SMOKE_QUANTITIES = {
        "BTCUSDT": Decimal("0.001"),
        "ETHUSDT": Decimal("0.01"),
        "BNBUSDT": Decimal("0.1"),
        "SOLUSDT": Decimal("0.1"),
        "XRPUSDT": Decimal("10"),
    }

    def __init__(self, settings):
        self.settings = settings
        self.ledger = FuturesTestnetLedger(settings.database_path)

    def _position_state(self, symbol: str) -> dict:
        """Return one authoritative symbol state, tolerating flat HEDGE rows.

        Binance can return separate LONG/SHORT rows while the account is in
        hedge mode. When both rows are flat, this is not ambiguous exposure;
        it is a flat account-mode mismatch that can be repaired safely before
        enabling automatic forward entries.
        """
        payload = signed_request("GET", "/fapi/v3/positionRisk", {"symbol": symbol})
        if not isinstance(payload, list):
            raise FuturesTestnetExecutionError("Invalid Futures Testnet position response")
        rows = [row for row in payload
                if isinstance(row, dict)
                and str(row.get("symbol", symbol)).upper() == symbol.upper()]
        if not rows:
            raise FuturesTestnetExecutionError(f"Futures Demo symbol state unavailable: {symbol}")
        for row in rows:
            _decimal(row.get("positionAmt", "0"))
            _decimal(row.get("leverage", "0"))
        if len(rows) == 1:
            return rows[0]
        exposed = [row for row in rows if _decimal(row.get("positionAmt", "0")) != 0]
        if exposed:
            raise FuturesTestnetExecutionError(f"Futures Demo symbol state ambiguous with exposure: {symbol}")
        # Flat hedge-mode rows are collapsed into one synthetic flat state so
        # the preflight can switch the account back to ONE_WAY safely.
        base = dict(rows[0])
        base["positionAmt"] = "0"
        base["positionSide"] = "HEDGE_FLAT"
        return base

    def _position_rows(self, symbol: str | None = None) -> list[dict]:
        payload = signed_request("GET", "/fapi/v3/positionRisk", {"symbol": symbol} if symbol else {})
        if not isinstance(payload, list):
            raise FuturesTestnetExecutionError("Invalid Futures Testnet position response")
        rows = []
        for row in payload:
            if not isinstance(row, dict):
                continue
            amount = _decimal(row.get("positionAmt", "0"))
            if amount != 0:
                if symbol and str(row.get("symbol", "")).upper() != symbol.upper():
                    raise FuturesTestnetExecutionError("Futures position response symbol mismatch")
                rows.append(self._configured_position(row))
        return rows

    def _configured_position(self, row: dict) -> dict:
        """V3 supplies exposure; symbolConfig supplies margin and leverage.

        Never interpret an absent configuration field as CROSS exposure.
        Legacy complete rows remain accepted for the manual diagnostic path.
        """
        symbol = str(row.get("symbol", "")).upper()
        if not symbol:
            raise FuturesTestnetExecutionError("Futures position symbol unavailable")
        if not row.get("marginType") or not row.get("leverage"):
            config = self._symbol_config(symbol)
            return {**row, "marginType": config["marginType"], "leverage": config["leverage"]}
        margin = str(row["marginType"]).lower()
        if margin == "crossed":
            margin = "cross"
        if margin not in {"cross", "isolated"}:
            raise FuturesTestnetExecutionError("Futures position configuration unavailable")
        return {**row, "marginType": margin}

    def _account(self) -> dict:
        payload = signed_request("GET", "/fapi/v3/account", {})
        if not isinstance(payload, dict):
            raise FuturesTestnetExecutionError("Invalid Futures Testnet account response")
        return payload

    def _symbol_config(self, symbol: str) -> dict:
        """Read leverage/margin configuration from Binance's configuration endpoint.

        /fapi/v3/positionRisk intentionally omits flat symbols without open
        orders, so it must not be used to confirm configuration while flat.
        """
        payload = signed_request("GET", "/fapi/v1/symbolConfig", {"symbol": symbol})
        if isinstance(payload, dict):
            rows = [payload]
        elif isinstance(payload, list):
            rows = payload
        else:
            raise FuturesTestnetExecutionError("Invalid Futures symbol configuration response")
        row = next((item for item in rows if isinstance(item, dict)
                    and str(item.get("symbol", "")).upper() == symbol.upper()), None)
        if row is None:
            fallback = signed_request("GET", "/fapi/v1/symbolConfig", {})
            fallback_rows = [fallback] if isinstance(fallback, dict) else fallback if isinstance(fallback, list) else []
            row = next((item for item in fallback_rows if isinstance(item, dict)
                        and str(item.get("symbol", "")).upper() == symbol.upper()), None)
        if row is None:
            raise FuturesTestnetExecutionError(f"Futures symbol configuration unavailable: {symbol}")
        leverage = _decimal(row.get("leverage", "0"))
        if leverage <= 0:
            raise FuturesTestnetExecutionError(f"Futures symbol leverage configuration unavailable: {symbol}")
        margin = str(row.get("marginType", "")).lower()
        if margin == "crossed":
            margin = "cross"
        if margin not in {"isolated", "cross"}:
            raise FuturesTestnetExecutionError(f"Futures symbol margin configuration unavailable: {symbol}")
        return {**row, "marginType": margin}

    def _trade_probe(self, symbol: str = "BTCUSDT") -> bool:
        """Validate TRADE permission without public-data dependency or execution."""
        # 0.001 BTC is deliberately conservative for BTCUSDT test-order validation:
        # it is above the historical MARKET minQty and does not execute on /order/test.
        result = signed_request("POST", "/fapi/v1/order/test", {
            "symbol": symbol,
            "side": "BUY",
            "type": "MARKET",
            "quantity": "0.001",
        })
        if result not in ({}, None):
            if not isinstance(result, dict):
                raise FuturesTestnetExecutionError("Invalid Futures Demo test-order response")
        return True

    def _validate_smoke_quantity(self, symbol: str, direction: str) -> Decimal:
        quantity = self.SMOKE_QUANTITIES.get(symbol)
        if quantity is None:
            raise FuturesTestnetExecutionError("No bounded Futures Demo smoke quantity")
        side = "BUY" if direction == "LONG" else "SELL"
        result = signed_request("POST", "/fapi/v1/order/test", {
            "symbol": symbol,
            "side": side,
            "type": "MARKET",
            "quantity": format(quantity, "f"),
        })
        if result not in ({}, None) and not isinstance(result, dict):
            raise FuturesTestnetExecutionError("Invalid Futures Demo smoke preflight response")
        return quantity

    def check(self) -> dict:
        account = self._account()
        positions = self._position_rows()
        balance = _decimal(account.get("totalWalletBalance", "0"))
        available = _decimal(account.get("availableBalance", "0"))
        trade_probe = self._trade_probe()
        return {
            "ok": True,
            "environment": "USD-M FUTURES DEMO",
            "can_trade": trade_probe,
            "reported_can_trade": bool(account.get("canTrade", False)),
            "trade_probe": trade_probe,
            "wallet_balance": float(balance),
            "available_balance": float(available),
            "open_positions": len(positions),
            "margin_type": self.settings.margin_type,
            "position_mode": self.settings.position_mode,
            "allowed_leverage": [1, 2, 3][: self.settings.max_leverage],
            "latest_smoke": self.ledger.latest(),
            "live_enabled": False,
        }

    def _configure(self, symbol: str, leverage: int) -> None:
        if leverage not in {1, 2, 3} or leverage > self.settings.max_leverage:
            raise ValueError("Futures Testnet leverage must be 1x, 2x or 3x")
        mode = signed_request("GET", "/fapi/v1/positionSide/dual", {})
        if not isinstance(mode, dict) or "dualSidePosition" not in mode:
            raise FuturesTestnetExecutionError("Futures Testnet position mode unavailable")
        if bool(mode["dualSidePosition"]):
            signed_request("POST", "/fapi/v1/positionSide/dual", {"dualSidePosition": "false"})
        try:
            signed_request("POST", "/fapi/v1/marginType", {"symbol": symbol, "marginType": "ISOLATED"})
        except FuturesTestnetExecutionError as exc:
            if exc.code != -4046:
                raise
        response = signed_request("POST", "/fapi/v1/leverage", {"symbol": symbol, "leverage": leverage})
        if not isinstance(response, dict) or int(response.get("leverage", 0)) != leverage:
            raise FuturesTestnetExecutionError("Futures Testnet leverage confirmation mismatch")

    def ensure_flat_forward_configuration(self, symbol: str, leverage: int = 1) -> dict:
        """Idempotently enforce ONE_WAY + ISOLATED + requested Demo leverage.

        Binance v3 positionRisk only returns symbols with an open position or
        open order. Therefore flatness is verified from the absence of non-zero
        position rows, while leverage/margin configuration is verified through
        /fapi/v1/symbolConfig, the endpoint Binance exposes for this purpose.
        """
        if type(leverage) is not int or leverage not in {1, 2, 3} or leverage > self.settings.max_leverage:
            raise ValueError("Futures Testnet leverage must be 1x, 2x or 3x")
        if self._position_rows(symbol):
            raise FuturesTestnetExecutionError(f"Futures flat preflight found open exposure: {symbol}")

        mode = signed_request("GET", "/fapi/v1/positionSide/dual", {})
        if not isinstance(mode, dict) or "dualSidePosition" not in mode:
            raise FuturesTestnetExecutionError("Futures Testnet position mode unavailable")
        if bool(mode["dualSidePosition"]):
            signed_request("POST", "/fapi/v1/positionSide/dual", {"dualSidePosition": "false"})

        before = self._symbol_config(symbol)
        ready = (
            str(before.get("marginType", "")).lower() == "isolated"
            and int(float(before.get("leverage", 0) or 0)) == leverage
        )
        if not ready:
            self._configure(symbol, leverage)

        if self._position_rows(symbol):
            raise FuturesTestnetExecutionError(f"Futures flat preflight found new exposure: {symbol}")
        after = self._symbol_config(symbol)
        if str(after.get("marginType", "")).lower() != "isolated":
            raise FuturesTestnetExecutionError(f"Futures flat preflight could not confirm ISOLATED: {symbol}")
        if int(float(after.get("leverage", 0) or 0)) != leverage:
            raise FuturesTestnetExecutionError(f"Futures flat preflight could not confirm {leverage}x: {symbol}")
        mode_after = signed_request("GET", "/fapi/v1/positionSide/dual", {})
        if not isinstance(mode_after, dict) or bool(mode_after.get("dualSidePosition")):
            raise FuturesTestnetExecutionError("Automatic Futures position mode changed from ONE_WAY")
        return {
            "symbol": symbol,
            "positionAmt": "0",
            "marginType": str(after.get("marginType", "")).lower(),
            "leverage": str(after.get("leverage")),
            "positionSide": "BOTH",
        }

    def ensure_forward_position_configuration(self, symbol: str, row: dict, expected_leverage: int = 1) -> dict:
        """Repair only a known isolated forward position whose leverage drifted.

        CROSS or hedge-mode positions fail closed; they are never mutated
        automatically while open. A leverage write is reconciled by rereading
        positionRisk before protection continues.
        """
        if type(expected_leverage) is not int or expected_leverage not in {1, 2, 3} or expected_leverage > self.settings.max_leverage:
            raise ValueError("Futures Testnet leverage must be 1x, 2x or 3x")
        row = self._configured_position({"symbol": symbol, **row})
        if str(row.get("marginType", "")).lower() != "isolated":
            raise FuturesTestnetExecutionError("Automatic Futures margin is not isolated")
        position_side = str(row.get("positionSide", "")).upper()
        if position_side and position_side != "BOTH":
            raise FuturesTestnetExecutionError("Automatic Futures position mode changed from ONE_WAY")
        if not position_side:
            mode = signed_request("GET", "/fapi/v1/positionSide/dual", {})
            if not isinstance(mode, dict) or "dualSidePosition" not in mode:
                raise FuturesTestnetExecutionError("Futures Testnet position mode unavailable")
            if bool(mode["dualSidePosition"]):
                raise FuturesTestnetExecutionError("Automatic Futures position mode changed from ONE_WAY")
        leverage = int(float(row.get("leverage", 0) or 0))
        if leverage == expected_leverage:
            return row
        if leverage not in {1, 2, 3}:
            raise FuturesTestnetExecutionError("Automatic Futures leverage is invalid")
        try:
            response = signed_request("POST", "/fapi/v1/leverage", {"symbol": symbol, "leverage": expected_leverage})
            if not isinstance(response, dict) or int(response.get("leverage", 0)) != expected_leverage:
                raise FuturesTestnetExecutionError("Futures Testnet leverage confirmation mismatch")
        except FuturesTestnetExecutionError as exc:
            if not exc.uncertain:
                raise
        refreshed = self._position_rows(symbol)
        if len(refreshed) != 1 or int(float(refreshed[0].get("leverage", 0) or 0)) != expected_leverage:
            raise FuturesTestnetExecutionError("Automatic Futures leverage repair not confirmed")
        if str(refreshed[0].get("marginType", "")).lower() != "isolated":
            raise FuturesTestnetExecutionError("Automatic Futures margin is not isolated")
        return refreshed[0]

    @staticmethod
    def _symbol_info(symbol: str) -> dict:
        payload = public_request("GET", "/fapi/v1/exchangeInfo", {"symbol": symbol}, allow_fallback=False)
        rows = payload.get("symbols", []) if isinstance(payload, dict) else []
        row = next((item for item in rows if isinstance(item, dict) and item.get("symbol") == symbol), None)
        if row is None:
            raise FuturesTestnetExecutionError("Futures Testnet symbol unavailable")
        return row

    @staticmethod
    def _reference(symbol: str) -> tuple[Decimal, float | None]:
        """Use only Demo-market references, with a same-host mark-price fallback."""
        premium = None
        price = Decimal("0")
        try:
            payload = public_request("GET", "/fapi/v1/ticker/price", {"symbol": symbol}, allow_fallback=False)
            candidate = _decimal(payload.get("price", "0") if isinstance(payload, dict) else "0")
            if candidate > 0:
                price = candidate
        except FuturesTestnetExecutionError:
            pass
        try:
            premium = public_request("GET", "/fapi/v1/premiumIndex", {"symbol": symbol}, allow_fallback=False)
        except FuturesTestnetExecutionError:
            premium = None
        if price <= 0 and isinstance(premium, dict):
            for key in ("markPrice", "indexPrice"):
                try:
                    candidate = _decimal(premium.get(key, "0"))
                except FuturesTestnetExecutionError:
                    continue
                if candidate > 0:
                    price = candidate
                    break
        if price <= 0:
            raise FuturesTestnetExecutionError(f"Futures Demo reference price unavailable: {symbol}")
        funding = None
        if isinstance(premium, dict):
            try:
                candidate = float(premium.get("lastFundingRate"))
                if math.isfinite(candidate):
                    funding = candidate
            except (TypeError, ValueError):
                pass
        return price, funding

    @staticmethod
    def _market_lot_filter(info: dict) -> dict:
        """Prefer MARKET_LOT_SIZE, but fall back to a valid LOT_SIZE.

        Binance Demo can expose an incomplete MARKET_LOT_SIZE on an otherwise
        tradable contract. Final sizing is still verified with /order/test.
        """
        filters = {row.get("filterType"): row for row in info.get("filters", []) if isinstance(row, dict)}
        for key in ("MARKET_LOT_SIZE", "LOT_SIZE"):
            row = filters.get(key) or {}
            try:
                step = _decimal(row.get("stepSize", "0"))
                minimum = _decimal(row.get("minQty", "0"))
                maximum = _decimal(row.get("maxQty", "0"))
            except FuturesTestnetExecutionError:
                continue
            if step > 0 and minimum > 0 and maximum >= minimum:
                return row
        raise FuturesTestnetExecutionError("Futures Demo quantity filters unavailable")

    @staticmethod
    def _probe_quantity(info: dict, price: Decimal, target_notional: Decimal) -> Decimal:
        """Smallest valid MARKET quantity for /order/test; this order is never executed."""
        filters = {row.get("filterType"): row for row in info.get("filters", []) if isinstance(row, dict)}
        lot = FuturesTestnetLab._market_lot_filter(info)
        step = _decimal(lot.get("stepSize", "0"))
        minimum = _decimal(lot.get("minQty", "0"))
        notional_filter = filters.get("MIN_NOTIONAL") or {}
        minimum_notional = _decimal(notional_filter.get("notional", "0"))
        required_notional = max(target_notional, minimum_notional)
        by_notional = (required_notional / price / step).to_integral_value(rounding=ROUND_CEILING) * step
        quantity = max(minimum, by_notional)
        return (quantity / step).to_integral_value(rounding=ROUND_CEILING) * step

    def forward_quantity(self, symbol: str, direction: str, target: Decimal, ceiling: Decimal) -> tuple[Decimal, Decimal]:
        """Size from current Demo filters, without leverage multiplying exposure."""
        from .config import FUTURES_FORWARD_SYMBOLS
        if symbol not in FUTURES_FORWARD_SYMBOLS or direction not in {"LONG", "SHORT"}:
            raise FuturesTestnetExecutionError("Unsupported Futures forward asset")
        info = self._symbol_info(symbol)
        if (info.get("status") != "TRADING" or info.get("contractType") != "PERPETUAL"
                or info.get("quoteAsset") != "USDT"):
            raise FuturesTestnetExecutionError("Futures forward contract unavailable")
        price, _ = self._reference(symbol)
        if price <= 0:
            raise FuturesTestnetExecutionError("Futures reference price unavailable")
        filters = {r.get("filterType"): r for r in info.get("filters", [])}
        lot = self._market_lot_filter(info)
        step = _decimal(lot.get("stepSize", "0"))
        minimum = _decimal(lot.get("minQty", "0"))
        maximum = _decimal(lot.get("maxQty", "0"))
        # Reserve 2% for price movement, independently of the cost-loss reserve.
        safe_ceiling = ceiling / Decimal("1.02")
        qty = _floor_step(min(target, safe_ceiling) / price, step)
        required = self._probe_quantity(info, price, Decimal("0"))
        qty = max(qty, required)
        if qty > maximum or qty * price > safe_ceiling:
            return Decimal("0"), price
        signed_request("POST", "/fapi/v1/order/test", {
            "symbol": symbol, "side": "BUY" if direction == "LONG" else "SELL",
            "type": "MARKET", "quantity": format(qty, "f"),
        })
        return qty, price

    @staticmethod
    def _quantity(info: dict, price: Decimal, notional: Decimal) -> Decimal:
        filters = {row.get("filterType"): row for row in info.get("filters", []) if isinstance(row, dict)}
        lot = filters.get("MARKET_LOT_SIZE") or filters.get("LOT_SIZE") or {}
        step = _decimal(lot.get("stepSize", "0"))
        minimum = _decimal(lot.get("minQty", "0"))
        quantity = _floor_step(notional / price, step)
        if quantity < minimum or quantity <= 0:
            raise FuturesTestnetExecutionError("Futures Testnet smoke quantity below exchange minimum")
        notional_filter = filters.get("MIN_NOTIONAL") or {}
        minimum_notional = _decimal(notional_filter.get("notional", "0"))
        if quantity * price < minimum_notional:
            raise FuturesTestnetExecutionError("Futures Testnet smoke notional below exchange minimum")
        return quantity

    def _query_order(self, pending: dict) -> dict:
        result = signed_request("GET", "/fapi/v1/order", {
            "symbol": pending["symbol"],
            "origClientOrderId": pending["client_order_id"],
        })
        if not isinstance(result, dict) or result.get("clientOrderId") != pending["client_order_id"]:
            raise FuturesTestnetExecutionError("Futures Testnet order identity mismatch")
        return result

    def _submit(self, *, run_id: int, phase: str, symbol: str, side: str,
                quantity: Decimal, reduce_only: bool) -> dict:
        existing = self.ledger.setting("pending_order")
        if existing:
            raise FuturesTestnetExecutionError("Futures Testnet order requires reconciliation")
        client_id = "cait-fut-" + secrets.token_hex(8)
        pending = {
            "run_id": run_id,
            "phase": phase,
            "symbol": symbol,
            "side": side,
            "quantity": str(quantity),
            "reduce_only": reduce_only,
            "client_order_id": client_id,
        }
        self.ledger.set_setting("pending_order", pending)
        fields = {
            "symbol": symbol,
            "side": side,
            "type": "MARKET",
            "quantity": format(quantity, "f"),
            "newClientOrderId": client_id,
            "newOrderRespType": "RESULT",
        }
        if reduce_only:
            fields["reduceOnly"] = "true"
        try:
            result = signed_request("POST", "/fapi/v1/order", fields)
        except FuturesTestnetExecutionError:
            # Do not retry. A later read-only order query must resolve identity/status.
            raise
        if not isinstance(result, dict) or result.get("clientOrderId") != client_id:
            raise FuturesTestnetExecutionError("Futures Testnet order identity mismatch")
        if result.get("status") != "FILLED":
            raise FuturesTestnetExecutionError("Futures Testnet MARKET order requires reconciliation")
        self.ledger.set_setting("pending_order", None)
        return result

    def forward_submit(self, *, symbol: str, side: str, quantity: Decimal, reduce_only: bool) -> dict:
        """Submit one forward-test order with a journal separate from smoke tests."""
        existing = self.ledger.setting("forward_pending_order")
        if existing:
            raise FuturesTestnetExecutionError("Futures forward order requires reconciliation")
        if not reduce_only:
            plan = self.ledger.setting("forward_open_plan") or {}
            leverage = int(plan.get("leverage", 1))
            if plan and (plan.get("symbol") != symbol or
                         ("BUY" if plan.get("direction") == "LONG" else "SELL") != side):
                raise FuturesTestnetExecutionError("Futures opening plan identity mismatch")
            self.ensure_flat_forward_configuration(symbol, leverage)
        client_id = "cait-fwd-" + secrets.token_hex(8)
        pending = {
            "symbol": symbol,
            "side": side,
            "quantity": str(quantity),
            "reduce_only": reduce_only,
            "kind": "CLOSE" if reduce_only else "OPEN",
            "created_at": datetime.now(UTC).isoformat(),
            "client_order_id": client_id,
        }
        self.ledger.set_setting("forward_pending_order", pending)
        if not reduce_only:
            self._observe_forward_entry(pending, plan)
        fields = {
            "symbol": symbol,
            "side": side,
            "type": "MARKET",
            "quantity": format(quantity, "f"),
            "newClientOrderId": client_id,
            "newOrderRespType": "RESULT",
        }
        if reduce_only:
            fields["reduceOnly"] = "true"
        try:
            result = signed_request("POST", "/fapi/v1/order", fields)
        except Exception:
            if not reduce_only:
                self._observe_forward_response(pending, {})
            raise
        if not isinstance(result, dict) or result.get("clientOrderId") != client_id:
            raise FuturesTestnetExecutionError("Futures forward order identity mismatch")
        if not reduce_only:
            self._observe_forward_response(pending, result)
        if result.get("status") != "FILLED":
            raise FuturesTestnetExecutionError("Futures forward MARKET order requires reconciliation")
        # The caller clears the journal only after the corresponding local
        # position/trade commit. This closes the power-loss window between a
        # confirmed Binance fill and durable local accounting.
        return result

    def _observe_forward_entry(self, pending: dict, plan: dict) -> None:
        try:
            from .opportunity_observer import observe_entry_intent
            context = getattr(self, "_opportunity_context", None) or {}
            final_at = time.time()
            evidence = dict(context.get("evidence", {"checks": ("NATIVE_FORWARD_CONFIGURATION_PASSED",)}))
            evidence.update(decision_at=final_at, known_at=final_at)
            leg = {"symbol": pending["symbol"], "venue": "FUTURES_DEMO",
                   "direction": "LONG" if pending["side"] == "BUY" else "SHORT",
                   "quantity": pending["quantity"], "reference_price": context.get("reference_price")}
            for key in ("stop_price", "take_profit"):
                if key in context:
                    leg[key] = context[key]
            observe_entry_intent(engine="FUTURES", environment="FUTURES_DEMO",
                origin_ref=pending["client_order_id"], strategy_version="futures-final-entry-v1", at=final_at,
                legs=[leg], capital=context.get("capital"), limits=None, evidence=evidence)
        except Exception:
            pass

    @staticmethod
    def _observe_forward_response(pending: dict, response: dict) -> None:
        try:
            from .opportunity_observer import observe_entry_outcome
            evidence = {}
            if "executedQty" in response:
                evidence["quantity"] = response["executedQty"]
            status = response.get("status")
            state = {"PARTIALLY_FILLED": "PARTIAL", "CANCELED": "CANCELLED",
                     "EXPIRED": "CANCELLED", "EXPIRED_IN_MATCH": "CANCELLED"}.get(status, status)
            observe_entry_outcome(engine="FUTURES", environment="FUTURES_DEMO",
                origin_ref=pending["client_order_id"], at=time.time(), stage="EXCHANGE_RESPONSE",
                state=state if state in {"FILLED", "PARTIAL", "CANCELLED", "REJECTED"} else "UNKNOWN",
                complete=status in {"FILLED", "CANCELED", "EXPIRED", "EXPIRED_IN_MATCH", "REJECTED"},
                evidence=evidence)
        except Exception:
            pass

    def reconcile_forward_pending(self) -> dict | None:
        pending = self.ledger.setting("forward_pending_order")
        if not pending:
            return None
        try:
            result = signed_request("GET", "/fapi/v1/order", {
                "symbol": pending["symbol"],
                "origClientOrderId": pending["client_order_id"],
            })
        except FuturesTestnetExecutionError as exc:
            # Binance Demo can expire historical order lookup before our durable
            # journal expires. Preserve the journal and let the forward engine
            # reconcile against current exchange exposure instead of generating
            # an endless exception loop.
            if exc.code == -2013:
                return {"resolved": False, "status": "ORDER_NOT_FOUND", "pending": pending}
            raise
        if not isinstance(result, dict) or result.get("clientOrderId") != pending["client_order_id"]:
            raise FuturesTestnetExecutionError("Futures forward order identity mismatch")
        status = str(result.get("status", ""))
        if status in {"NEW", "PARTIALLY_FILLED"}:
            return {"resolved": False, "status": status, "pending": pending}
        if status not in {"FILLED", "CANCELED", "EXPIRED", "REJECTED", "EXPIRED_IN_MATCH"}:
            raise FuturesTestnetExecutionError("Unknown Futures forward order state")
        if status != "FILLED":
            self.ledger.set_setting("forward_pending_order", None)
        return {"resolved": True, "status": status, "pending": pending, "order": result}

    def _execution_price(self, order: dict, symbol: str) -> Decimal:
        """Resolve a filled order price without resubmitting the order."""
        for candidate in (order,):
            avg = _decimal(candidate.get("avgPrice", "0"))
            if avg > 0:
                return avg
            qty = _decimal(candidate.get("executedQty", "0"))
            quote = _decimal(candidate.get("cumQuote", "0"))
            if qty > 0 and quote > 0:
                return quote / qty
        client_id = str(order.get("clientOrderId") or "")
        if not client_id:
            raise FuturesTestnetExecutionError("Futures Testnet close missing order identity")
        queried = signed_request("GET", "/fapi/v1/order", {
            "symbol": symbol,
            "origClientOrderId": client_id,
        })
        if not isinstance(queried, dict) or queried.get("clientOrderId") != client_id:
            raise FuturesTestnetExecutionError("Futures Testnet order identity mismatch")
        avg = _decimal(queried.get("avgPrice", "0"))
        if avg > 0:
            return avg
        qty = _decimal(queried.get("executedQty", "0"))
        quote = _decimal(queried.get("cumQuote", "0"))
        if qty > 0 and quote > 0:
            return quote / qty
        raise FuturesTestnetExecutionError("Futures Testnet close missing execution price")

    def reconcile_pending(self) -> dict | None:
        pending = self.ledger.setting("pending_order")
        if not pending:
            return None
        result = self._query_order(pending)
        status = str(result.get("status", ""))
        if status in {"NEW", "PARTIALLY_FILLED"}:
            return {"resolved": False, "status": status, "phase": pending["phase"]}
        if status not in {"FILLED", "CANCELED", "EXPIRED", "REJECTED", "EXPIRED_IN_MATCH"}:
            raise FuturesTestnetExecutionError("Unknown Futures Testnet order state")
        self.ledger.set_setting("pending_order", None)
        return {"resolved": True, "status": status, "phase": pending["phase"]}

    def recover(self) -> dict:
        """Resolve a prior smoke write and flatten only its recorded symbol."""
        pending = self.ledger.setting("pending_order")
        pending_result = self.reconcile_pending() if pending else None
        if pending_result and not pending_result["resolved"]:
            return {"ok": False, "pending": True, **pending_result, "live_enabled": False}

        latest = self.ledger.latest()
        if not latest or latest.get("status") == "COMPLETED":
            return {"ok": True, "pending": False, "position_closed": True, "message": "No Futures recovery required", "live_enabled": False}
        symbol = str(latest["symbol"])
        rows = self._position_rows(symbol)
        if not rows:
            self.ledger.set_status(int(latest["id"]), "RECOVERED_FLAT")
            return {"ok": True, "pending": False, "position_closed": True, "symbol": symbol, "live_enabled": False}
        if len(rows) != 1:
            raise FuturesTestnetExecutionError("Futures recovery found ambiguous positions")
        row = rows[0]
        amount = _decimal(row.get("positionAmt", "0"))
        if amount == 0:
            self.ledger.set_status(int(latest["id"]), "RECOVERED_FLAT")
            return {"ok": True, "pending": False, "position_closed": True, "symbol": symbol, "live_enabled": False}
        expected_direction = str(latest.get("direction", ""))
        expected_sign = 1 if expected_direction == "LONG" else -1
        actual_sign = 1 if amount > 0 else -1
        if actual_sign != expected_sign:
            raise FuturesTestnetExecutionError("Futures recovery direction mismatch")
        if int(float(row.get("leverage", 0) or 0)) != int(latest.get("leverage", 0)):
            raise FuturesTestnetExecutionError("Futures recovery leverage mismatch")
        if str(row.get("marginType", "")).lower() != "isolated":
            raise FuturesTestnetExecutionError("Futures recovery margin type mismatch")
        side = "SELL" if amount > 0 else "BUY"
        result = self._submit(
            run_id=int(latest["id"]), phase="RECOVERY_CLOSE", symbol=symbol, side=side,
            quantity=abs(amount), reduce_only=True,
        )
        if self._position_rows(symbol):
            raise FuturesTestnetExecutionError("Futures recovery close left an open position")
        self.ledger.set_status(int(latest["id"]), "RECOVERED")
        return {
            "ok": True,
            "pending": False,
            "position_closed": True,
            "symbol": symbol,
            "close_order_id": result.get("orderId"),
            "live_enabled": False,
        }

    def smoke(self, *, direction: str, leverage: int, symbol: str | None = None) -> dict:
        direction = direction.upper()
        if direction not in {"LONG", "SHORT"}:
            raise ValueError("Futures Testnet direction must be LONG or SHORT")
        if leverage not in {1, 2, 3} or leverage > self.settings.max_leverage:
            raise ValueError("Futures Testnet leverage must be 1x, 2x or 3x")
        if not self.settings.enabled:
            raise ValueError("Futures Testnet lab is disabled")
        if symbol is not None:
            symbol = symbol.upper()
            if symbol not in self.SYMBOLS:
                raise ValueError(f"Unsupported Futures Testnet smoke symbol: {symbol}")
        if self.ledger.setting("pending_order"):
            raise FuturesTestnetExecutionError("Futures Testnet recovery required")
        latest = self.ledger.latest()
        if latest and latest.get("status") not in {"COMPLETED", "RECOVERED", "RECOVERED_FLAT"}:
            raise FuturesTestnetExecutionError("Futures Testnet recovery required")

        account = self._account()
        if not self._trade_probe():
            raise FuturesTestnetExecutionError("Futures Demo trade permission probe failed")
        available = _decimal(account.get("availableBalance", "0"))
        margin = Decimal(str(self.settings.smoke_margin_usdt))
        if available < margin * Decimal("1.25"):
            raise FuturesTestnetExecutionError("Insufficient Futures Testnet margin")

        occupied = {row.get("symbol") for row in self._position_rows()}
        if symbol is not None:
            if symbol in occupied:
                raise FuturesTestnetExecutionError(f"Futures Testnet symbol already has an open position: {symbol}")
        else:
            symbol = next((candidate for candidate in self.SYMBOLS if candidate not in occupied), None)
            if symbol is None:
                raise FuturesTestnetExecutionError("No isolated Futures Testnet symbol available")

        self._configure(symbol, leverage)
        quantity = self._validate_smoke_quantity(symbol, direction)
        funding = None
        run_id = self.ledger.start(symbol, direction, leverage, self.settings.margin_type)
        open_side = "BUY" if direction == "LONG" else "SELL"
        close_side = "SELL" if direction == "LONG" else "BUY"
        try:
            opened = self._submit(
                run_id=run_id, phase="OPEN", symbol=symbol, side=open_side,
                quantity=quantity, reduce_only=False,
            )
            rows = self._position_rows(symbol)
            if len(rows) != 1:
                raise FuturesTestnetExecutionError("Futures Testnet open position not found")
            position = rows[0]
            amount = _decimal(position.get("positionAmt", "0"))
            if (direction == "LONG" and amount <= 0) or (direction == "SHORT" and amount >= 0):
                raise FuturesTestnetExecutionError("Futures Testnet position direction mismatch")
            actual_qty = abs(amount)
            entry = _decimal(position.get("entryPrice", opened.get("avgPrice", "0")))
            liquidation_raw = _decimal(position.get("liquidationPrice", "0"))
            liquidation = float(liquidation_raw) if liquidation_raw > 0 else None

            closed = self._submit(
                run_id=run_id, phase="CLOSE", symbol=symbol, side=close_side,
                quantity=actual_qty, reduce_only=True,
            )
            remaining = self._position_rows(symbol)
            if remaining:
                raise FuturesTestnetExecutionError("Futures Testnet smoke close left an open position")
            exit_price = self._execution_price(closed, symbol)
            self.ledger.finish(
                run_id,
                quantity=float(actual_qty),
                entry_price=float(entry),
                exit_price=float(exit_price),
                liquidation_price=liquidation,
                funding_rate=funding,
            )
            return {
                "ok": True,
                "symbol": symbol,
                "direction": direction,
                "leverage": leverage,
                "margin_type": "ISOLATED",
                "position_mode": "ONE_WAY",
                "margin_usdt": float((actual_qty * entry) / Decimal(leverage)),
                "position_notional_usdt": float(actual_qty * entry),
                "quantity": float(actual_qty),
                "entry_price": float(entry),
                "exit_price": float(exit_price),
                "liquidation_price": liquidation,
                "funding_rate": funding,
                "position_closed": True,
                "live_enabled": False,
            }
        except Exception:
            self.ledger.fail(run_id)
            raise
