"""Explicit bridge to an existing trading install; never constructs a trading engine."""
import argparse
import json
import os
import subprocess
import sys
import time
import tomllib
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from trader.config import load_config
from trader.remote_agent import RemoteAgent
from trader.remote_jobs import RemoteJobs
from trader.remote_paper_controls import RemotePaperControls
from trader.live_runtime_gate import (require_runtime_mode,runtime_mode_allowed,
    LIVE_SPOT_DATABASE,LIVE_SPOT_KILL)


SUPERVISOR_MODULES = (
    "scripts/windows_agent.py",
    "scripts/remote_job.py",
    "trader/config.py",
    "trader/remote_agent.py",
    "trader/remote_jobs.py",
    "trader/remote_paper_controls.py",
    "trader/update_manager.py",
    "trader/update_supervisor.py",
    "trader/native_protection_compat.py",
    "trader/runtime.py",
    "trader/runtime_control.py",
    "trader/live_runtime_gate.py",
    "trader/live_authorization.py",
    "trader/local_protection.py",
    "trader/central_admission.py",
)


def supervisor_modules_current(source):
    """Require the independent supervisor to match signed installed modules."""
    journal = ROOT / 'data/remote-updates/journal.json'
    if not journal.is_file():
        return False
    try:
        record = json.loads(journal.read_text(encoding='utf-8'))
        files = record.get('files') or {}
        version = tomllib.loads((source/'pyproject.toml').read_text(encoding='utf-8'))['project']['version']
        if record.get('phase') != 'committed' or record.get('version') != version:
            return False
        import hashlib
        for name in SUPERVISOR_MODULES:
            expected = files.get(name)
            local = ROOT / name
            source_file = source / name
            if (not isinstance(expected, str) or not local.is_file() or not source_file.is_file()
                    or hashlib.sha256(source_file.read_bytes()).hexdigest() != expected
                    or hashlib.sha256(local.read_bytes()).hexdigest() != expected):
                return False
        return True
    except (OSError, ValueError, KeyError, json.JSONDecodeError, tomllib.TOMLDecodeError):
        return False


def source_settings(source):
    source = Path(source).resolve(strict=True)
    raw = tomllib.loads((source / "config.toml").read_text(encoding="utf-8"))
    require_runtime_mode(source,raw["bot"]["mode"].lower(),require_ready=False)
    def confined(value):
        path = (source / value).resolve()
        if not path.is_relative_to(source) or path == source:
            raise ValueError("Source paths must remain within the selected installation")
        return path
    kill = confined(raw["bot"]["kill_switch_path"])
    config = load_config(source / "config.toml")
    model = str(raw["ai"]["model"])
    execution_mode = str(raw["bot"]["mode"]).lower()
    # Read only non-secret overrides; never import source API credentials.
    for name in (".env.local", ".env"):
        file = source / name
        if not file.is_file():
            continue
        rows = file.read_text(encoding="utf-8").splitlines()
        found_model = next((line.split("=", 1)[1].strip().strip('"\'') for line in rows
                            if line.split("=", 1)[0].strip() == "OPENAI_MODEL" and "=" in line), None)
        found_mode = next((line.split("=", 1)[1].strip().strip('"\'').lower() for line in rows
                           if line.split("=", 1)[0].strip() == "EXECUTION_MODE" and "=" in line), None)
        if found_model:
            model = found_model
        if found_mode:
            execution_mode = found_mode
        if found_model or found_mode:
            break
    require_runtime_mode(source,execution_mode,require_ready=False)
    database_setting = (LIVE_SPOT_DATABASE if execution_mode=='live' else
        raw["bot"].get("testnet_database_path", "data/testnet-trader.db")
        if execution_mode == "testnet" else raw["bot"]["database_path"])
    if execution_mode=='live': kill=confined(LIVE_SPOT_KILL)
    database = confined(database_setting)
    if not database.is_file():
        raise ValueError("Existing active database required; no database will be created")
    return replace(config, bot=replace(config.bot, mode=execution_mode, database_path=database, kill_switch_path=kill),
                   ai=replace(config.ai, model=model))


def dashboard_from_source(source, config):
    """Read current installed trading code in an isolated process.

    The supervisor is intentionally separate from the bot, so importing its
    own dashboard forever would leave financial projections on an old schema.
    No child engine is constructed or started by the export script.
    """
    source = Path(source).resolve(strict=True)
    script = source / 'scripts/export_paper_snapshot.py'
    if not script.is_file():
        raise FileNotFoundError('Trading projection exporter unavailable')
    if not script.resolve().is_relative_to(source):
        raise ValueError('Trading projection escaped installation')
    python = Path(sys.executable)
    if python.name.lower() == 'pythonw.exe':
        python = python.with_name('python.exe')
    if not python.is_file():
        raise FileNotFoundError('Trading projection Python unavailable')
    result = subprocess.run(
        [str(python), '-I', '-B', str(script), '--source', str(source)],
        cwd=source, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL, timeout=15, check=False,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if result.returncode != 0 or len(result.stdout) > 480_000:
        raise RuntimeError('Trading projection unavailable')
    payload = json.loads(result.stdout)
    if (not isinstance(payload, dict) or not isinstance(payload.get('status'), dict)
            or not runtime_mode_allowed(source,str(payload['status'].get('mode','')).lower())):
        raise ValueError('Trading projection invalid')
    return payload


def recover_updates(source):
    # Recovery is opt-in and precedes reading a possibly migrated database.
    channel = ROOT/'data/trusted-release.json'
    recovery_record = ROOT/'data/remote-updates/supervisor.json'
    if channel.is_file() and recovery_record.is_file():
        settings = json.loads(channel.read_text())
        record = json.loads(recovery_record.read_text())
        if record.get('phase') == 'bootstrap_rolled_back':
            print('Initial update rolled back; legacy startup requires owner review')
            return
        if settings.get('supervised_install_enabled') is True and source.resolve() != ROOT:
            recovered = {'status': record.get('phase')}
            if record.get('phase') not in {'completed', 'rolled_back'}:
                from trader.update_manager import UpdateManager
                from trader.update_supervisor import UpdateSupervisor
                recovered = UpdateSupervisor(UpdateManager(source, ROOT/'data/trusted-update.pub',
                                                           state_dir=ROOT/'data/remote-updates')).recover()
            if type(record.get('job_id')) is int and record['job_id'] > 0:
                completed = recovered['status'] == 'completed'
                jobs = RemoteJobs(ROOT, source)
                try:
                    jobs.finish(record['job_id'], 'completed' if completed else 'failed',
                        'Actualización recuperada y arranque comprobado' if completed else 'Actualización interrumpida; versión anterior restaurada')
                except (OSError, ValueError):
                    print('Recovered update; remote job acknowledgement unavailable')


def update_candidate(source):
    candidate = ROOT/'data/verified-release.json'
    channel = ROOT/'data/trusted-release.json'
    sequence = ROOT/'data/remote-updates/sequence.json'
    if not candidate.is_file() or not channel.is_file():
        return None
    value = json.loads(candidate.read_text())
    if value['expires'] <= time.time() or (sequence.exists() and value['sequence'] <= json.loads(sequence.read_text())['sequence']):
        return None
    value['enabled'] = (json.loads(channel.read_text()).get('supervised_install_enabled') is True
                        and (source/'trader/runtime_control.py').is_file()
                        and supervisor_modules_current(source))
    return value


def restore_candidate(source):
    channel = ROOT/'data/trusted-release.json'
    key = ROOT/'data/trusted-update.pub'
    if source.resolve() == ROOT or not channel.is_file() or not key.is_file():
        return None
    if json.loads(channel.read_text()).get('supervised_install_enabled') is not True:
        return None
    from trader.update_manager import UpdateManager
    from trader.update_supervisor import UpdateSupervisor
    return UpdateSupervisor(UpdateManager(source,key,state_dir=ROOT/'data/remote-updates')).available_restore()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--autostart", action="store_true")
    args = parser.parse_args()
    if not args.check:
        recover_updates(args.source)
    config = source_settings(args.source)
    production = json.loads((ROOT / "cloudflare/wrangler.production.json").read_text())
    values = dict(line.split("=", 1) for line in (ROOT / "cloudflare/.secrets/windows-agent.env").read_text().splitlines() if "=" in line)
    if values["PORTAL_ORIGIN"] != production["vars"]["PORTAL_ORIGIN"]:
        raise ValueError("Device destination differs from the deployed portal")
    state = ROOT / "data"
    agent = RemoteAgent(config, values["PORTAL_ORIGIN"], values["PORTAL_DEVICE_TOKEN"], state_directory=state)
    agent.config_provider = lambda: source_settings(args.source)
    agent.dashboard_provider = lambda: dashboard_from_source(args.source, agent.config)
    agent.jobs = RemoteJobs(ROOT,args.source)
    agent.paper_controls = RemotePaperControls(ROOT,args.source)
    agent.update_provider = lambda: update_candidate(args.source)
    agent.restore_provider = lambda: restore_candidate(args.source)
    agent.version_provider = lambda: tomllib.loads(
        (args.source / "pyproject.toml").read_text(encoding="utf-8")
    )["project"]["version"]
    snapshot = agent.snapshot()
    if args.check:
        print(json.dumps({"mode": snapshot["mode"], "database_readable": True,
                          "last_cycle_at": snapshot["last_cycle_at"], "engine_started": False}))
        return
    state.mkdir(parents=True, exist_ok=True)
    if args.autostart:
        (state / "REMOTE_STOP").unlink(missing_ok=True)
    def validate():
        raw = tomllib.loads((args.source / "config.toml").read_text(encoding="utf-8"))
        refreshed = source_settings(args.source)
        expected_database = (LIVE_SPOT_DATABASE if refreshed.bot.mode=='live' else
            raw["bot"].get("testnet_database_path", "data/testnet-trader.db") if refreshed.bot.mode == "testnet" else raw["bot"]["database_path"])
        expected_kill=LIVE_SPOT_KILL if refreshed.bot.mode=='live' else raw["bot"]["kill_switch_path"]
        if ((args.source / expected_database).resolve() != refreshed.bot.database_path
                or (args.source / expected_kill).resolve() != refreshed.bot.kill_switch_path):
            raise ValueError("Source paths changed; restart after review")
    last_success = None
    def report(ok):
        nonlocal last_success
        if ok:
            last_success = time.time()
        temporary = state / "remote-status.tmp"
        temporary.write_text(json.dumps({"pid": os.getpid(), "at": time.time(), "last_success": last_success,
                                         "sync_ok": ok, "error_type": agent.last_error, "mode": agent.config.bot.mode.upper(), "engine_started": False}))
        temporary.replace(state / "remote-status.json")
    agent.run(stop=lambda: (state / "REMOTE_STOP").exists(), validate=validate, report=report)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        # No traceback containing server bodies, tokens or request headers.
        print("Remote agent stopped: " + type(error).__name__, file=sys.stderr)
        raise SystemExit(1)
