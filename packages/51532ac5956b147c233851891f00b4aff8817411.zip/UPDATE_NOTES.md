Validación local final27Oct2026: **1573/1573 Python offline PASS**, cero fallos,
errores u omisiones; fuentes inalteradas durante ejecución, red externa bloqueada.
**294/294 Node PASS**; Windows5.1 lifecycle, entrada protegida y vista/render
sintéticos PASS. Build compartido, sintaxis y versión55→56 PASS; paquete308
archivos permitidos. CI, firma e instalación requieren sus propias evidencias.

## 27 octubre 2026 — candidata 0.10.56; base 0.10.55 verificada

Main `d78b7ee882236bfbdac14047662abe9ad7154e03`, [PR132](https://github.com/jlboper/Crypto-BOT/pull/132),
[publicación40400621712](https://github.com/jlboper/Crypto-BOT/actions/runs/40400621712)
y seguridad40400621700 SUCCESS Linux/Windows. Base55 firmada e instalada294/294.
56 añade enlace opcional de identidades/permisos GET, invalidación y caducidad de
evidencia de claves, ingesta financiera segregada, productor de señales nativas
y adaptador al coordinador, y preparación de política exclusivamente inactiva.
Ver [validación y límites56](PREPRODUCTION_VALIDATION_56.md). No confundir pruebas
con Binance simulado con una integración LIVE comisionada. El guard del motor
sigue bloqueando LIVE antes de crear wallet. No cambia Testnet, riesgo, stops,
IA individual ni datos financieros. GuardianL0; Pulse/Quant SHADOW. Aprobación del
borrador numérico no equivale a activación. CI/firma/instalación56 requieren
resultados propios; las secciones siguientes son historia fechada.

## 0.10.55 — entrada protegida y auditor de conexión (en preparación)

La entrada local system-generated HMAC64 rechaza pegados incompletos/duplicados
antes de escribir, ofrece cuatro intentos y cancela con entrada vacía. El fallback
de eco se bloquea. Un lock exclusivo propio del vault cubre lectura actualizada,
fusión por ámbito y escritura atómica; la espera del usuario ocurre fuera del lock.
Reemplazar un ámbito exige indicación explícita y conserva el otro.

Windows añade un acceso local desde Acciones rápidas/bandeja. Usa el runtime del
supervisor y el inventario de entrada COMMITTED del instalador firmado, consola
cmd /D /V:OFF, sin perfiles PowerShell, secretos en argv o arranque del motor.
El auditor --scope rechaza ámbitos no configurados antes de archivos o red.
Los errores conservan sólo estados HTTP y códigos de proveedor numéricos acotados;
no mensajes, cabeceras o URLs firmadas. El cuerpo de error es acotado y se cierra,
sin introducir reintentos. Para transferencias, sólo {"total":0} exacto equivale a
una ventana vacía; contradicciones permanecen UNKNOWN. No es historial integral.

No cambia trading, estrategias, stops, límites, balances, cohortes, actualizador
ni autoridad. Pulse/Quant SHADOW, GuardianL0. Pruebas/CI/firma/instalación pendientes.


## 0.10.53 — auditor GET compatible con Futures Account V3

La verificación instalada52 detectó una exigencia incorrecta de canTrade en
Futures V3, cuyo contrato financiero omite ese campo. Ahora el auditor exige
localmente dict sin forma de error, totales numéricos finitos y listas assets/
positions; canTrade opcional debe ser bool si aparece. Son criterios conservadores
de observación, no campos obligatorios publicados ni certificación de permisos.
Spot sigue exigiendo bool. Nuevos fixtures cubren contrato V3 y errores mezclados.
No añade endpoints, claves, IA, ejecución, riesgo o UI. La cache52 conserva su
corte parcial hasta una nueva auditoría explícita. Base52 verificada255/255;
pruebas/publicación53 requieren resultados propios.

Validación local53:1210/1210Python offline PASS208.359s y280/280Node PASS60.317s,
sin skips. Primeros ensayos enfocado/Node en sandbox fallaron por permisosTEMP;
se repitieron con runtime/temporales aislados, sin cambiar pruebas o lógica para
ocultarlo. Revisión independiente focalizada sin bloqueantes. CI/rollout pendientes.

## Corrección de validación Windows de la candidata52

Los primeros workflowsPR39986314395/39986314399 no pasaron Windows: una prueba
nueva comparaba el alias8.3RUNNER~1 con la ruta canónica; un job agotó el margen
fixture de3s del supervisor y otro registró FAILED en una receta previa sin
diagnóstico suficiente para atribuir su causa exacta. Linux pasó. No se integró.

Se normaliza sólo la expectativa de rutas y se amplía a10s sólo el arranque de
fixtures sintéticos Windows; supervisor operativo/protecciones sin cambios.
Un repro independiente retuvo un writerSIM400ms y falló con database locked
al presupuesto250ms. Ahora SQLiteSIM espera máximo5s antes de la transacción,
conservando comprobaciones de frescura/expiry dentro del lock y sin reintentos
de exchange. Otra regresión verifica que agotar la espera no crea reserva ni
entrada de journal.132pruebas relacionadas PASS23.158s y16supervisorPASS19.952s.
La suite completa y CI del nuevo head requieren comprobación nueva.

## 0.10.52 — auditoría de transición en preparación

Base main51 `f90f311f53a7c6f338b079f1d37b64bf4cd58459`,
[PR128](https://github.com/jlboper/Crypto-BOT/pull/128). Workflows39903537643
y39903537657 SUCCESS Linux/Windows. Corte23Oct15:51UTC: Ed25519 válida,
237/237 hashes, journal COMMITTED, runtime RUNNING, mismo motor18436/agente25008,
HTTPS correcto; Spot2/Futures3 ARMED. Son observaciones fechadas.

La candidata52 implementa auditoría GET Testnet/Demo explícita, protocolo conjunto
riesgo+capital exclusivamente SIM, bloqueos durables de pérdidas SIM, hipótesis
de capital Spot/Futures y validación de recibos prospectivos, más informe plegable
compartido. Ver [MIGRATION_AUDIT.md](MIGRATION_AUDIT.md). No cambia admisión, riesgo,
IA individual, protección, cuentas o trading de los motores. Guardian LEVEL0;
Pulse/Quant SHADOW. LIVE/control/reservas efectivas/promoción permanecen bloqueados.

No une wallets ni deduce30d certificados. Flow y latches aún tienen almacenes
independientes; no hay captura/registro durable de cohortes operativas ni
admisión conjunta de motores. Fuente de cuenta parcial, historia/cashflows y
validación operativa siguen pendientes. Pruebas, CI, publicación, firma e
instalación52 requieren evidencia propia. Las secciones siguientes son historia.


Validación local52 final:1205/1205Python offline PASS197.937s a23Oct16:18:23UTC,
280/280Node PASS58.945s, build compartido,diff-check yPowerShell5.1
lifecycle/view PASS. Primer Node detectó expectativa53plegables frentea55;
se actualizó la expectativa por el panel y detalle SIM nuevos, sin relajar
validaciones. Dos revisores independientes corrigieron y comprobaron conflictos
idempotentes y binding nocional/principal. CI/firma/instalación52 aún pendientes.

## 0.10.51 — presentación de intervalos (en preparación)

Base main50 `df12f1d625503eed6e77ffc98ea50954ed97307a`,
[PR127](https://github.com/jlboper/Crypto-BOT/pull/127).
Publicación39707960453 y seguridad39707960358 SUCCESS en Linux/Windows.
A22Oct2026 01:57–01:59UTC: Ed25519válida,237/237hashes,COMMITTED/RUNNING,
único motor24484/agente22748,agente11/11 y dos HTTPS distintos correctos.
Spot8/Futures6 con14/14ARMED y cantidad desprotegida observada cero.
183170filas previas/11tablas,configuración,credenciales y settings congelados
preservados; Research archivado conserva hashes. Es una verificación fechada,
no captura atómica de toda cuenta Binance. Guardian LEVEL0, Pulse/Quant SHADOW.
Una respuesta GuardianIA ordinaria22Oct00:00UTC fue aceptada; la de01:00UTC
se rechazó por CAUTION_BOUNDS. No se forzaron llamadas ni se relajaron validadores.

La candidata51 corrige exclusivamente la representación de días de observación:
máximo dos decimales, truncados para evitar mostrar30 cuando el intervalo aún es
29.999. Conserva valor original,umbral,contrato,fuentes,gates,límites y protecciones.
No activa modos financieros. PR/CI/firma/instalación51 requieren comprobación propia.

Validación local final51:1099/1099Python offline PASS193.141s a22Oct02:08:53UTC,
263/263Node PASS43.290s,build compartido ydiff-checkPASS. La prueba de frontera
se actualiza de29.999bruto a29.99visual conservando el dato original y su bloqueo.
No se relajan validadores ni se modifican decisiones. CI/publicación/instalación51
requieren evidencia nueva;50 permanece la última instalación comprobada aquí.

# 0.10.50 — Preparación verificable de migración (candidata)

## Checkpoint vigente — 0.10.49 instalada; preparación 0.10.50

La base confirmada es main `a3bd52b541868bce498107e9f6a19787db03bbbf`,
[PR126](https://github.com/jlboper/Crypto-BOT/pull/126).
[Publicación39615774170](https://github.com/jlboper/Crypto-BOT/actions/runs/39615774170)
y [seguridad39615774421](https://github.com/jlboper/Crypto-BOT/actions/runs/39615774421)
finalizaron correctamente en Linux y Windows. Corte21Oct2026 20:25–20:27UTC:
Ed25519 válida,229/229 archivos, journal COMMITTED, un motor5016/agente14328,
11/11 módulos del agente y dos sincronizaciones HTTPS distintas verificadas.
Spot8/Futures6 con8/8 y6/6 protecciones ARMED y cantidad desprotegida observada cero.
Pulse/Quant SHADOW; Guardian LEVEL0 sin autoridad. Es una observación fechada.
Las172972 filas previas de11 tablas conservaron cero cambios o ausencias;
configuración, credenciales y settings preservaron hashes. No es una captura
atómica de toda la cuenta Binance. Research21Oct13:50UTC COMPLETED permanece archivado.

La candidata50 prepara evaluación RO de migración y viabilidad de costes SIM.
No habilita LIVE ni programa activación a30 días. Capital propuesto por el dueño
no significa fondos asignados; pérdida diaria, drawdown, ámbito de motores,
cuenta, reconciliación y autorización final se validan por separado.
Los spans legacy no son cohortes continuas certificadas. Pulse/Quant necesitan
su propia evidencia y el protocolo común de capital sigue sin admisión efectiva.
La alerta Futures de riesgo inclusivo observado9.308 frente al límite7.5USDT
no se resuelve elevando topes. Ver [Preparación de migración](LIVE_MIGRATION_PREPARATION.md)
y [Auditoría de evidencia](LIVE_MIGRATION_EVIDENCE.md).
Pruebas, PR, CI, publicación, firma e instalación50 requieren comprobaciones nuevas.
Las secciones anteriores y posteriores de versiones previas son historia fechada.


## Validación local de la candidata50

Python offline final: **1099/1099 PASS**,139.719s,22Oct2026 01:40:43UTC,
sin fallos, errores o skips; claves vacías, red externa bloqueada y ningún bot iniciado.
Node final: **262/262 PASS**,56.772s, incluidos autenticación/CSRF, Worker/D1,
contrato compartido cerrado, rechazo de autoridad y compatibilidad con snapshots
anteriores. PS5.1 lifecycle/vistas y build compartido PASS. La primera corrida
Node detectó una expectativa del test que preservaba -0 mientras JSON transmite0;
se corrigió la expectativa al formato transportado, sin cambiar datos financieros.

QA sintética: panel plegable en escritorio1265px y móvil360px; anchura documento
345/345 en móvil, cuatro tarjetas y propuesta explícita sin asignación. Detalle
abierto conservado al refrescar y repliegue por teclado comprobados. Sin APIs
externas, POST403 y ninguna instancia de TradingEngine. No acredita UI instalada
ni acceso de propietario remoto. CLI de costes ejecutada: una hipótesis compatible
y otra rechazada por mínimo nocional, ambas sin autoridad ni financiación conjunta.

Proyección candidata RO sobre instalación49 a21Oct20:55:16UTC:479577bytesASCII
y cuatro detalles recientes del observer59; conserva matrizResearch,Guardian,
CapitalLab,protecciones y preparación.205sentenciasSQLite,cero mutaciones y cero
llamadas a proveedores/IA; el harness evita constructorDDL y lockResearch, por lo
que no sustituye una petición HTTP real ni prueba de sincronización autenticada.

El propietario pidió preparar Spot y Futures con perfil algo más agresivo. Los
porcentajes sugeridos son un borrador privado; no hay aprobación de límites exactos
ni activación de dinero real. Pulse y Quant conservan sus validaciones separadas.
CI, publicación, firma e instalación50 permanecen pendientes a este checkpoint.

# 0.10.49 — Historial remoto adaptativo (en preparación;48 verificada)

**0.10.48 está publicada, firmada e instalada**: main
`0270057f59d67362a6cff2851d138e0cc765155d`,
[PR125](https://github.com/jlboper/Crypto-BOT/pull/125).
[Publicación39609237309](https://github.com/jlboper/Crypto-BOT/actions/runs/39609237309)
y [seguridad39609237234](https://github.com/jlboper/Crypto-BOT/actions/runs/39609237234)
aprobaron Linux y Windows. Entre21Oct2026 **13:41–13:44UTC** se verificaron Ed25519,
**228/228 archivos**, agente11/11 y dos sincronizaciones HTTPS correctas.
Las **172145 filas** de referencia conservaron cero ausencias/cambios;
configuración, credenciales y settings mantuvieron sus hashes. Son verificaciones
fechadas, no una captura global atómica ni prueba de todas las filas posteriores.

Research terminó **COMPLETED a13:50:14UTC**:24/30 activos Spot y15/15 Futures.
Seis activos Spot quedaron excluidos con categoría `ValueError`; no se atribuye
una causa específica que el informe no conserva. El nuevo archivo incluye matriz
de cuatro motores, replay Pulse acotado a1000 decisiones sin divergencias y
16/16 modelos Quant coincidentes en su muestra. El archivo previo del19Oct quedó
intacto. Metodología presente/replay coincidente no acreditan rentabilidad,
ejecución validada, ventaja OOS independiente o ganancias atribuibles a IA/Guardian.

Después del estudio se observó en48 una proyección remota de **474183 bytes**
con serialización ASCII predeterminada y **441792 bytes** de transporte que omitía
`opportunity_shadow`. La menor huella de transporte no aumenta el límite de
validación ni demuestra una caída del observador o de los motores.

La candidata49 prepara historial remoto adaptativo: probar de seis a cero registros
recientes y conservar el mayor prefijo que quepa, retirando primero el detalle más
antiguo. Mantiene **480000 bytes** como límite de serialización ASCII predeterminada.
Conserva sin recortar la base, `health`, `coverage`, `scopes`, permisos y
evidencia de protecciones. Si ni con cero detalles cabe, conserva la omisión
opcional reconocida; no fuerza una proyección inválida.

La UI diferencia cero registros en el journal de cero detalles incluidos en esa
proyección. El SQLite y el detalle habitual local no se recortan para reducir el
envío remoto. No cambian contratos públicos, APIs, autoridad, trading o riesgo.
Pulse/Quant permanecen SHADOW y Guardian LEVEL0, sin promociones o LIVE.

Validación local49: **1061/1061 Python offline PASS**198.282s,21Oct14:10:29UTC,
sin fallos/errores/skips, red externa bloqueada y bot no iniciado; **245/245 Node
PASS**90.126s, PS5.1 lifecycle/vistas, build/diff PASS. Nueve regresiones Python
y tres UI cubren prefijo máximo, límite exacto/Unicode, resumen sin detalle,
omisión inevitable, ausencia de mutaciones y distinción entre vacío/desconocido.
Probe RO secuencial14:05:22–23UTC:48omite el observer con474217bytes; candidata49
incluye3recientes de37 con479616bytes, misma matriz y protecciones,0SQLmutaciones.
No es sesión remota autenticada ni una captura global atómica. CI del head/main,
PR, publicación, firma e instalación49 aún requieren verificación propia.
Las secciones inferiores conservan historia.


# 0.10.48 — Estado Research en Windows (en preparación)

Base confirmada **0.10.47 publicada, firmada e instalada**, main
`216c8232e50903627ff541b52befdb8494cac4e8`, [PR124](https://github.com/jlboper/Crypto-BOT/pull/124).
[Publicación39532789868](https://github.com/jlboper/Crypto-BOT/actions/runs/39532789868)
y [seguridad39532789801](https://github.com/jlboper/Crypto-BOT/actions/runs/39532789801)
aprobaron Linux y Windows. Entre21Oct2026 **02:35–02:38UTC** se verificaron
Ed25519, **227/227 archivos**, agente **11/11** y dos sincronizaciones HTTPS
distintas correctas. Las **154485 filas** de referencia conservaron cero
ausencias/cambios. Spot5/Futures7 mantenían protecciones ARMED en ese corte;
son observaciones fechadas y no acreditan el estado actual de los motores.

El arranque real de Research a02:38UTC falló con `WinError5` al reemplazar
su JSON de estado. Se reprodujo un escenario con un lector sintético sin cambiar
ACL. La identidad del handle que originó el incidente operativo no se determinó.

La candidata48 usa temporales exclusivos por escritura en el mismo directorio,
flush/fsync y cierre antes del reemplazo. Sólo reintenta los errores Windows5/32/33:
hasta cinco reintentos, con **310ms de espera acumulada**; el tiempo de E/S se suma
a esa espera. Si persiste el error, conserva el JSON anterior. La limpieza se limita
al temporal de esa invocación; nunca borra el destino ni cambia permisos para
forzar el reemplazo. No modifica scheduler, IA, trading, riesgos o protecciones.

La matriz Research47 se adjunta sólo a un estudio nuevo completado. El informe
histórico del19Oct conserva la evidencia disponible entonces y no se enriquece
retrospectivamente con observaciones posteriores. Instalar47 no acredita que ese
nuevo estudio haya finalizado. Pulse/Quant siguen SHADOW y Guardian LEVEL0;
no se habilitan Control, reservas efectivas, promociones o LIVE.

Validación local48: **1052/1052 Python offline PASS**145.156s,21Oct13:26:59UTC,
sin fallos/errores/skips, red externa bloqueada y ningún bot iniciado;
**242/242 Node PASS**34.309s, PS5.1 lifecycle/vistas, build/diff PASS.
Diez regresiones nuevas incluyen un lector Windows real, fallos de serialización,
E/S, fsync y reemplazo, reintentos selectivos/acotados y escrituras concurrentes.
CI del head/main, PR, publicación, firma e instalación48 requieren verificación
propia y permanecen pendientes. Los bloques inferiores conservan historia.


# 0.10.47 — Trazabilidad, investigación y recuperación (en preparación)

- Hooks postcommit observan aperturas/cierres/parciales y conciliación GET con
  vínculo persistente exacto de posición. Nunca se libera por símbolo o TTL.
  Sin cambio de órdenes, cantidades, revisión IA individual, stops o límites.
- Metadatos internos conservan el DTO público; regresión con lector/escritor46
  congelado permite ignorar tablas nuevas y preserva terminales durante rollback.
- El presupuesto remoto se aplica después de la compatibilidad histórica; Guardian
  se calcula antes con marcas completas. Se conserva el tope480000 y evidencia
  de protecciones. Omisiones y fuentes antiguas siguen explícitas.
- Trece consultas locales RO citan observaciones, cortes y registros, separando
  exposición por entorno. Rechazo hipotético no equivale a veto ni pérdida evitada.
- Research agrega auditoría Quant causal acotada y matriz de cuatro motores:
  metodología no equivale a ejecución validada, comparabilidad/atribución UNKNOWN.
- Preparación Risk+Capital SIM usa políticas explícitas, enteros micro-USDT,
  estados objetivos y el protocolo transaccional previo; ningún hook financiero.
- Copias explícitas de ocho SQLite en directorios nuevos, manifiesto INCOMPLETE
  antes del trabajo, integridad/hash y protección contra sobrescrituras. No cambia
  updater, firma, antirretroceso ni restaura datos operativos.
- Validación local final:1042Python offline PASS142.563s/242Node PASS39.280s,
  PS5.1 lifecycle/vistas, build/diff/paquete227archivos PASS. CI del head/main,
  publicación, firma e instalación47 pendientes.
- Guardian IA: dos intentos ordinarios21Oct completados por el API pero rechazados
  localmente; se añade diagnóstico cerrado sin cambiar validador/schema/cuotas.
  Causa histórica específica y comentario aceptado siguen sin verificar.

# 0.10.46 — Recursos remotos de Opportunity Shadow (en preparación)

- [PR123](https://github.com/jlboper/Crypto-BOT/pull/123) inicial5199e23: CI de
  publicación39456257911 pasó, pero seguridad39456257900 falló en Windows por
  el deadline3s de un ensayo de45 transacciones SQLite,959 tests/1failure.
  No se integró ni se atribuye esa CI a correcciones posteriores.
- Observación auténtica45 a20:41:58UTC: cuatro registros nuevos (Spot y Pulse:
  intención+resultado), digests4/4válidos, hipótesis UNKNOWN, cero errores/descartes
  y tres latidos distintos. Futures/Quant aún sin entrada capturada al corte.
- Base instalada45, main5d08ca7/PR122, publicación39453869690 SUCCESS Linux/Windows;
  firma y207/207hashes verificados20Oct16:10UTC. Observer IDLE/FRESH, tres latidos,
  sin errores o entradas forzadas. Motores/protecciones preservados.
- Corrección confirmada por GET401 remoto: los dos scripts compartidos existían
  en el build pero faltaban en la lista cerrada de recursos estáticos del Worker.
  Se agregan exactamente `/opportunity-contract.js` y `/opportunity-ui.js`.
- Conserva CSP/no-store y autenticación/CSRF de APIs; sin abrir directorios,
  rutas financieras, credenciales o datos. Sin cambio de motores, riesgo o IA.
- Pruebas locales46:959 Python offline PASS (157.844s),223 Node PASS (44.546s),
  build/diff PASS. Regresión401 antes del fix,5/5 foco después. CI/rollout46
  pendientes;45 no acreditó el panel
  remoto nuevo aunque la proyección HTTPS y la UI local funcionaron.

# 0.10.45 — Opportunity & Capital Shadow (en preparación)

- Base instalada/publicada44: main `f79578360f7870321d29cb842966bac2a250dba5`,
  PR121, publicación39407655253 y seguridad39407655107 SUCCESS Linux/Windows.
  Ed25519/195hashes/11módulos/dos HTTPS verificados20Oct; datos previos preservados.
- Captura acotada de intención final Spot/Futures y entrada hipotética Pulse/Quant,
  más resultados exchange/commit separados. IDs nativos sólo persistidos como digest.
  Sin cambio de órdenes, filtros, sizing, AI Advisor individual o protecciones.
- Consumidor dentro del motor supervisado: cola64 sin espera, eventos≤4096bytes,
  SQLite separado append-only≤16MiB/100000registros, idempotencia, reinicio,
  divergencias latched, heartbeat y degradación sin bloquear motores.
- Aritmética Decimal: bruto sin netear patas, costes y riesgo nominal diferenciados,
  reservas exclusivamente hipotéticas. Datos/cuenta/baselines/límites incompletos
  mantienen UNKNOWN. FILLED no prueba commit ni protección; sin liberación por TTL.
  Cierres existentes aún sin hooks: no declarar reservas fieles a la cartera.
- Portal local/remoto/Windows compartido: tres nuevos plegables Guardian (50total),
  cobertura por motor, ámbitos separados y evidencia/tiempos/digests. Validador único
  Worker/navegador, opcional≤12000bytes, fallback acotado para Worker anterior.
  No rutas, botones financieros ni privilegios nuevos.
- Guardian IA: schema por assessment con enum de evidencias y límites de arrays;
  instrucciones de longitud coherentes con validador local intacto. Modelo, cuotas,
  cache/claims y diagnósticos sin cambios. Sin llamadas reales de desarrollo ni
  reset del2/2 de20Oct; aceptación real y causa de fallos históricos pendientes.
- Validación local:959 Python offline PASS (157.391s TEST_RESULTS),220 Node PASS
  (45.607s); foco posterior contrato+UI32 PASS (4.568s), PS5.1 lifecycle/vistas,
  build y diff PASS. QA sintética360/768/1366px sin overflow; no prueba instalación.
- Ver alcance, límites, conservación y validaciones actuales en
  [OPPORTUNITY_CAPITAL_SHADOW.md](OPPORTUNITY_CAPITAL_SHADOW.md).
  PR/main CI/publicación/firma/instalación45 no se infieren de pruebas locales.

# Registro histórico de preparación44 (la verificación posterior está en el handover)

# 0.10.44 — Capital Protocol Lab (en preparación)

- Base 43 main `e61dd2a6f617cd39e8bd1c69728dc6f63b800401`,
  [PR #120](https://github.com/jlboper/Crypto-BOT/pull/120), publicación 39254593562
  y seguridad 39254593565 SUCCESS. Firma e instalación **188/188** verificadas el
  2026-10-19 a las 12:53:08 UTC; Guardian con cuatro fuentes FRESH y tres replays
  MATCH a las 12:54:49 UTC. Datos/límites previos preservados, Spot 2/Futures 4
  ARMED, cantidad desprotegida cero y agente 11/11.
- Siete recetas SIM cerradas prueban reservas transaccionales, concurrencia,
  incertidumbre/reinicio, cancelación parcial, múltiples patas y déficit visible.
  CLI explícito, nuevos UUID/cuentas simuladas y libro entero micro-USDT separado.
- Research Lab compartido muestra JSON RO ≤8000 bytes. GET/sync no ejecuta recetas,
  crea wallets ni abre SQLite del laboratorio. Sin controles de capital o trading.
  Guardian continúa NOT_INTEGRATED; las cifras no se suman a cuentas de motores.
- Revisión corrigió terminal→UNKNOWN que revivía capital, balances anteriores a
  mutaciones y campos extra en checks. No se modifican motores, riesgo o updater.
  No es F3 runtime/common candidate adapter ni Global Risk Engine completo.
- Core/Lab/CLI integrados: 64 tests PASS (9.895 s); prototipos: 61 tests previos.
  Antes de compactar la UI: **850/850 Python offline (181.531 s en TEST_RESULTS,
  2026-10-19 13:19:52.904728 UTC), 202/202 Node (69.325 s)**, 84 pruebas UI enfocadas
  (13.643 s), PS5.1 lifecycle/vistas, build y diff PASS.
- [PR #121](https://github.com/jlboper/Crypto-BOT/pull/121) en draft, head
  `5138e51a1f37001629ac1420e3b0d7e48a439170`: CI 39259777367/39259777360 PASS.
  Compactación local posterior: 47 plegables, auditoría cerrada y ámbito/estados
  dentro del detalle de cada caso; fecha, LAB SIM y resultado visibles. Pruebas
  UI 84/84 (7.046 s) y diff PASS. QA visual PASS en preview sintético local a
  360/768/1366px, sin overflow, siete casos y detalles/teclado/auditoría correctos.
  Auditoría cerrada 42.53px frente a 815.9px; primer caso ~534px frente a 1215px.
  Full final tras compactar: **850/850 Python** (171.844 s en TEST_RESULTS,
  2026-10-19 17:56:01.749748 UTC; runner 171.835 s), **202/202 Node** (37.430 s),
  build y diff PASS, sin fallos/errores/skips. Nuevo head/CI final pendientes;
  no atribuir CI anterior a cambios nuevos ni QA de preview a instalación.
  Sin merge, publicación/firma ni instalación44.
- Auditoría RO 13:18:23 UTC: trades Spot del backup 43 80/80 y receipts 48/48 sin
  ausencias/cambios; SHA del backup intacto (`append-only-backup43-verification.json`).
  Updater 43 sólo respaldó Spot. Comparaciones anteriores de prefijos muestreados
  Futures/Pulse/Quant siguen válidas, pero no demuestran todas las filas pre-43;
  no existe backup 43 multiledger para esos motores.
  Véase CAPITAL_PROTOCOL_LAB.md para ejecución, límites y conservación de cohortes.

# 0.10.43 — Guardian RO WAL y prefiltrado IA (registro de preparación)

- Base main 42 `b1e065b1c4934eef80cf4a6d39c52bafa1abb5de`, PR #119.
  [Publicación 39181606398](https://github.com/jlboper/Crypto-BOT/actions/runs/39181606398)
  y [seguridad 39181606401](https://github.com/jlboper/Crypto-BOT/actions/runs/39181606401)
  SUCCESS. Ed25519, 188/188 hashes y cinco assets web verificados a 2026-10-19
  00:42:33 UTC; motor 3680, Spot 1/Futures 5 ARMED, cantidad desprotegida cero.
  Agente entonces 9/11. Refresco firmado verificado **00:54:20 UTC**: agente 21344,
  **11/11 módulos**, sync_ok y dos heartbeats recientes correctos; motor 3680 sin
  cambio, Spot 1/Futures 5 ARMED y cantidad desprotegida observada cero.
- Incidencia real de 42: Guardian PARTIAL, 0/4 fuentes válidas, todas UNKNOWN por
  WAL_SIDECARS_UNAVAILABLE. Journal real 1/replay MATCH. Un intento IA FAILED con
  usage/causa desconocidos; no se diagnostican cuota/créditos sin evidencia.
- Corrección prevista: SQLite mode=ro/query_only normal permite metadata WAL/SHM
  transitoria sin exigir sidecars permanentes ni efectuar DML financiero. Conserva
  frescura y causalidad; sin constructores, migraciones ni copia immutable antigua.
- Prefiltro determinista evita IA con todas las fuentes UNKNOWN. Diagnósticos
  seguros y acotados sin cuerpo del proveedor, headers arbitrarios o secretos.
  No cambia presupuestos IA, riesgos, capital, ejecución, stops ni conciliación.
- Pruebas previstas: DB/WAL financiero sin cambios, escritores concurrentes,
  retorno de fuentes reales y no-llamada IA sin evidencia suficiente. PR/main CI
  y publicación/firma/instalación 43 pendientes. El laboratorio Capital Protocol Lab
  sigue como prototipo sintético externo y no forma parte de este correctivo.
- Evidencia candidata43 00:47:04 UTC: backups SQLite RO temporales de cuatro
  esquemas reales leídos FRESH/completos, posiciones 1/5/1/0 y SIDEWAYS descriptivo,
  sin motor/proveedores/credenciales. Copias retiradas; no demuestra 43 instalada.
  Pruebas enfocadas captura/servicio 87 y no-IA con todas UNKNOWN 1 PASS.
- Validación local 43 adicional: **IA 35 PASS (6.961 s), Node 180/180 PASS
  (106.485 s)**, lifecycle/vistas Windows PowerShell 5.1, build y diff PASS.
  **777/777 Python offline PASS (238.609 s)**, sin fallos/errores/skips, red externa
  bloqueada y sin iniciar bot (`TEST_RESULTS.json`, 00:55:17 UTC). PR/CI/rollout
  siguen pendientes; pruebas locales no equivalen a instalación de 43.

# 0.10.42 — Guardian Intelligence Shadow (registro de preparación)

- F2 observacional dentro del proceso supervisado: captura explícita en sólo
  lectura de Spot/Futures/Pulse/Quant, sin constructores ni migraciones de sus
  ledgers. Inventarios parciales/antiguos/ausentes permanecen UNKNOWN, con tiempos
  por fuente; no se representa una captura global atómica.
- Informe determinista tipado ≤12 KB: proxy BTC de 60m con 61 cierres contiguos
  disponibles al corte, métricas Pulse de liquidez cuando son válidas, conflictos,
  límites existentes y códigos WOULD_REVIEW. Hipótesis descriptivas no calibradas;
  sin suma de capitales, hedge supuesto, correlación inventada o pérdidas evitadas.
- `guardian-shadow.db` independiente, evidencia congelada append-only, hashes,
  lease/recuperación y replay causal. Límite de almacenamiento degrada observación
  sin borrar historia financiera ni detener motores. No hay orden/veto/reserva.
- IA explicativa opcional con presupuesto propio autorizado: máximo dos intentos
  diarios, mínimo una hora, TTL histórico 900 s, entrada 4,096 bytes, salida 512
  tokens, respuesta 32 KB y timeout 8 s; requiere `ai.enabled`. Claims fallidos/
  inciertos sobreviven reinicios. Cache validada y ligada al assessment original;
  nunca modifica estados deterministas. No sustituye IA individual o protecciones.
- Tarifas estándar verificadas 2026-10-18 para el modelo existente gpt-6-luna:
  $0.10 entrada/$0.01 cache/$0.125 escritura cache/$0.50 salida por millón de tokens
  ([fuente oficial](https://developers.openai.com/api/docs/models/gpt-6-luna)).
  Reserva diaria estimada $0.01, no garantía de factura máxima. Usage incompleto
  deja costes desconocidos; pruebas sintéticas no acreditan una llamada real.
- Base 0.10.41 main `022fb9135d165d5c52f12b65aa9628ab8c1436af`, PR #118,
  publicada/firmada/instalada 178/178. CI/publicación 39134814222 y seguridad
  39134814202 exitosas; continuidad verificada 14:16:30 UTC, sin pérdidas/cambios
  en las filas financieras comparadas. Esa evidencia corresponde a 41.
- Ocho consultas locales cerradas de sólo lectura: resumen, régimen, riesgo por
  ámbito, conflictos, calidad, revisión original, límites y contrafactual UNKNOWN.
  Responden sobre assessment/corte y journal incluido, sin APIs, SQL ni tools.
  Historial de seis identidades sólo en la pestaña; no es auditoría durable.
  Consulta NL general de servidor/histórico, Capital Manager y Control pendientes.
- Suite completa: **767/767 Python offline (361.510 s), 180/180 Node (85.515 s)**,
  lifecycle/vistas Windows PowerShell 5.1, build del portal y diff aprobados.
  Regresiones cubren precisión UTC, metadatos numéricos y digest int/REAL sin
  relajar causalidad. Sólo fixtures, transporte y claves sintéticos.
- QA visual a 1366/360/768 px sin desbordamiento horizontal y un workspace Guardian;
  consultas de contrafactual permanecen desconocidas y citan IDs de journal reales.
  Base 41 verificada nuevamente 19:10 UTC: 178/178 hashes, motor 19240/agente 13056,
  Spot 1/Futures 9 ARMED y cantidad desprotegida observada cero. CI de PR/main,
  publicación/firma/instalación y operación de 42 siguen pendientes.

# 0.10.41 — Intelligent Trading Command Center (registro de preparación)

- Auditoría de los cuatro motores, Guardian Observer, revisión IA individual,
  reservas preparatorias, agente y flujo firmado. `COMMAND_CENTER_2_0.md` registra
  mapa, matriz de reutilización/riesgos, contratos tipados y fases 0–6.
- La fase 1 reorganiza el portal compartido en siete vistas y conserva identidad
  coherente en Windows. Portfolio & Capital usa datos existentes separados por
  entorno; Guardian AI muestra Observer y las funciones futuras pendientes.
  Conserva autenticación/CSRF y significado de controles actuales.
- No implementa Guardian Intelligence, Capital Manager, veto ni asignación.
  Presupuesto Guardian IA cero: no añade llamadas, modelos, servicios de pago,
  ejecución, cambios de riesgo o promoción. Spot conserva ALLOW/REJECT/REDUCE y
  Futures ALLOW/REJECT; cierres y conciliación no dependen de IA/Guardian.
- Base 0.10.40 main `81ba4366cf587c16cae20d403974a340080c4d10`, PR #117,
  firmada e instalada 178/178 hashes a las 02:27 UTC del 18 de octubre.
  Publicación 39089416208 y seguridad 39089416215 exitosas. Esa evidencia es
  del predecesor: pruebas/CI/publicación/firma/instalación de 41 se verifican aparte.

# 0.10.40 — Evidencia de minutos cerrados para StatArb (registro de preparación)

- La observación detectó que acumular snapshots no resolvía huecos de cadencia:
  el historial podía ser largo sin una ventana contigua suficiente. Quant solicita
  hasta 500 velas Spot cerradas de un minuto por BTC/ETH/SOL desde la API pública
  allowlisted, en lugar de interpolar o reconstruir snapshots perdidos.
- Las barras viven en un almacén separado append-only, con primera recepción
  real conservada. Los diagnósticos y replay sólo usan evidencia recibida antes
  del corte; una barra cerrada previamente no se atribuye retrospectivamente a
  una decisión anterior a su recepción. No se aceptan velas todavía abiertas.
- `premiumIndex` se obtiene en lote para conservar el presupuesto: 14 peticiones
  de arranque y 10 por refresco estable previsto, siempre bajo el máximo vigente
  de 15/minuto. No se amplían frescura, riesgo, capital, modos ni permisos.
- Son diagnósticos retrospectivos de barras cerradas recibidas durante la
  observación. No equivalen a forward/OOS, backtest validado ni ventaja probada;
  StatArb continúa sin entradas. Se conservan los huecos originales, decisiones,
  posiciones, journals, Guardian Observer y ejecución exclusiva SHADOW.
- Preparada desde main 0.10.39 `2328f2959dc9b4fb939e889519b59a19e5a58423`,
  verificada firmada e instalada 176/176 tras publicación 39070205949 y seguridad
  39070205944 exitosas. Agente 11/11; cuatro ticks Quant recientes, edad máxima
  observada 60.85 s. Esta evidencia es de 0.10.39. La 0.10.40 requiere suite completa,
  CI, publicación/firma e instalación propias antes de declararse disponible.

# 0.10.39 — Disponibilidad y diagnóstico de firma (registro de preparación)

- 0.10.38 main `a94f1124d57439e90620f4b2d5c02cbb07f53f58` superó CI,
  pero los intentos 1/2 de publicación fallaron con HTTP 403 y código
  `publisher_revision_unavailable`. No hay firma/instalación 0.10.38 verificada;
  continúa instalada la 0.10.37 con 176/176 hashes. La causa concreta del fallo
  de consulta GitHub todavía no está acreditada; no se atribuye a cuota sin evidencia.
- El firmante añade diagnóstico acotado y saneado de HTTP/límites de consulta,
  sin cuerpos ni credenciales. El publicador admite reintentos sólo de
  disponibilidad de revisión y propagación, conservando manifiesto y token OIDC
  exactos y un máximo acumulado de 105 s de espera entre intentos (siete
  solicitudes como máximo, cada una con timeout de 30 s).
- Cada intento vuelve a exigir OIDC válido, identidad/workflow autorizados,
  `main` actual exacto, revisión desplegada coincidente y controles de firma.
  Una revisión superada, identidad inválida u otro rechazo no se autoriza ni se
  convierte en disponibilidad transitoria. Se conserva la corrección de cadencia
  de 0.10.38 sin cambios de trading, riesgo, datos, UI o confianza de Windows.
- 0.10.39 está preparada; suite completa, CI, publicación, firma e instalación
  requieren evidencias propias. Un despliegue del portal o ZIP sin firma no
  demuestra una release instalable.

# 0.10.38 — Cadencia de referencias Quant (registro de preparación)

- La 0.10.37, main `3b02326c435acf3c9c666940a90923908e9bab64`, se verificó
  firmada e instalada con 176/176 hashes. La observación posterior detectó
  referencias antiguas intermitentes: programar desde el inicio del tick podía
  volver a consultar unos milisegundos antes de vencer la caché estricta de 60 s.
- Quant programa el siguiente tick 60 s después de completar el actual. Evita
  reutilizar accidentalmente esa respuesta antigua sin relajar la frescura de
  90 s, aumentar llamadas/API ni cambiar hipótesis, costes, riesgo o ejecución.
  Un proveedor lento o caído sigue produciendo datos parciales/antiguos explícitos.
- Se conservan el ledger/journal Quant, sus pausas y protecciones hipotéticas,
  Spot/Futures/Pulse, Guardian Observer y el flujo firmado de actualización.
  Suite completa, CI, publicación/firma e instalación de 0.10.38 aún pendientes.

# 0.10.37 — Quant Shadow funcional y evidencia de dos piernas (registro de preparación)

- Servicio Quant opcional dentro del proceso supervisado, ledger virtual SQLite,
  journal, fuentes contemporáneas, recuperación/idempotencia y pausa propia.
  Binance público BTC/ETH/SOL de referencia, sin claves, cuentas u órdenes.
- Funding Carry puede simular Spot LONG/Futures SHORT tras filtros de costes,
  liquidez, basis, timing, funding histórico, colateral y estrés. Dos piernas con
  comisiones/deslizamiento y fallo/unwind conservador; no cobertura atómica.
  Proyección condicional y asiento histórico `SETTLED_SIMULATION` son distintos;
  falta de eventos vencidos verificables deja equity/P&L/estadísticas desconocidos.
- Capital virtual inicial 1,000 USDT, hasta dos pares/cuatro piernas; riesgo
  estimado 0.25% y exposición 15% subordinados a límites globales. Bloqueos propios
  de nuevas entradas 1% diario/2% semanal, referencia primera equity válida del
  período UTC. Pausas y bloqueos conservan salidas protectoras hipotéticas.
- StatArb genera diagnósticos exploratorios y WAIT/REJECT; entradas bloqueadas
  hasta calibración independiente. Replay de fuentes congeladas limita el corte
  temporal, sin afirmar backtest válido, rentabilidad o evidencia OOS independiente.
- Portal compartido y Windows muestran Quant inicializado, pares/piernas, costes,
  funding, decisiones/journal y salud; valores actuales se ocultan con datos
  antiguos. Controles autenticados vía agente exigen capacidad Quant específica.
  Badge Windows corregido a cuatro bots. Guardian conserva Observer sin veto.
- Estrés de colateral virtual a 1x y coste conservador adicional no modelan la
  liquidación Binance ni garantizan fills intravela. No cambian riesgos Spot/Futures,
  credenciales o historiales previos. No se habilita ejecución Testnet/Demo/LIVE.
- Validación local completa: 611 pruebas Python offline y 138 Node aprobadas;
  lifecycle/vistas PowerShell 5.1, build compartido y diff-check también pasan.
  CI Linux-Windows, publicación/firma/instalación de esta versión siguen pendientes. La predecesora
  0.10.36 main `1bb77fad1a490472907ce29591e0b1075d3e7ba3` se verificó firmada e
  instalada 167/167; esa evidencia no sustituye la de 0.10.37.

# 0.10.34 — Diez activos, cinco fuentes y portal plegable

- Market Pulse observa BTC, ETH, BNB, XRP, SOL, TRX, ZEC, HYPE, DOGE y LINK.
  Selección fechada de capitalización CoinGecko cruzada con pares Spot USDT activos
  en Binance; sin stablecoins, duplicados ni activos sin par compatible. No es un
  ranking que se actualice silenciosamente. Spot y Futures conservan sus universos.
- Cinco RSS públicos: Ethereum Foundation, Bitcoin Core, Kraken, Federal Reserve
  y SEC; una petición por minuto en total, estados individuales y fallos aislados.
  Rumores, noticias antiguas/futuras, predicciones y promociones no confirman entradas.
  Contexto monetario se registra como MARKET, nunca como orden sobre un activo.
- Ordena candidatos por score, confianza y liquidez antes de asignar los tres slots
  hipotéticos existentes. La cola IA prioriza eventos prometedores, conserva el
  límite propio de seis intentos/día y nunca participa en cierres protectores.
- La expansión aditiva preserva ledger, posiciones y journal, registrando la
  transición de hipótesis; cambiar costos/riesgo sigue rechazado. SHADOW exclusivo.
- Secciones extensas plegables con teclado, navegación que abre la sección destino,
  preferencia local acotada y redibujo de gráficos al abrir. Resumen/estados/controles
  siguen visibles. Contrato remoto compatible hasta diez activos y cinco proveedores
  dentro de 20 KB, sin aumentar posiciones, exposición ni consumo de IA.

# 0.10.33 — Prueba de exclusión determinista

- La prueba de exclusión de observadores espera una señal del stream sintético,
  posterior a la adquisición del lease, antes de intentar reclamarlo con un segundo
  servicio. Elimina una carrera de planificación de hilos observada en CI Linux.
- No cambia código de producción, trading, riesgo, finanzas ni recuperación.
  Conserva la URL RSS oficial directa corregida en 0.10.32 y la interfaz de tres
  motores. La firma e instalación se verifican separadamente después de CI.

# 0.10.32 — Feed oficial directo de Ethereum

- La primera observación instalada de 0.10.31 detectó HTTP 301 en el feed de
  Ethereum Foundation. Se utiliza su destino oficial `/en/feed.xml` directamente;
  se mantiene el rechazo de redirecciones, timeout, límites y validación de origen.
- No cambia trading, riesgo, credenciales, bases financieras ni modos. Market Pulse
  continúa exclusivamente SHADOW dentro del mismo proceso supervisado.
- La 0.10.31 se publicó, verificó con Ed25519 e instaló con 160/160 hashes iguales;
  Spot y Futures conservaron posiciones y protecciones ARMED. La publicación e
  instalación de este ajuste requieren verificación independiente posterior.

# 0.10.31 — Tres motores y AI Market Pulse Shadow

- Portal compartido con tres tarjetas consistentes, siete secciones, panel Pulse
  de inteligencia/eventos/oportunidades/evidencia financiera/salud y navegación móvil.
- App Windows renovada con un resumen de los tres motores, entornos y frescura,
  posiciones/protecciones, rendimiento separado y accesos al panel Market Pulse.
  Las consultas locales se realizan en segundo plano; se preservan propiedad del
  indicador, watchdog, controles existentes y flujo firmado de actualización.
- Observador continuo Binance público BTC/ETH/SOL dentro del proceso supervisado,
  después de activación firmada. Ventanas 1/5m, indicadores reproducibles, gates de
  frescura/liquidez/costos, backoff, recuperación REST y ledger Shadow independiente.
- Feed oficial RSS limitado; clasificación determinista y revisión IA estructurada
  tras prefiltrado, cuota persistente seis/día, 300s entre intentos, sin reintentos.
  El propietario autorizó reutilizar la clave existente. No se crean suscripciones.
- Posiciones hipotéticas con stops/costos, riesgo estimado <=0.25% subordinado a
  límites existentes, protección independiente de IA y pausa, journal/replay de
  evidencia contemporánea. Ponderaciones son hipótesis; no hay backtest válido ni
  ventaja estadística demostrada ni promoción automática.
- Contrato remoto opcional acotado a 20KB con compatibilidad anterior; controles
  pausa/reanudación conservan autenticación y trabajos supervisados. Falla de Pulse
  no invalida Spot/Futures. Preparación de reservas compartidas sin conectar Spot.
- Se conservan riesgos Spot/Futures, datos, credenciales, firma, antirretroceso y
  rollback. La versión no admite ejecución Pulse PAPER/Testnet/LIVE. Pruebas y
  estados publicado/firmado/instalado se verifican por separado en la entrega.

# 0.10.30 — Planes de entrada consistentes y evaluación de las reglas actuales

- Spot conserva los porcentajes de stop/objetivo y la relación recompensa/riesgo al pasar del cierre al precio actual. Mantiene los límites originales de admisión hasta el preflight Testnet y escala el ATR inicial al fill; las posiciones existentes y sus protecciones no se reescriben. El journal conserva un signal compatible con la versión anterior y separa la observación original.
- Futures rechaza referencias fuera del stop/objetivo del cierre o de la propuesta revisada por IA, antes de abrir. Revalidar cantidad y presupuesto no revive una señal invalidada. No afecta conciliación ni cierres protectores; el portal explica el descarte.
- El laboratorio descarga Futures y mark en su propia temporalidad (1h); Spot sigue en 4h. Valida cadencia/duración, separa caches y conserva la cohorte anterior. El cambio de temporalidad reinicia solo Futures; nunca cuenta el antiguo 4h como observación nueva 1h.
- Añade referencias de señales y límites actuales de ambos bots. Futures comparte exactamente el cálculo operativo, con regresión de 56 casos; no se atribuye PnL a esta referencia de señales. La interfaz distingue temporalidades, reglas actuales y escenarios históricos.
- La auditoría y comparaciones de RSI/extensión no encontraron una alternativa con ventaja consistente después de costos. No se promueve una estrategia por una ventana favorable, ni se amplían exposición, leverage, score o permisos LIVE. El rendimiento futuro sigue sin demostrarse.

# 0.10.29 — Recuperación de pausas por reloj Futures Demo

- Una respuesta del reloj Demo de más de dos segundos dejó Futures pausado aunque después se confirmaran las protecciones. Los motivos exactos de reloj lento/no disponible ahora admiten la auditoría automática completa existente.
- Antes de reanudar se concilian journals, identidad/cantidad, modo/leverage, protecciones nativas, contratos sin exposición y cuenta. Una escritura pendiente, identidad incorrecta, protección sin confirmar, cuenta no disponible o pausa manual conserva el bloqueo.
- Se mantiene el rechazo de muestras de tiempo inválidas/lentas, el reloj monotónico anclado únicamente a Demo y la prohibición de reintentar escrituras firmadas. No cambian señales, umbrales, límites ni órdenes para producir actividad.
- Regresiones reproducen el error desde protección con posiciones abiertas y verifican todos los bloqueos de recuperación. Spot sigue evaluando 60 activos en 4h; su ausencia actual de entradas corresponde a señales bajo score 70.

# 0.10.28 — Protección Spot y continuidad remota

- GNS se compró y su OCO fue rechazado por PERCENT_PRICE_BY_SIDE. Ahora stop y objetivo redondeados se validan contra la referencia de Binance Testnet y las bandas SELL antes de comprar. Una referencia nula exige la ventana VWAP exacta. Los niveles no se recortan ni amplían para hacer pasar una orden.
- Un rechazo definitivo de banda puede repararse tras comprobar filtros, saldo e identidad de posición, con identidad nueva y un máximo de tres reparaciones. Una respuesta incierta conserva la identidad original y exige consulta. Un trailing inválido conserva la protección anterior. Las cantidades sin confirmación se muestran sin protección, corrigiendo el falso cero.
- El historial Futures superó 80.000 caracteres y provocó HTTP 400. El portal acepta hasta 120.000 para el exportador anterior; el nuevo reduce solo filas históricas de la vista a menos de 72.000. Conserva posiciones, protecciones, pausas y totales; SQLite permanece completo. Si el portal rechaza esa proyección opcional, el agente conserva heartbeat autenticado y actualizaciones e informa degradación.
- La pausa automática por una respuesta incierta de lectura Futures se recupera solo después de conciliar journals, identidad/exposición, configuración, protecciones y cuenta. Las pausas manuales y escrituras pendientes siguen bloqueadas.
- Se conservan diez cupos, presupuestos, apalancamiento, estrategias, credenciales y datos financieros. Regresiones reproducen la banda GNS, el rechazo tras compra, trailing, intentos limitados, historial Python→Worker, fallback y recuperación segura.

# 0.10.27 — Diez posiciones y conservación de las correcciones operativas

- Spot Testnet y Futures Demo admiten hasta diez posiciones cada uno. Se amplía el validador Futures de cinco a diez, limitado también al número de contratos configurados.
- Se conservan exposición Spot del 60%, riesgo por operación del 0,75%, límites de pérdida diarios/semanales y presupuestos Futures de 300 USDT de notional bruto y 7,5 USDT de pérdida estimada hasta stops. El dimensionamiento Futures existente distribuye las nuevas entradas a un objetivo de 30 USDT por cupo, sujeto a mínimos y presupuesto restante.
- Regresiones verifican el décimo cupo, el rechazo del undécimo, el presupuesto conservado y la proyección de límites. El contrato remoto acepta hasta diez posiciones Futures y conserva compatibilidad con snapshots anteriores.
- Consolida las correcciones locales ya instaladas entre el 8 y el 11 de octubre: contabilidad neta Futures con comisiones/funding, transporte de reloj, conciliación de protección nativa, rechazo previo a órdenes y diagnósticos resueltos. Conserva la cadencia Spot de cinco minutos y el universo de sesenta activos que usa la instalación actual, sin cambiar señales, stops, apalancamiento ni las estrategias activas. La actualización firmada no debe revertir estas correcciones al ampliar los cupos.

# 0.10.25 — Comparable evidence and current contract diagnostics

- Shared Spot/Futures scorecards now show account return, win rate/profit factor, expectancy and open P&L together, with separate net/gross labels, account windows, technical closes and cost-attribution limits.
- Futures last-cycle counters match the Spot presentation. A partial contract-data failure or stale cycle also degrades the headline/observation summary; high cycle coverage cannot imply full contract availability.
- Per-contract scores identify LONG/SHORT, timeframe and analysis date. Historical/undated scores no longer appear as current opportunities; current unavailable-contract reasons appear on the affected card.
- Aggregate Futures exposure/loss-to-stop budgets are visible in Limits. Fix the displayed Spot risk percentage for leve/moderado/alto using the same six-profile mapping as the description; execution limits are unchanged.
- Research failures retain a bounded, allowlisted diagnostic and safe stage instead of only an exception class. The portal dates the retained older report and identifies its actual Spot/Futures coverage. The previously observed generic ValueError is not assigned a cause without new execution evidence.
- Preserve strategies, thresholds, timeframes, leverage, signed rollout, journals, histories, exchange order handling and the LIVE prohibition. No database/schema or independent-agent dependency change.

# 0.10.24 — Recuperación automática de contratos Futures Demo

- Futures vuelve a validar en cada ciclo los contratos bloqueados; un fallo temporal no elimina permanentemente una moneda. Si Binance Demo vuelve a exponer filtros/configuración válidos, el contrato regresa automáticamente a READY.
- El sizing tolera un MARKET_LOT_SIZE incompleto usando LOT_SIZE únicamente cuando este último es internamente válido; /order/test sigue siendo la validación final antes de cualquier entrada.
- La referencia de entrada usa ticker del Demo y, si falta temporalmente, markPrice/indexPrice del mismo Binance Futures Demo. No mezcla precios de producción.
- El diagnóstico del portal identifica símbolo y causa exacta de cada BLOCKED / ASSET_UNAVAILABLE / NO_DATA, en vez de mostrar solo un contador genérico.
- No cambian score, timeframe, leverage, límites de cartera, stops, IA final ni bloqueo de LIVE.

# 0.10.23 — Más oportunidades observables con diagnóstico explícito

- Futures Demo conserva 15 contratos, hasta 5 posiciones, 300 USDT de notional bruto, 7.5 USDT de pérdida estimada hasta stops, ISOLATED y pruebas 1x/2x/3x sin multiplicar exposición. Cambia únicamente su cadencia de señal a 1h y el score mínimo de 75 a 70; Spot continúa en 4h.
- El portal ahora explica cada ciclo Futures: contratos evaluados, señales LONG/SHORT, revisiones IA, entradas y motivos de descarte o bloqueo. Entre cierres de velas muestra explícitamente que espera una nueva vela, en lugar de confundirlo con inactividad.
- Spot mantiene intactos sus límites diario/semanal. Cuando uno se activa, el portal muestra qué periodo bloquea, retorno observado, límite correspondiente y fecha/hora de expiración del bloqueo.
- La publicación automática de main validado preparada en 0.10.22 se conserva: PRs validan; publicación/firma solo desde el commit exacto de main tras Linux y Windows.

# 0.10.22 — Publicación automática de main validado

- Los PR ejecutan pruebas sin publicar. Tras integrarlos, el push de `main` valida nuevamente ese commit exacto en Linux/Windows y publica desde el entorno existente. Respeta cualquier revisión que el propietario vuelva a configurar.
- Scripts de despliegue/paquete y firmante OIDC admiten únicamente el push de main; rechazan identidades PR, cambios de SHA/ref y revisiones superadas por main. Se conserva firma Ed25519, inventario, secuencia, preflight de versión, migraciones, salud/rollback y rollout supervisado de Windows.
- El centro de actualizaciones describe la publicación automática y solo ofrece una revisión pendiente si ambas plataformas aprobaron la revisión actual. Se actualizan instrucciones permanentes y documentación para evitar volver al flujo PR con aprobación.
- Regresiones prueban rechazo de PRs, eventos manuales, otro repositorio/rama, sustitución de revisión, main avanzado y verificación no disponible. Motores, estrategias, límites, datos y dependencias del supervisor independiente conservan su comportamiento.

# 0.10.21 — Motivo del último ciclo Spot

- Spot muestra «Trabajando · sin oportunidades» cuando termina el análisis sin señales de compra. Distingue candidatas descartadas por IA/filtros/vela ya revisada, límites de entradas, pausa, límite de pérdida, entradas ejecutadas, datos o IA no disponibles y error operativo.
- Guarda un resumen del último ciclo con fecha, universo, monedas evaluadas, señales, candidatas, revisiones IA y entradas. Muestra score mínimo, régimen BTC y contadores de motivos permitidos; no copia mensajes privados o respuestas de proveedores.
- El panel local y remoto usan la misma proyección y diseño. Diagnósticos ausentes en instalaciones anteriores muestran «Sin detalle aún»; resultados antiguos o fallos de conexión muestran «Sin datos recientes». Un error reciente sigue visible aunque el último ciclo exitoso sea antiguo.
- El campo remoto es opcional para conservar compatibilidad con snapshots antiguos; el Worker valida estados, motivos y contadores acotados. Una prueba de contrato sincroniza las proyecciones producidas realmente por Python para todos los códigos y estados.
- Las reglas de señales, revisión IA, ejecución, protección y riesgo conservan su comportamiento. Las regresiones verifican rechazo versus fallo de IA, datos faltantes, presupuesto, deduplicación, pausa, pérdida, error/recuperación y una entrada PAPER completa con proyección de solo lectura.

# 0.10.20 — Laboratorio diario, carteras conjuntas y seguimiento futuro

- Ejecución automática cada 24 horas con Windows/app encendidos; botón «Actualizar análisis ahora» para adelantarla. Estado durable, última/próxima ejecución, progreso, exclusión mutua manual/diaria/remota/CLI, prioridad reducida y límite de duración. El análisis cede cooperativamente ante mantenimiento de actualizaciones y conserva el último informe completo.
- Hasta 30 activos Spot del universo público líquido y los 15 configurados de Futures, separados. Datos cerrados públicos, cache incremental, mark/funding históricos USD-M y activos sin datos identificados; jamás sustituir Futures por Spot ni missing funding por cero. Histórico público de referencia, no fills Demo.
- Carteras con un reloj, capital compartido, cinco posiciones, límites de riesgo/notional/exposición, LONG/SHORT en Futures y ejecución siguiente apertura. Stops primero, gaps, comisiones/slippage, funding y estrés de liquidación por mark. Tres perfiles simulados, con 1/2/3/5/10x en Futures (18 escenarios). Leverage cambia margen, no multiplica cantidades. Mantenimiento supuesto del 1%; sin calibración de brackets, estos resultados Futures no califican para promoción.
- Selección de modelos solo en entrenamiento inicial; desarrollo OOS separado de ventana final y costos ×2. Comparar escenarios no selecciona automáticamente al ganador. Se conservan las puertas previas Spot y Monte Carlo; las ilustraciones antiguas por ventanas se etiquetan como tales.
- Archivos completos de ejecuciones inmutables, hashes de datos, parámetros, curvas/netos/drawdowns/motivos de descarte. Portal local/remoto comparten proyección acotada, hasta doce ejecuciones recientes y las carteras conjuntas; cobertura de cierres usa los activos del último informe completo.
- Cohorte de observación futura con reglas congeladas: hasta cinco Spot y hasta quince Futures. Solo velas abiertas después del registro; días/cierres separados (excluye cierres artificiales de fin de ventana), resultados simulados y gaps visibles. Ninguna promoción automática ni cambio de órdenes, configuración de riesgo operacional, capital o LIVE.
- Trabajo remoto ejecuta el código instalado en un intérprete aislado nuevo; evita reutilizar el módulo de investigación del supervisor anterior. Inventarios de dependencias del supervisor permanecen iguales.

# 0.10.19 — Confirm completed updates without the previous config validator

- Update/install and restore jobs no longer parse trading settings through an already imported independent-supervisor validator. Research still uses the full configuration; signed staging, exact approval, runtime health and committed activation remain mandatory.
- After a successful install, validate the returned healthy status, exact release identity and staged version before recording completion. Restoration similarly requires its confirmed restore identity. Actual install failures continue to fail.
- Reproduced the previous 0.10.17 validator rejecting the signed fifteen-asset 0.10.18 configuration with `ValueError: Unsupported Futures forward symbol`. The former post-install `source_settings` call could therefore mark a healthy committed installation as failed.
- Regression tests exercise the real remote-job entry point with a stale validator, confirmed install/restore, real failure and mismatched completion identity. Both independent-agent dependency inventories remain unchanged and their isolated refresh/import regression passes.
- Authenticated portal audit observed installed 0.10.18, connected Windows, fifteen Futures assets/max five positions, the failed job at 21:26:06 Mexico City, and a subsequent completed signed check reporting current 0.10.18. The generic historical ValueError alone does not expose a full Windows traceback; the reproduced defect matches the post-upgrade scenario. No operating data or historical job was rewritten.

# 0.10.18 — Fifteen Futures assets with aggregate entry budgets (candidate)

- Observe BTC, ETH, SOL, BNB, XRP, ADA, DOGE, LINK, AVAX, DOT, LTC, BCH, TRX, ATOM and NEAR USDT perpetual contracts. Up to five positions; current Demo availability is verified per candidate.
- Size against current exchange filters, a 100 USDT entry ceiling, 300 USDT gross portfolio ceiling and 7.5 USDT estimated loss-to-stop ceiling including a 0.5% cost reserve. Reserve another 2% in pre-submit sizing for price movement. Exchange minimums never override caps; fewer than five positions may qualify.
- Reconcile actual position identities and marks, block unknown exposure, and recheck budgets after AI review. Existing positions retain protection even over a new limit. Fills, gaps, fees and funding can exceed estimates; no guaranteed loss bound is claimed.
- Keep confirmed-entry 1x/2x/3x rotation and repair the low-level submission reset: confirm the durable plan's leverage before the order. Keep crash recovery, native stops and independent account loss gates.
- Extend shared UI and bounded Worker synchronization to fifteen signals and five positions with measured portfolio budgets. Block incompatible restoration while expanded positions/plans remain. Preserve financial history.
- Local validation: 291 offline Python tests and 76 Node tests passed, covering gross budgets, post-AI refresh, missing marks/untracked exposure, per-asset availability, five-position rotation, actual submit-layer leverage and expanded restoration/snapshot contracts. Linux/Windows CI, protected publication and installation remain separate.

# 0.10.17 — Five-asset Futures Demo and bounded leverage trials (candidate)

- Add BNBUSDT and XRPUSDT to the existing BTC/ETH/SOL forward universe; retain three positions, 4H signals, score 75 and AI review.
- Alternate confirmed Demo entries at 1x/2x/3x without scaling order quantity or the 100 USDT notional ceiling. Stops must consume less than 80% of estimated initial margin; existing account loss gates and native conditional protection remain.
- Record the selected leverage/index in the durable open plan. Commit position accounting and rotation together; reconstruct an interrupted 2x/3x fill without resubmitting. Preserve existing positions' leverage and block incompatible code restoration while leveraged state remains.
- Shared portal shows effective trial levels, next entry, leverage per close and dated gross strategy-close totals. Previous snapshots remain accepted; a bounded optional contract validates the new trial shape.
- This is infrastructure testing with fictional funds, not a matched return comparison. Different entries and missing fees/funding prevent profitability conclusions. Histories remain; trial evidence starts separately.
- Local validation: 282 offline Python tests and 76 Node tests passed, including rotation, 2x/3x configuration, crash recovery, caps, native protective-close integration and legacy/current snapshot acceptance. Linux/Windows CI, protected publication and signed Windows rollout remain separate pending checks.

# Actualización 0.10.16 — auditoría de métricas y estados del portal

- Separa cierres de estrategia y cierres técnicos Futures en los resúmenes. Win rate, profit factor y expectativa de estrategia usan únicamente su historial; los totales brutos y LONG/SHORT conservan todos los cierres y lo indican. Los cierres técnicos no completan las puertas de evidencia.
- La curva Futures representa wallet más P&L no realizado. El P&L de toda la cuenta Demo se muestra aparte y nunca se usa para inferir el precio o el resultado de un contrato. Con varias posiciones, las tarjetas por activo muestran cantidad, entrada y protecciones sin atribuirles el total de la cuenta.
- Selecciona la última revisión IA por fecha y muestra su activo y momento, también junto a las señales. Una revisión histórica no se presenta como evaluación de la señal actual.
- Corrige la pérdida media Spot: los cierres en cero no se cuentan como pérdidas. Los activos cerrados sin exposición muestran cero; una posición abierta sin cotización reciente mantiene sus estimaciones ausentes.
- Cuenta los preflights bloqueados y explica que el diagnóstico incluye versiones anteriores, sin confundir candidatas con órdenes ejecutadas. Aclara costos, períodos de los contadores y puntos porcentuales del benchmark.
- El diagnóstico Futures detecta el último ciclo atrasado aunque una concentración de muestras antiguas produzca cobertura alta. La comparación conjunta también exige ausencia de errores consecutivos activos.
- Durante una verificación pendiente del actualizador, el centro conserva el estado ocupado hasta recibir resultado de Windows. No ofrece otra instalación ni vuelve prematuramente a reposo.
- El laboratorio muestra «Sin muestras» para regímenes vacíos y explica los informes anteriores sin desglose OOS por candidata. Las pequeñas pérdidas Futures conservan seis decimales; el sentinel del profit factor sin pérdidas se presenta con texto.
- Conserva señales, estrategias, riesgo, cantidades, stops, leverage, journals y LIVE deshabilitado. No borra observaciones ni reinicia el período de auditoría. Publicación e instalación de esta versión requieren verificaciones separadas.

# Actualización 0.10.15 — conexión del agente e indicador único

- Corrige una dependencia omitida en el refresco del supervisor independiente: copia `native_protection_compat.py` desde el inventario firmado. La 0.10.14 podía instalar correctamente el bot y dejar al agente con `ModuleNotFoundError` después de la reparación.
- Prueba la igualdad de los inventarios de refresco/capacidad y los imports desde una instalación independiente vacía en un proceso Python aislado, para impedir que el checkout de desarrollo oculte dependencias faltantes.
- Si fallan los metadatos del actualizador/restauración, conserva el heartbeat básico, retira las ofertas y desactiva el rollout automático hasta recuperar el supervisor. No omite firma, secuencia ni controles de instalación/restauración.
- Un mutex por instalación/sesión evita abrir dos indicadores de Windows. Una apertura manual vuelve a mostrar el existente; el inicio minimizado no lo interrumpe. El mutex se libera al salir y se recupera tras un cierre inesperado.
- Serializa la reparación del agente entre el motor, la app y el watchdog, sin detener el motor de trading. Solo muestra conexión recuperada tras dos sincronizaciones HTTPS nuevas; los estados pendiente, deshabilitado o reparación en curso se muestran como advertencia.
- Pruebas Windows ejecutan procesos temporales con PowerShell 5.1 para validar duplicados, activación, autostart silencioso, salida/crash, exclusión de reparaciones y mensajes. No usan tareas ni datos de la PC operativa.
- Una PC afectada por la dependencia omitida de 0.10.14 puede necesitar la recuperación local de ese único módulo desde su instalación ya firmada antes de recibir el rollout. Publicación e instalación de 0.10.15 deben verificarse por separado.
- Conserva estrategias, riesgo, stops, ledgers y LIVE deshabilitado. Esta corrección no prueba por sí sola el estado de Binance o la continuidad de la conexión real.

# Actualización 0.10.14 — protección nativa Spot y Futures

- Spot Testnet instala OCO `STOP_LOSS` + `TAKE_PROFIT` con ejecución MARKET al dispararse. Futures Demo instala `STOP_MARKET` + `TAKE_PROFIT_MARKET`, cierre de posición y disparador MARK_PRICE, para LONG y SHORT.
- Conserva las señales, cantidades piloto, ISOLATED 1x y límites. Ajusta los niveles a `PRICE_FILTER` de forma conservadora; la ejecución MARKET puede deslizarse y no garantiza el precio del trigger.
- Registra identidades e intención antes de cada POST. Un envío incierto se consulta por identidad y nunca se repite a ciegas, aunque Binance no encuentre la orden. Los rechazos explícitos de validación mantienen disponible la salida local y bloquean nuevas entradas.
- Reconoce ejecuciones nativas después de un reinicio, exige evidencia del fill, contabiliza una sola vez y cancela únicamente las órdenes hermanas registradas. Un cierre local cancela y confirma sus protecciones antes de enviar otra venta/cierre.
- Reconcilia ejecuciones parciales, cancelaciones inciertas y carreras entre stop y cierre manual. Los estados ambiguos bloquean nuevas escrituras; nunca inventa un cierre a partir de un saldo o posición ausentes.
- El trailing Spot reemplaza su OCO tras cancelación confirmada. Este reemplazo tiene un intervalo sin orden nativa; si falla, se muestra sin confirmar. Sin conexión permanece el último par confirmado, mientras el trailing y las salidas por señal requieren al bot conectado.
- Migra posiciones existentes al pasar la reconciliación y verificar su identidad. El portal separa integración disponible de confirmación por posición, muestra errores y cantidad cubierta; un remanente bajo los mínimos del exchange exige revisión y no se presenta como protegido.
- Impide restaurar código sin soporte nativo mientras persista un journal de órdenes nativas. Verifica otra vez con el motor detenido para cerrar la carrera con la restauración. Los journals y ledgers no se borran para forzar un downgrade.
- Guarda `native_protection_started_at` para separar la observación de esta versión sin eliminar historia. Reinicia la ventana de estabilidad de 48–72 horas al instalar; la integración se valida en Binance durante la operación Demo.
- LIVE sigue deshabilitado. Publicación e instalación mantienen el flujo firmado con aprobación del propietario.

# Actualización 0.10.13 — integridad de ejecución y evidencia

- Une la exposición de Futures `positionRisk` V3 con `symbolConfig`, reconoce `CROSSED` y exige margen CROSS confirmado antes de una reparación. Los campos ausentes ya no provocan cierres técnicos falsos.
- Usa velas cerradas del contrato USD-M Demo y una decisión durable por símbolo/vela. Limita las revisiones IA diarias de Futures, envía el contrato y tamaño propuesto, y comprueba la pausa después de la revisión y antes del envío.
- Aplica límites diarios/semanales de pérdida a la cuenta Futures con su propio historial, sin desactivar el ciclo independiente de protección. Conserva todos los puntos financieros disponibles.
- Normaliza cantidades Spot con filtros del propio Testnet antes del preflight y combina `LOT_SIZE` con `MARKET_LOT_SIZE`. El broker vuelve a validar con precio actual antes del envío.
- Confirma contabilidad, recibo único del fill y journal aplicado dentro de una sola transacción SQLite. Un reinicio no vuelve a acreditar un SELL parcial. Incluye las comisiones en activo base en el costo y P&L.
- Separa cierres técnicos y de estrategia; los técnicos no satisfacen el mínimo de evidencia. Publica señales recientes en ambos portales y reconoce motivos de salida con prefijo TESTNET.
- Corrige umbrales propios y rendimiento SHORT del shadow lab. Inicia muestras `v2` separadas, conserva el historial anterior y etiqueta la suma bruta por cierre; no calcula rentabilidad ficticia multiplicando por leverage.
- Mantiene cantidades piloto fijas, ISOLATED 1x y los límites de riesgo; el notional estimado por entrada ahora respeta el tope configurado, sin tolerancia adicional del 25%. Una orden MARKET puede variar respecto al precio de señal. No promueve estrategias ni habilita LIVE.
- Las pruebas usan bases temporales y transportes simulados. Esta versión requiere publicación protegida y verificación de instalación; las cifras históricas borradas o las comisiones no registradas no se reconstruyen artificialmente.

# Actualización 0.10.12 — diagnóstico y robustez Spot

- Sustituye el evento genérico `Cycle failed: ValueError` por diagnósticos seguros y accionables con códigos persistentes, sin exponer excepciones crudas ni credenciales.
- Separa los rechazos esperados de guardrails de entrada (riesgo por operación, exposición, filtros del exchange, saldo Testnet y movimiento de precio antes de enviar) de los fallos reales del ciclo.
- Un guardrail esperado ahora omite esa entrada y continúa el ciclo; no incrementa el contador de errores consecutivos ni puede activar falsamente el kill switch.
- Los fallos desconocidos siguen fallando de forma cerrada y conservan el kill switch de seguridad.
- La salud de Spot muestra errores consecutivos activos y el último diagnóstico persistente; cuando el siguiente ciclo sano recupera el motor, queda registrado como recuperado.
- No cambia estrategia, score, stops, riesgo, posiciones máximas, leverage ni LIVE.

# Actualización 0.10.11 — salud de observación, analítica y consistencia visual

- Mejora la salud de observación de 24 h para distinguir incidencias recuperadas de bloqueos activos: Spot pasa a `VIGILAR` cuando hay errores/avisos recuperados con continuidad e integridad sanas, y reserva `ATENCIÓN` para cobertura baja, fallos de integridad o una concentración mayor de errores.
- Futures deja de mostrar el contador histórico ambiguo como “errores totales” y separa claramente errores consecutivos, incidentes, intentos fallidos y ciclos.
- Añade motivos concretos de salud por motor para saber por qué aparece `VIGILAR` o `ATENCIÓN`.
- Amplía la analítica Spot con expectativa neta por cierre, ganancia media, pérdida media y comisiones frente al P&L neto absoluto.
- Amplía la analítica Futures con expectativa por cierre, ganancia media y pérdida media, manteniendo LONG/SHORT separados.
- MAE/MFE no se inventa a partir de datos que el historial actual no registra; el portal lo marca explícitamente como `PENDIENTE DE TELEMETRÍA` hasta instrumentarlo de forma fiable.
- Homologa estados, mayúsculas y estilos entre Spot/Futures: `OPERATIVO`, `PROTECCIONES ACTIVAS`, `PAUSADO`, tarjetas financieras y badges usan el mismo formato visual.
- No cambia estrategia, señales, stops, riesgo, número de posiciones, leverage ni LIVE.

# Actualización 0.10.10 — estabilización del release y menú Opciones

- Corrige la superposición del menú `Opciones` para mantenerlo por encima de los paneles Spot/Futures animados.
- El cambio visual forma parte del paquete firmado del bot, por lo que requiere una versión nueva en lugar de reutilizar 0.10.9.
- Conserva la validación OIDC endurecida para PRs `release/*` del mismo repositorio hacia `main`, con `portal-production` y SHA atestiguado por GitHub.
- Añade validación temprana de sintaxis para todos los módulos JavaScript críticos del release antes de pedir aprobación de producción.
- No cambia estrategia, Spot, Futures, IA, riesgo ni LIVE.

# Actualización 0.10.9 — identidad OIDC alineada con el SHA atestiguado por GitHub

- Corrige el 403 `invalid_publisher_repository` observado después de que el portal ya se desplegara correctamente.
- El job protegido publica ahora exactamente el merge-ref SHA que GitHub atestigua en el token OIDC de una PR, eliminando la discrepancia entre el SHA empaquetado y el SHA firmado por GitHub.
- El firmante acepta solo dos identidades: el flujo histórico de `push` protegido a `main` o una PR del mismo repositorio con base `main`, rama `release/*`, ref `refs/pull/<n>/merge`, workflow exacto y environment `portal-production`.
- Se añadieron pruebas positivas y negativas para impedir ampliar accidentalmente esa identidad en el futuro.
- No cambia estrategia, Spot, Futures, IA, riesgo ni LIVE. Conserva las animaciones ligeras del portal.

# Actualización 0.10.8 — publicación firmada compatible con PR aprobada

- El portal ya pudo desplegarse y superar el health check desde la PR aprobada.
- Corrige el último guard heredado: el publicador del paquete firmado del bot exigía todavía un `push` directo a `main`, aunque el nuevo flujo de release usa una PR `release/*` aprobada.
- El publicador firmado ahora acepta únicamente el SHA validado de una PR del mismo flujo seguro: evento `pull_request`, base `main`, rama `release/*` y SHA explícito de 40 caracteres.
- Mantiene intactas la firma, verificación, rama `bot-releases`, rollback del portal y bloqueo de LIVE.
- No cambia estrategia, Spot, Futures, IA ni riesgo. Conserva las animaciones ligeras ya desplegadas en el portal.

# Actualización 0.10.7 — guard de publicación compatible con PR aprobada

- Corrige el fallo posterior a la aprobación de `portal-production`: el script de despliegue aceptaba únicamente `refs/heads/main`, aunque el workflow aprobado de una PR usa `refs/pull/<n>/merge`.
- El deploy mantiene controles estrictos: repositorio exacto, evento `pull_request`, base `main`, rama `release/*` y SHA de 40 caracteres validado explícitamente.
- El portal se publica y verifica contra el SHA real de la rama de release validada, no contra el merge-ref temporal de GitHub.
- No cambia estrategia, Spot, Futures, IA, riesgo ni LIVE. Conserva las animaciones ligeras del portal.

# Actualización 0.10.6 — aprobación protegida antes del merge

- Cambia el flujo de release para no depender de que un merge hecho por API dispare otro workflow, algo que GitHub puede suprimir para evitar cadenas recursivas de automatización.
- Las ramas `release/` ejecutan validaciones completas y, si pasan, el job de publicación queda esperando la aprobación obligatoria de `portal-production` dentro de la propia PR.
- La publicación usa exactamente el SHA de la rama de release validada. Solo después de una publicación exitosa se mergea la PR a `main`.
- Con esto, la única acción humana necesaria sigue siendo aprobar `portal-production`; el merge posterior lo realiza el asistente.
- Conserva las animaciones ligeras del portal y no cambia contenido, estrategia, riesgo, Spot, Futures, IA, credenciales ni LIVE.

# Actualización 0.10.5 — un solo disparador de publicación protegida

- Elimina la duplicidad de publicaciones que podía ocurrir al mantener simultáneamente `push main` y `pull_request_target closed`.
- La publicación protegida queda ligada a un único evento: PR mergeada. Esto evita que dos jobs intenten publicar la misma versión y que uno termine marcado como fallo aunque el otro haya avanzado.
- Las PR abiertas/sincronizadas siguen ejecutando validaciones normales antes del merge.
- Tras el merge, el workflow toma exactamente el `merge_commit_sha`, vuelve a validar y espera la aprobación obligatoria de `portal-production` antes de publicar.
- Conserva las animaciones ligeras del portal y no cambia contenido, estrategia, riesgo, Spot, Futures, IA, credenciales ni LIVE.

# Actualización 0.10.4 — publicación protegida y animaciones

- Mantiene la capa visual de animaciones ligeras introducida en 0.10.3.
- Incrementa la versión porque el paquete cambió también al corregir el workflow de publicación protegida; el guard de release bloqueó correctamente 0.10.3 al detectar archivos distintos con la misma versión.
- Ajusta el flujo de PR mergeada para usar `pull_request_target` y publicar el commit mergeado tras la aprobación de `portal-production`.
- No cambia estrategia, riesgo, Spot, Futures, IA, credenciales ni LIVE.

# Actualización 0.10.3 — animaciones ligeras del portal

- Añade una capa visual de movimiento al portal sin cambiar contenido, estrategia, cálculos, APIs ni comportamiento de trading.
- Tarjetas y paneles ganan transiciones suaves y un desplazamiento mínimo al pasar el cursor, manteniendo el diseño actual.
- Botones y controles tienen respuesta visual ligera al hover/click.
- Estados y métricas hacen una animación corta únicamente cuando cambia su texto; no se añade polling adicional ni llamadas al servidor.
- Las gráficas Spot y Futures hacen un fade corto al redibujarse con los datos que ya recibían cada 30 segundos; no se añade un loop de render continuo.
- Los estados operativos tienen un pulso muy sutil para dar sensación de actividad sin usar canvas, partículas ni GPU intensiva.
- El logo tiene una microinteracción discreta al hover y los menús/details aparecen con transiciones cortas.
- La carga inicial usa una entrada suave de encabezado, motores y paneles.
- Respeta `prefers-reduced-motion`: si el sistema solicita movimiento reducido, las animaciones se desactivan prácticamente por completo.
- Todo se ejecuta en el navegador; no añade carga relevante al Worker/servidor ni modifica el intervalo de sincronización existente.

# Actualización 0.10.2 — preflight Futures alineado con Binance v3

- Corrige el fallo observado en 0.10.1: `Futures Demo symbol state unavailable: BTCUSDT / ETHUSDT`.
- Binance `GET /fapi/v3/positionRisk` omite por diseño los símbolos sin posición ni órdenes abiertas. El preflight estaba tratando esa ausencia como error, cuando en realidad es el estado plano esperado.
- La lógica ahora separa dos fuentes oficiales: `positionRisk v3` se usa solo para detectar exposición real y `GET /fapi/v1/symbolConfig` se usa para verificar margin type y leverage de símbolos planos.
- La cuenta sigue verificando ONE_WAY con `positionSide/dual`; solo cambia a ONE_WAY cuando no hay exposición.
- Tras configurar un símbolo, vuelve a comprobar exposición cero, `ISOLATED`, `1x` y ONE_WAY antes de permitir reanudación.
- Se añadió una prueba de regresión que simula exactamente la respuesta vacía de `positionRisk v3` para un símbolo plano.
- No cambia estrategia, riesgo, sizing, IA, credenciales ni LIVE.

# Actualización 0.10.1 — preflight Futures compatible con cuenta HEDGE plana

- Corrige la causa común detrás de `bloqueados: BTC, ETH, SOL` en la reanudación supervisada de 0.10.0.
- Binance puede devolver dos filas `LONG/SHORT` por símbolo cuando la cuenta está en **HEDGE mode**, incluso con exposición cero. El preflight anterior interpretaba esas dos filas planas como estado ambiguo y bloqueaba los tres símbolos antes de poder devolver la cuenta a ONE_WAY.
- El preflight ahora distingue **HEDGE plano** de **exposición ambigua real**. Si todas las filas del símbolo están en cero, puede cambiar de forma segura la cuenta a ONE_WAY y continuar con ISOLATED + 1x. Si cualquier fila tiene exposición, falla cerrado y no cambia el modo automáticamente.
- La reanudación y el portal ahora muestran el error exacto por símbolo cuando un preflight queda bloqueado, en vez de solo listar BTC / ETH / SOL.
- No cambia estrategia, riesgo, leverage objetivo 1x, sizing, IA, credenciales ni LIVE.

# Actualización 0.10.0 — auditoría integral Futures y recuperación por estado real

Esta versión nace de una auditoría completa del flujo Futures Demo después de observar una pausa persistente con cientos de repeticiones del mismo incidente. El hallazgo principal es que el problema no era un único error de margen: era una interacción entre el journal durable, la ventana de crash entre Binance y SQLite, la caducidad de consultas históricas de órdenes y la recuperación de una apertura confirmada que podía reaparecer como posición CROSS antes de quedar registrada localmente.

Cambios de raíz:

- **Estado actual primero:** la recuperación deja de depender exclusivamente de que Binance todavía conserve una orden histórica. Antes de decidir, contrasta journal, posición local y exposición actual del exchange para el símbolo exacto.
- **Apertura confirmada + posición CROSS sin posición local:** si el journal de apertura, el plan durable, la dirección y la cantidad coinciden con una única exposición actual, reconstruye primero la posición local. Si esa exposición está en CROSS, limpia el journal de apertura ya confirmado y ejecuta un único cierre `reduceOnly` identificado; luego restaura el símbolo plano a ONE_WAY / ISOLATED / 1x. Esto corrige específicamente el ciclo que producía `Automatic Futures margin is not isolated` sin poder avanzar.
- **Crash después del commit local:** si la posición local ya existe pero quedó el journal de apertura, valida identidad contra Binance, elimina solo el journal obsoleto y repara configuración de forma segura.
- **Órdenes históricas expiradas:** Binance `-2013 Order does not exist` deja de ser una excepción infinita. Si una apertura antigua no puede consultarse y la exposición actual es cero, el journal se pone en cuarentena y se limpia, dejando una marca explícita de brecha de evidencia. Si existe exposición, no se limpia.
- **Cierres `reduceOnly`:** mantienen la regla anterior: solo se elimina un journal antiguo sin consultar la orden cuando local y exchange están inequívocamente planos.
- **Reanudar deja de ser un simple borrado del kill switch:** la acción ahora pasa por mantenimiento supervisado, detiene cooperativamente el motor, reconcilia journal, valida identidad, corrige/neutraliza exposición CROSS permitida, ejecuta preflight de todos los símbolos y solo entonces quita la pausa y reinicia el motor.
- **Anti-spam operativo:** un mismo fallo repetido se conserva como un incidente con contador, pero los WARN idénticos del motor se limitan a uno cada 15 minutos. Se separan `incidentes`, `intentos fallidos` y `ciclos` para no volver a presentar cientos de chequeos de protección como cientos de causas distintas.
- **Diagnóstico durable:** el portal recibe la última recuperación de journal y cualquier brecha de evidencia sin secretos, para que una recuperación no quede invisible.
- **Spot Testnet auditado:** el broker Spot ya reconcilia su journal por `clientOrderId` antes de cada ciclo, protege posiciones con precio de ejecución Testnet y mantiene su ledger separado. No se encontró el patrón de bloqueo de Futures ni se cambió su estrategia/riesgo.
- La tipografía de **Posiciones abiertas · Spot** permanece en el tamaño estándar restaurado en 0.9.9; el scroll horizontal es intencional para conservar homologación visual.
- No habilita LIVE ni cambia estrategia, scores, riesgo, leverage automático 1x, sizing, credenciales o límites financieros.

# Actualización 0.9.9 — cierre definitivo del journal Futures plano

- Corrige el caso que todavía podía mantener Futures en **PAUSADO + conciliación pendiente** después de 0.9.8: un journal `reduceOnly` antiguo podía quedar huérfano cuando Binance y el ledger local ya estaban planos, pero la consulta histórica de esa orden fallaba antes de que el motor comprobara ese estado seguro.
- La recuperación ahora inspecciona primero el tipo de journal. Si es un cierre `reduceOnly`, no existe posición local y Binance confirma exposición cero para ese símbolo, el journal se limpia como bookkeeping obsoleto **sin reenviar ninguna orden** y sin depender de que Binance todavía conserve la orden histórica.
- Esta excepción segura nunca aplica a aperturas ni a estados con exposición: cualquier journal de entrada o cualquier posición todavía visible sigue requiriendo reconciliación exacta por identidad.
- Se conserva un registro `forward_last_journal_recovery` con el motivo y timestamp de la limpieza segura para diagnóstico posterior.
- Añade pruebas de regresión que garantizan que el atajo plano no consulta ni reenvía órdenes y que nunca se usa para una apertura pendiente.
- Revierte únicamente el ajuste tipográfico compacto de **Posiciones abiertas · Spot**: vuelve al tamaño/espaciado original para mantener la homologación visual general, aceptando nuevamente scroll horizontal cuando sea necesario.
- No cambia estrategia, señales, riesgo, leverage, sizing, IA, credenciales, histórico financiero ni LIVE.

# Actualización 0.9.8 — recuperación Futures y paridad visual

- Corrige un bloqueo real de recuperación de Futures: una orden de cierre `reduceOnly` ya confirmada por Binance podía dejar un `forward_pending_order` durable aunque la posición local y la del exchange ya estuvieran planas. Ese journal huérfano impedía la auto-reanudación y mantenía el motor en PAUSADO.
- La auto-recuperación ahora reconcilia primero cualquier journal pendiente. Si Binance confirma el cierre y ambos lados están planos, limpia el journal de forma segura y continúa la recuperación; si todavía hay exposición, no reenvía la orden y espera/escala sin duplicar ejecución.
- Cuando Futures está en una pausa automática y ya está plano, el bucle de protección puede completar la recuperación segura sin esperar al siguiente ciclo de estrategia. Las pausas manuales nunca se reanudan solas.
- Evita convertir la latencia transitoria del endpoint de posiciones después de un cierre FILLED en cientos de errores repetidos.
- Conserva los errores históricos, pero el portal deja de presentarlos como un porcentaje contra ciclos (que podía superar 1000% por incluir varios chequeos de protección por ciclo). Ahora los identifica explícitamente como eventos históricos.
- Homologa la tarjeta **IA final** de Futures con Spot: muestra el veredicto/estado y debajo el mismo modelo compartido. Spot y Futures continúan usando la configuración IA común; actualmente `gpt-6-luna` cuando ese es el modelo activo.
- La tabla de posiciones Spot usa tipografía/espaciado más compacto en escritorio para evitar scroll horizontal innecesario; en pantallas pequeñas conserva scroll deliberadamente.
- No cambia estrategia, señales, umbral de entrada, riesgo, leverage automático 1x, sizing, credenciales, ledgers ni LIVE.

# Actualización 0.9.7 — contrato portal/Windows y versión visible

- Corrige el HTTP 400 de sincronización introducido al añadir `pause_diagnostics.incident` en 0.9.6: el agente Windows ya emitía el campo, pero el validador del Worker todavía no lo aceptaba.
- El Worker acepta ahora el objeto `incident` únicamente con su forma acotada y validada, conserva compatibilidad con snapshots anteriores sin ese campo y rechaza formas malformadas.
- Añade pruebas de regresión específicas para que el contrato de diagnóstico Futures actual y el legado sean aceptados por el portal antes de publicar.
- Regla permanente: todo campo nuevo del snapshot remoto debe actualizar en la misma PR el validador del portal y una prueba de compatibilidad. Una release no debe romper los heartbeats por evolución unilateral del esquema.
- El encabezado compartido del portal muestra en letra pequeña la versión instalada junto al nombre **Crypto AI Trader**. En remoto toma `installed_version` del heartbeat; en local la obtiene del `pyproject.toml` instalado.
- No cambia estrategia, señales, riesgo, leverage, sizing, credenciales, ledgers ni LIVE.

# Actualización 0.8.14 — portabilidad y memoria durable del proyecto

- Añade `PROJECT_HANDOVER.md` como punto de entrada obligatorio para futuros mantenedores o modelos de IA: misión, arquitectura, invariantes, estado, ideas futuras y checklist de toma de control.
- Añade `PROJECT_HISTORY.md` para conservar decisiones arquitectónicas, enfoques abandonados, lecciones de seguridad y razones detrás de la evolución PAPER → Spot Testnet + Futures Demo.
- Añade `PORTABILITY.md` con separación explícita entre código, secretos, estado persistente y supervisor del host.
- Añade bootstrap reproducible para Windows y Linux, más un preflight de portabilidad de solo lectura. No inicia el motor, no crea credenciales y no habilita LIVE.
- `AGENTS.md` obliga a futuras sesiones de Work/IA a leer el handover e historial antes de cambiar el proyecto y a actualizar esa memoria cuando cambie la arquitectura o el roadmap.
- El objetivo es que ni la PC actual ni el historial de este chat sean puntos únicos de conocimiento: el proyecto debe poder reconstruirse y comprenderse desde el repositorio.
- No cambia estrategia, señales, riesgo, leverage, sizing, IA de decisión, credenciales, ledgers ni LIVE.

# Actualización 0.8.13 — arquitectura Windows estable sin PowerShell en el agente

- Corrige la causa demostrada del supervisor inestable: el self-heal podía arrancar el watchdog y luego reescribir la tarea con `Set-ScheduledTask`, terminando el host PowerShell con `0xC000013A` y dejando `pythonw.exe` huérfano.
- La tarea `Crypto Paper Portal Agent` pasa a ejecutar **`pythonw.exe windows_agent.py` directamente**. PowerShell deja de formar parte de la ruta normal del agente remoto.
- Task Scheduler conserva `RestartCount=999`, por lo que si el agente termina, Windows lo relanza sin abrir consola.
- El self-heal ahora sigue un orden cerrado: detener agente → refrescar módulos firmados → reconfigurar la tarea mientras está detenida → arrancar → exigir **dos heartbeats HTTPS consecutivos** con la tarea en estado `Running`.
- Un único heartbeat ya no basta para declarar el agente saludable.
- El updater local se relanza automáticamente con el **mismo Python del supervisor** aunque lo invoque la app o el portal local, eliminando diferencias de runtime y errores de dependencias.
- Buscar actualizaciones estando en la release actual devuelve **`up_to_date` / “Ya estás actualizado”** en vez de `LOCAL_VALIDATION_FAILED`.
- El portal local acepta ese estado como éxito y no muestra 503 por estar ya actualizado.
- Mantiene firma Ed25519, hash, secuencia anti-downgrade, health-check, rollback, ledgers y credenciales sin cambios.
- No cambia estrategia, señales, riesgo, leverage, sizing, IA ni LIVE.

# Actualización 0.8.12 — cierre de dependencias del supervisor Windows

- Corrige el `ModuleNotFoundError` persistente del updater/agente independiente.
- Añade `trader/config.py` al conjunto firmado y sincronizado del supervisor; `windows_agent.py` y `remote_agent.py` lo importan directamente.
- El agente independiente deja de importar `portal_snapshot.py` como fallback al arrancar. La proyección financiera se obtiene únicamente mediante el exportador aislado de la instalación activa.
- Esto evita que una carpeta histórica como `audit-work-v0.6.2` oculte dependencias antiguas y produzca un supervisor parcialmente actualizado.
- El self-heal reescribe siempre la acción de Task Scheduler al formato watchdog oculto después de recuperar conectividad, eliminando definiciones heredadas que abren ventanas PowerShell.
- Mantiene firma, hashes, secuencia anti-downgrade, health-check y rollback.
- Incluye todos los cambios visuales de 0.8.11 para paridad Spot/Futures.
- No cambia estrategia, señales, riesgo, leverage, sizing, IA, credenciales, ledgers ni LIVE.

# Actualización 0.8.11 — paridad visual Spot + Futures

- Reorganiza el portal para que los dos motores tengan el mismo peso visual en desktop: Spot a la izquierda y Futures a la derecha; en móvil se apilan.
- **Límites:** añade un panel Futures equivalente con leverage automático, margen, máximo de posiciones, presupuesto de margen, score mínimo, stop mínimo/ATR y reward/risk.
- **Posiciones:** mantiene la tabla Spot y añade una tarjeta Futures con contrato/dirección, cantidad, entrada, precio estimado actual, P&L no realizado, stop/objetivo, leverage/margen y hora de apertura.
- **Seguimiento financiero:** añade un panel Futures completo con días observados, cierres, retorno, P&L, drawdown, win rate, profit factor, LONG/SHORT, errores, puertas pendientes y cierres recientes.
- Los datos Futures provienen exclusivamente de su ledger/configuración independiente. No se mezclan con Spot y no se inventan controles manuales que el motor no soporte.
- Reduce la tabla Spot para que la comparación sea más legible sin eliminar las protecciones relevantes.
- No cambia estrategia, señales, riesgo, leverage, sizing, IA, credenciales, ejecución ni LIVE.

# Actualización 0.8.10 — runtime correcto para el updater local de Windows

- Corrige el `ModuleNotFoundError` del centro local de actualizaciones después de introducir el watchdog PowerShell.
- Si la tarea `Crypto Paper Portal Agent` ejecuta `powershell.exe`, el updater extrae el `-PythonPath` firmado/configurado en los argumentos de la tarea y deriva el `python.exe` correspondiente.
- El updater deja de caer silenciosamente a `py -3` u otro Python del sistema, evitando ejecutar el supervisor con un entorno sin sus dependencias.
- Si no puede identificar el runtime exacto del supervisor, falla de forma cerrada con un mensaje claro en vez de intentar otro intérprete.
- No cambia estrategia, señales, riesgo, leverage, sizing, IA, credenciales, ledgers ni LIVE.

# Actualización 0.8.9 — recuperación del agente y diagnóstico persistente

- Corrige un defecto de 0.8.8 donde la autoreparación podía intentar modificar la tarea programada antes de recuperar la conexión HTTPS. Si Windows rechazaba esa modificación, el proceso terminaba antes de refrescar/reiniciar el agente.
- El orden pasa a ser: detener solo el agente → refrescar módulos firmados → arrancar con la tarea existente → confirmar sincronización HTTPS → endurecer la tarea como paso no bloqueante.
- El watchdog PowerShell se ejecuta con `-WindowStyle Hidden`; ya no debe quedar una consola visible aparentemente “pegada”.
- Añade `data/agent-self-heal.json` y `data/agent-watchdog.json` con estados seguros de fase, reintentos y exit code. No almacenan secretos, URLs privadas ni cuerpos de respuestas.
- Si endurecer Task Scheduler falla por permisos, el agente conectado permanece vivo; la recuperación remota tiene prioridad sobre la mejora de la tarea.
- Mantiene el watchdog persistente, backoff, refresh firmado del supervisor y rollback del updater.
- No cambia estrategia, señales, riesgo, leverage, sizing, IA, credenciales, ledgers ni LIVE.

# Actualización 0.8.8 — Self-Healing Rollout

- El motor Windows, después de que una release firmada quede comprometida y activada, lanza una reparación asincrónica del agente remoto. La visibilidad remota nunca bloquea el trading.
- La tarea `Crypto Paper Portal Agent` pasa a ejecutar un watchdog persistente que relanza únicamente el agente HTTPS con backoff; no inicia ni reinicia el motor de trading.
- La tarea conserva una política secundaria de hasta 999 reinicios con intervalo de un minuto, evitando agotar tres intentos y quedar desconectada indefinidamente.
- La autoreparación refresca los módulos del agente desde la instalación firmada, conserva respaldo, reinicia solo el agente y comprueba una nueva sincronización HTTPS.
- El mismo mecanismo se usa desde la opción manual **Reparar conexión del portal**, eliminando dos rutas de mantenimiento divergentes.
- Una PC que todavía tenga 0.8.6 y no haya instalado 0.8.7 puede saltar directamente a 0.8.8 cuando el agente vuelva a conectarse: el portal siempre ofrece la última release firmada superior.
- Corrige la leyenda del publicador para mostrar el modo real de la release (TESTNET/PAPER) en vez de imprimir siempre PAPER.
- No cambia estrategia, señales, riesgo, sizing, leverage, IA, credenciales, ledgers ni habilita LIVE.

# Actualización 0.8.7 — observabilidad e integridad de la muestra

- Añade un panel **Salud de observación · 24 h** separado para Spot Testnet y Futures Demo.
- Mide cobertura de ciclos contra el tiempo realmente observado, muestras esperadas, gap promedio y antigüedad del último ciclo sin penalizar un arranque reciente.
- Spot resume errores/avisos, revisiones IA/rechazos, cierres y P&L realizado de las últimas 24 horas.
- Futures resume continuidad, cierres/P&L, errores consecutivos y total de errores.
- Añade comprobaciones locales de integridad: journal de órdenes pendiente, frescura de precios, límite de posiciones Spot y restricción de una posición Futures.
- El panel clasifica la muestra como INICIANDO, ESTABLE, VIGILAR o ATENCIÓN para distinguir problemas operativos de resultados financieros.
- No cambia señales, estrategia, riesgo, leverage, sizing, universo, IA, credenciales ni rutas LIVE. Es observabilidad únicamente.

# Actualización 0.8.6 — puente de actualización remota

- Release puente compatible con el updater instalado en 0.8.4: el paquete se publica temporalmente como `PAPER` y no incluye `config.toml`, evitando el `ValueError` del verificador antiguo.
- Instala el updater/verificador nuevo, que ya acepta releases TESTNET y `config.toml` firmado para versiones posteriores.
- En modo TESTNET, Futures forward queda habilitado por diseño; la pausa operativa usa exclusivamente el kill switch dedicado. Esto corrige el estado `INACTIVO · FORWARD DESHABILITADO` aun cuando la PC conserve el config histórico.
- Mantiene firma Ed25519, secuencia anti-downgrade, health-check y rollback supervisado.
- No modifica credenciales, ledgers, estrategia, leverage ni habilita LIVE.

# Actualización 0.8.5 — Unified Rollout portal + Windows

- Una release aprobada y firmada pasa a ser una actualización integral: el portal se publica y el agente Windows detecta automáticamente si la PC sigue en una versión anterior.
- Windows recibe automáticamente un trabajo `update_install` para la release exacta. El supervisor conserva parada cooperativa, firma Ed25519, health-check y rollback.
- Si la PC estaba apagada o desconectada, el rollout se genera al volver a sincronizar.
- Una instalación que falla no se reintenta en bucle; queda registrada para revisión. Una nueva release puede volver a intentarse normalmente.
- El botón manual de instalación permanece como recuperación/fallback, pero deja de ser el paso normal.
- Esta versión es la transición: debe instalarse y refrescar el agente independiente una vez para activar el rollout automático de las versiones siguientes.
- No cambia estrategia, riesgo, leverage, credenciales, ledgers ni rutas LIVE.

# Actualización 0.8.4 — corrección de activación Futures

- Corrige el caso en que una variable local antigua `FUTURES_FORWARD_ENABLED=false` podía seguir deshabilitando el forward test aunque la configuración firmada tuviera `forward_enabled=true`.
- La activación del forward test ahora proviene únicamente de la configuración firmada. Pausar/reanudar Futures sigue usando su kill switch dedicado desde el portal.
- No cambia estrategia, leverage, tamaño, credenciales, ledger ni rutas LIVE.

# Actualización 0.8.3 — consolidación final Spot + Futures

- **Binance Spot Testnet pasa a ser el modo operativo predeterminado** del paquete. PAPER permanece disponible únicamente como respaldo técnico/CI; Binance LIVE sigue sin implementación.
- El forward test Futures Demo queda habilitado automáticamente cuando el motor está en TESTNET. El portal deja de mostrar un “INACTIVO” ambiguo y explica si el motivo es entorno incorrecto, forward deshabilitado o pausa.
- Portal local y remoto comparten una sola interfaz consolidada: dos bloques simétricos para Spot y Futures, métricas comparables y una curva independiente por motor.
- La app de Windows usa la misma jerarquía conceptual: Spot Equity/Return y Futures Wallet/P&L, con estado explícito del segundo motor.
- Se simplifica el menú normal a Motores e IA, Actualizaciones, Actividad y Diagnóstico avanzado. PAPER y smoke tests quedan plegados como herramientas técnicas.
- Las pruebas unitarias ahora declaran explícitamente su entorno en vez de depender del modo global, evitando que una prueba PAPER intente tocar Testnet por accidente.
- El paquete firmado declara su modo real desde config.toml; deja de etiquetarse siempre como PAPER.
- Se actualiza documentación obsoleta y se preservan deliberadamente ledgers, históricos, rollback, journal durable, kill switches y nombres internos de compatibilidad.
- La revisión IA final permanece en ambos motores. Los cierres protectores, stops, reconciliación y recuperación nunca esperan a la IA.

# Actualización 0.8.2 — cierre operativo para observación dual

- **Futures Demo usa el mismo modelo IA que Spot** como confirmación final fail-closed antes de una entrada automática. La IA solo puede `ALLOW` o `REJECT`; no crea la operación, no cambia LONG/SHORT, no aumenta tamaño/leverage y no elimina protecciones.
- Las escrituras Futures inciertas ahora se recuperan desde el journal durable después de fallas de Internet, proceso o energía. Una apertura confirmada puede reconstruirse desde Binance + el plan persistido; un cierre confirmado se concilia sin reenviar la orden.
- Se mantiene un **kill switch separado de Futures** y tres errores consecutivos pausan ese motor sin detener Spot.
- El portal normal se limpia alrededor de **Spot Testnet + Futures Demo**; PAPER queda plegado como respaldo técnico/CI.
- El estado Futures distingue **ACTIVO · ESPERANDO SEÑAL**, posición abierta, pausado e inactivo. El panel muestra además la última confirmación IA y el estado de recuperación.
- El centro de control de Windows refleja los dos motores y añade un watchdog con backoff que recupera el proceso del motor si desaparece inesperadamente, sin interferir con mantenimiento/updates firmados.
- Desde **http://127.0.0.1:8765** se puede buscar, verificar e iniciar directamente una actualización firmada usando el supervisor independiente de Windows; ya no hace falta abrir el portal remoto para instalar.
- La observación comparativa de 0.8.1 se conserva: días, cierres, P&L, retorno, drawdown, win rate, profit factor, LONG/SHORT, ciclos y errores.
- **LIVE sigue bloqueado.** Los stops/targets nativos persistentes en el exchange todavía no forman parte del forward test; mientras la PC esté completamente sin Internet o energía, la protección local no puede actuar. Esa capacidad queda como puerta obligatoria antes de considerar capital real.

# Actualización 0.8.1 — observabilidad comparativa Spot + Futures

- Añade un scorecard persistente del forward test Futures Demo: días observados, cierres, P&L realizado bruto, retorno observado de la cuenta, win rate, profit factor, drawdown muestreado y desglose LONG/SHORT.
- Registra ciclos y errores acumulados del segundo motor para distinguir problemas operativos de resultados de estrategia.
- El portal muestra Spot Testnet y Futures Demo en un panel comparativo con puertas de observación separadas.
- La regla mínima para una revisión formal se mantiene en **30 días y 30 cierres por motor**. Alcanzarla solo habilita revisión humana; nunca activa Binance LIVE.
- Durante el warm-up se evitan cambios de estrategia, riesgo o leverage basados en pocos días. Las correcciones operativas y de seguridad sí pueden aplicarse cuando sean necesarias.
- No cambia señales, tamaño de Spot, presupuesto Futures, leverage automático ni límites de riesgo. LIVE continúa bloqueado.

# Actualización 0.8.0 — Spot Testnet + Futures Demo en paralelo

- El portal pasa a mostrar dos motores claramente separados: **Spot Testnet** y **Futures Demo**.
- Spot conserva su estrategia multi-activo, ledger y controles actuales.
- Futures deja de ser solo un smoke lab y añade un forward test persistente de **BTCUSDT LONG/SHORT**, máximo una posición, margen `ISOLATED`, modo `ONE_WAY` y **1x automático fijo**.
- El forward test Futures arranca automáticamente al instalar 0.8.0 mientras el motor principal esté en TESTNET; no requiere un botón inicial.
- Futures usa su propio ledger, journal de órdenes y kill switch. Pausar Futures no pausa Spot, y pausar nuevas entradas Futures mantiene la protección de una posición ya abierta.
- Las pruebas manuales 1x/2x/3x quedan plegadas como diagnóstico; 2x/3x no forman parte de la ejecución automática.
- La cantidad automática inicial es `0.001 BTC`, validada con `/order/test`, y se bloquea si supera el presupuesto configurado de 100 USDT con margen de tolerancia.
- El portal muestra wallet, posición, P&L cerrado y número de cierres de Futures por separado de las métricas Spot.
- Tres errores consecutivos del forward test activan únicamente el kill switch de Futures; Spot continúa.
- Binance LIVE continúa sin host, ruta de escritura ni activación automática.

# Actualización 0.7.9 — acciones de portal de un solo clic

- Las acciones manuales mantienen un estado ocupado persistente desde el primer clic: el botón cambia a **Procesando…** y queda bloqueado mientras Windows trabaja.
- El refresco periódico del dashboard ya no puede reactivar prematuramente **Verificar Futures**, **Prueba Futures**, **Reconciliar Futures** ni el smoke Spot mientras una acción sigue en curso.
- El portal sigue automáticamente la solicitud remota hasta que Windows devuelve `completed`, `failed` o `expired`, y muestra el mensaje final sin requerir otro clic.
- **Instalar actualización** muestra inmediatamente **Instalación solicitada** después de aceptar el job y deja claro que no hay que volver a pulsar.
- Se conserva el estado fresco de Windows antes de cada acción y la idempotencia por `request_id`.
- Si Binance omite `avgPrice` en la respuesta inmediata del cierre Futures, el bot usa `cumQuote / executedQty` o consulta la orden firmada por `clientOrderId`; nunca reenvía el cierre.
- No cambia estrategia, balances, riesgo ni ejecución Binance; LIVE continúa bloqueado.

# Actualización 0.7.8 — smoke Futures 100% privado/Testnet

- La **Prueba Futures** ya no depende de ticker, funding ni exchangeInfo públicos.
- Antes de abrir una posición, valida la cantidad exacta con `POST /fapi/v1/order/test` en Futures Demo; esa llamada no ejecuta ninguna orden.
- Para BTCUSDT usa inicialmente `0.001`, la misma cantidad ya validada por **Verificar Futures**.
- El notional y margen mostrados se calculan después de la apertura a partir de `positionAmt`, `entryPrice` y leverage obtenidos mediante endpoints firmados.
- `funding_rate` queda en `null` durante este smoke técnico porque ya no consulta el endpoint público de funding.
- Apertura, lectura de posición, cierre `reduceOnly` y reconciliación siguen exclusivamente en `testnet.binancefuture.com`.
- LIVE continúa bloqueado.

# Actualización 0.7.7 — diagnóstico privado independiente de datos públicos

- **Verificar Futures** ya no depende de ticker, funding ni exchangeInfo públicos. Usa directamente `POST /fapi/v1/order/test` con BTCUSDT y cantidad `0.001`, que valida permiso TRADE sin ejecutar una orden.
- Las lecturas públicas de Futures usan la configuración de red/proxy normal de Windows; las llamadas firmadas mantienen el transporte sin proxy y el host fijo de Testnet.
- Esto separa claramente un problema de conectividad pública de un problema de credenciales o permiso Futures.
- El smoke real conserva datos públicos para dimensionar una orden válida; si ese paso falla, el mensaje ya permite distinguirlo de la verificación privada.
- LIVE continúa bloqueado para cualquier llamada firmada o escritura.

# Actualización 0.7.6 — Futures Demo resiliente a fallos públicos

- El preflight de permiso TRADE deja de consultar funding; para construir `order/test` solo usa ticker y filtros del contrato.
- Las lecturas públicas de Futures intentan primero `testnet.binancefuture.com` y, si ese GET falla, usan `fapi.binance.com` únicamente como respaldo de datos públicos.
- Las llamadas firmadas siguen fijadas exclusivamente a `testnet.binancefuture.com`: cuenta, posiciones, `order/test`, leverage, marginType y órdenes nunca tienen fallback a producción.
- El fallback público no recibe API key ni secret y no puede escribir.
- Mantiene los diagnósticos detallados de 0.7.4/0.7.5 y los botones de primer clic.
- LIVE continúa bloqueado para cualquier acción de trading.

# Actualización 0.7.5 — host REST correcto para Binance Futures Demo

- Corrige el host de USDⓈ-M Futures: la interfaz se denomina **Binance Demo Trading**, pero la API REST de prueba usa `https://testnet.binancefuture.com`.
- Revierte el host experimental `demo-fapi.binance.com`, que provocaba `Futures Testnet public connection failed`.
- Conserva todas las mejoras de 0.7.4: `POST /fapi/v1/order/test` como preflight de permiso TRADE, cantidad compatible con filtros del contrato y mensajes reales de Binance.
- Conserva los cambios de fiabilidad de primer clic del portal.
- Futures sigue separado de Spot, con fondos ficticios, ISOLATED, One-way, 1x/2x/3x, reduceOnly, journal durable y recovery.
- Binance LIVE continúa sin host ni ruta de escritura.

# Actualización 0.7.4 — diagnóstico Futures Demo + acciones de un solo clic

- **Verificar Futures** construye ahora una orden de prueba con una cantidad compatible con `minQty`, `stepSize` y `MIN_NOTIONAL`; deja de asumir que 10 USDT siempre producen una cantidad válida para BTCUSDT.
- Los rechazos HTTP de Binance conservan de forma acotada el código y mensaje de API y los muestran en Actividad, sin exponer credenciales.
- El portal ya no recomienda reconciliar de forma genérica cuando el fallo ocurrió antes de una escritura; solo el estado de recovery pendiente exige **Reconciliar Futures**.
- Las acciones manuales consultan estado fresco de Windows antes de ejecutarse, evitando depender de una caché de hasta cinco segundos.
- **Buscar actualizaciones** deja de ignorar silenciosamente un clic por el throttle usado para comprobaciones automáticas; un clic manual siempre inicia una comprobación nueva o informa que ya hay una en curso.
- **Instalar**, **Verificar Futures**, Research y otros controles remotos usan el mismo patrón de estado fresco para mejorar la respuesta al primer clic.
- Mantiene Binance Futures Demo, fondos ficticios, ISOLATED, One-way, 1x/2x/3x, reduceOnly, journal durable y LIVE bloqueado.

# Actualización 0.7.3 — verificación real de permiso Futures Demo

- Deja de bloquear Futures Demo únicamente por el campo `canTrade` de `/fapi/v3/account`.
- **Verificar Futures** ahora usa el endpoint oficial `POST /fapi/v1/order/test`: exige permiso TRADE pero no crea ni ejecuta una orden.
- El smoke también realiza ese preflight no ejecutable antes de cualquier cambio de leverage o apertura real en Demo.
- Conserva host `demo-fapi.binance.com`, fondos ficticios, margen ISOLATED, One-way, 1x/2x/3x, reduceOnly, journal durable y recovery.
- El valor reportado por la cuenta queda disponible solo como diagnóstico (`reported_can_trade`) y no como única fuente de verdad.
- Binance LIVE continúa bloqueado.

# Actualización 0.7.2 — Binance Futures Demo correcto

- Corrige el endpoint del laboratorio de derivados para usar el entorno que corresponde a las claves creadas en Binance Demo Trading: `https://demo-fapi.binance.com`.
- La v0.7.1 apuntaba al antiguo host `testnet.binancefuture.com`; por eso una clave válida de Demo podía devolver un estado de cuenta incompatible como `canTrade=false`.
- Mantiene credenciales, ledger y controles de Futures separados de Spot.
- Conserva margen `ISOLATED`, modo One-way, leverage 1x/2x/3x, cierre `reduceOnly`, journal durable y recuperación explícita.
- El portal pasa a nombrar este entorno como **Futures Demo** para coincidir con Binance.
- Binance LIVE sigue sin host, selector ni ruta de escritura.

# Actualización 0.7.1 — hardening de Futures Testnet

- Mantiene la arquitectura 0.7.0: Spot Testnet como motor principal, PAPER como respaldo/CI y Futures Testnet como laboratorio separado.
- Antes de intentar cambiar el modo de posiciones de USDⓈ-M Futures, consulta `GET /fapi/v1/positionSide/dual`; solo envía el cambio a One-way si la cuenta realmente está en Hedge Mode.
- Evita una escritura de configuración innecesaria en cada smoke test y reduce el riesgo de conflictos con cambios recientes de Binance al sincronizar modos de posiciones entre productos.
- Conserva margen `ISOLATED`, leverage limitado a 1x/2x/3x, cierre `reduceOnly`, journal durable y reconciliación explícita.
- Documenta en `.env.example` las credenciales separadas de Futures Testnet.
- Binance LIVE continúa sin host, selector ni ruta de escritura.

# Actualización 0.7.0 — TESTNET principal + laboratorio Futures aislado

- PAPER queda funcionalmente congelado como respaldo, CI y diagnóstico; las capacidades nuevas pasan a Testnet salvo correcciones de seguridad.
- Mantiene Spot Testnet como motor automático principal y conserva `trader.db`, `testnet-trader.db` y ahora `futures-testnet.db` separados.
- Añade un laboratorio paralelo de Binance USDⓈ-M Futures Testnet con credenciales independientes de Spot.
- Futures Testnet queda limitado por código a margen `ISOLATED`, modo `ONE_WAY` y leverage 1x/2x/3x.
- Añade verificación de cuenta Futures, smoke LONG/SHORT con margen ficticio pequeño, lectura de funding/liquidation price y cierre `reduceOnly`.
- Cada escritura Futures guarda primero un journal durable con `clientOrderId`; una respuesta incierta no se reintenta y exige reconciliación explícita.
- La reconciliación solo puede cerrar el símbolo registrado por el smoke y valida dirección, leverage y margen aislado antes de enviar `reduceOnly`.
- El portal reorganiza Modelo IA y motor en dos tarjetas: Motor principal (Spot/PAPER) y Laboratorio Futures Testnet.
- Binance LIVE sigue sin host, selector ni ruta de escritura.

# Actualización 0.6.26 — responsive global y Smoke Test aislado

- Unifica el ancho de todos los paneles del portal para que Actualizaciones, Modelo IA, Historial, Diagnóstico y paneles financieros compartan la misma geometría.
- Añade una capa responsive coherente para desktop, tablet y móvil: tipografías fluidas, grids 4→2→1, botones y selects de ancho completo cuando corresponde, tablas con scroll táctil y zonas de interacción de al menos 44 px.
- Corrige el panel Modelo IA y motor en móvil para que labels, selects y botones no se deformen ni desborden horizontalmente.
- La app de Windows identifica de forma explícita Binance Spot Testnet, fondos ficticios y LIVE bloqueado; cuando se alcanza el máximo de posiciones, resalta la exposición en ámbar.
- El Smoke Test Testnet ya no exige un ledger vacío. Selecciona un símbolo válido que no esté entre las posiciones estratégicas existentes, usa un límite temporal exclusivamente para la prueba y verifica que las posiciones preexistentes queden intactas tras BUY → conciliación → SELL → conciliación.
- Las órdenes pendientes siguen bloqueando la prueba. Binance LIVE continúa sin rutas de escritura.

# Actualización 0.6.25 — limpieza PAPER/TESTNET, updater visual y Smoke Test

- Limpia validaciones, mensajes y documentación heredados que todavía asumían PAPER aunque el motor unificado ya soporte PAPER y Binance Spot Testnet.
- El updater local y el supervisor usan terminología neutral y reconocen ambos entornos; el bloqueo de archivos usa el ledger efectivo del modo activo.
- La app y el portal ya no muestran PAPER por defecto mientras esperan el estado real del motor.
- El seguimiento financiero adapta sus etiquetas al entorno activo y evita presentar costos/operaciones Testnet como si fueran simulación PAPER.
- Rediseña el Centro de actualizaciones como una sola experiencia compacta: estado principal, una acción relevante y detalles técnicos plegados.
- Añade una prueba supervisada de ejecución Binance Spot Testnet. Solo funciona en TESTNET, requiere cero posiciones abiertas y ninguna orden pendiente, detiene el motor cooperativamente y usa el mismo BinanceTestnetBroker para una ida y vuelta BTCUSDT pequeña con fondos ficticios.
- El Smoke Test usa un solo escritor, journal durable e idempotencia del portal; no reintenta escrituras inciertas y siempre vuelve a levantar el motor mediante el supervisor.
- Binance LIVE sigue sin host, ruta ni modo de escritura implementado. El Smoke Test valida infraestructura, no rentabilidad.
- Conserva los nombres internos históricos necesarios para compatibilidad, como /v1/paper-controls y paper_close, sin exponerlos como estado efectivo del motor.

# Actualización 0.6.24 — comprobación de updates idempotente

- Corrige la búsqueda de actualizaciones cuando el bot ya está en la versión firmada más reciente: la secuencia actual puede verificarse para descubrimiento sin tratarse como replay ni convertirse en candidata de instalación.
- La instalación continúa siendo estrictamente monotónica: una release con la misma secuencia o una anterior sigue sin poder instalarse.
- Si Windows confirma que no hay una versión nueva, el Centro muestra `Estás actualizado · bot X · firma verificada` en lugar de registrar `ValueError`.
- Si la consulta de detalles de publicación en GitHub falla temporalmente pero Windows sigue disponible, el estado local del bot continúa siendo útil y el error externo queda como detalle secundario.
- No modifica estrategia, riesgo, balances, ledgers ni ejecución Binance Testnet.

# Actualización 0.6.23 — supervisor independiente actualizable en TESTNET

- Corrige una deuda de arquitectura detectada al intentar instalar 0.6.22 desde el portal con el motor en TESTNET: el supervisor independiente sincronizaba el heartbeat y controles, pero conservaba copias antiguas de sus módulos de instalación.
- La reparación firmada sincroniza ahora también `scripts/remote_job.py`, `trader/remote_jobs.py`, `trader/update_manager.py`, `trader/update_supervisor.py`, `trader/runtime.py` y `trader/runtime_control.py`.
- Antes de ofrecer una instalación remota, Windows verifica que todos esos módulos del supervisor independiente coincidan byte a byte con los hashes firmados de la versión instalada. Si están stale, el portal bloquea la instalación y exige reparación en vez de fallar a mitad del update.
- El refresh firmado del supervisor acepta tanto PAPER como TESTNET, siempre que la versión instalada esté comprometida en el journal firmado y cada módulo coincida con su hash.
- La clave pública de confianza, secretos, bases financieras y definición de la tarea de Windows permanecen fuera de esta sincronización.
- Mantiene el único escritor Binance Spot Testnet en el TradingEngine unificado y LIVE bloqueado.

# Actualización 0.6.22 — auto-recuperación, limpieza y pipeline de promoción

- Añade un watchdog local que compara el modo real del motor con el agente del portal y reinicia únicamente el agente saliente cuando queda desincronizado o su heartbeat se estanca. Un error HTTPS reciente no provoca bucles de reinicio.
- «Reparar conexión del portal» reinicia el agente incluso cuando sus módulos ya están actualizados, corrigiendo el caso observado en 0.6.20 donde el motor estaba en TESTNET y el agente seguía reportando PAPER.
- El centro local de actualizaciones devuelve códigos seguros y accionables en vez de mostrar solo `RuntimeError` / `ValueError`.
- La app de Windows muestra el modo real PAPER/TESTNET leído del motor; ya no deja un badge PAPER estático después de un cambio correcto de entorno.
- Retira el antiguo piloto manual de órdenes Testnet del portal y de los controles remotos. El único escritor de Binance Spot Testnet es ahora el broker del TradingEngine unificado.
- Separa el transporte firmado mínimo de Binance Spot Testnet en `trader/testnet_transport.py`, con host fijo de Testnet y sin ruta LIVE.
- Elimina código/UI ya fuera del build activo (`portal_web/`) y el ZIP histórico v0.5.0 almacenado en el repo. No se borran ledgers, historial financiero ni respaldos operativos.
- Conserva deliberadamente dos ledgers: `data/trader.db` para PAPER y `data/testnet-trader.db` para TESTNET. No se fusionan para evitar mezclar posiciones, P&L y equity entre entornos.
- Research Lab muestra un pipeline explícito de promoción: RESEARCH → CANDIDATE → FORWARD_TEST → TESTNET → APPROVED. Una estrategia que supera todas las puertas se recomienda para forward test, pero ninguna etapa se activa automáticamente.
- La recomendación de cada candidato incluye motivo, siguiente acción y requisitos mínimos previstos del forward test (30 días y 30 cierres, retorno neto positivo y ventaja frente al benchmark). Toda promoción exige aprobación del propietario.
- `APPROVED` nunca habilita LIVE. Binance LIVE continúa siendo una autorización separada, no implementada por este release.

# Actualización 0.6.21 — corrección de sincronización PAPER ↔ TESTNET

- Corrige el agente remoto para aceptar el cambio supervisado entre `data/trader.db` y `data/testnet-trader.db` dentro de la misma instalación. En 0.6.20 podía rechazar este cambio y dejar el portal mostrando un snapshot PAPER antiguo aunque el motor hubiera cambiado.
- Añade códigos de fallo seguros y mensajes claros en Actividad para credenciales Binance Testnet, trading deshabilitado, motor no saludable, mantenimiento, timeout de parada, fallo de health-check y configuración local no disponible.
- Mantiene Binance LIVE bloqueado y no modifica las reglas de riesgo ni la promoción automática de estrategias.

# Actualización 0.6.20 — motor único Binance Spot Testnet y promoción de estrategias

- Añade un único motor con dos entornos permitidos: PAPER y Binance Spot Testnet. Binance LIVE continúa sin implementación ni ruta de escritura.
- El modo Testnet usa el mismo TradingEngine, estrategia, revisión IA, límites, stops y seis niveles de riesgo; solo cambia el broker de ejecución.
- PAPER y Testnet conservan bases financieras separadas para no mezclar posiciones, P&L ni equity.
- Las órdenes automáticas Testnet guardan identidad durable antes del único POST, nunca reintentan una escritura incierta y exigen conciliación antes de otra orden.
- El supervisor, agente HTTPS, portal y actualizador reconocen PAPER/TESTNET sin duplicar motores. El cambio de entorno es supervisado desde Opciones y exige credenciales Spot Testnet operables.
- El piloto manual Testnet anterior se bloquea cuando el motor unificado está en TESTNET, evitando dos escritores sobre la misma cuenta.
- El cierre manual de una posición usa PaperBroker en PAPER y BinanceTestnetBroker en TESTNET.
- Research Lab sigue aislado de ejecución y ahora publica un pipeline explícito RESEARCH → CANDIDATE → FORWARD_TEST → TESTNET → APPROVED → RETIRED. Ningún candidato se activa automáticamente.

# Actualización 0.6.19 — seis niveles y evidencia Binance Spot Testnet

- Seis niveles para el tamaño de nuevas entradas PAPER: Mínimo 25%, Leve 35%, Prudente 50%, Moderado 65%, Alto 85% y Muy alto 100% del límite configurado. Los valores guardados anteriormente para Mínimo, Prudente y Normal conservan exactamente su significado; «Muy alto» muestra el límite que antes se llamaba «Normal». No aumenta el riesgo base ni el límite de exposición.
- El panel Testnet distingue posición abierta, una entrada ya realizada en el día UTC, conciliación pendiente y vueltas completas. Solo habilita comprar o cerrar cuando el registro permite esa operación. Muestra variación **bruta** de vueltas cerradas, sin afirmar rentabilidad neta cuando no están verificadas las comisiones.
- «Comprobar órdenes y saldo en Binance» consulta el resultado de hasta diez órdenes propias y los saldos BTC/USDT en Spot Testnet; señala diferencias respecto al registro local y bloquea nuevas operaciones si detecta una. La consulta no envía órdenes. El ensayo sigue siendo manual: ninguna estrategia envía operaciones automáticamente ni utiliza Binance de producción.

## Actualización anterior 0.6.18 — sincronización automática de la conexión del portal

- La app comprueba la instalación firmada al abrirse, después de un update local y cuando detecta uno remoto mientras sigue abierta. Si los módulos del agente independiente cambiaron, los respalda y reinicia únicamente su tarea.
- La actualización conserva «Reparar conexión del portal» como recuperación. Nunca reanuda un agente detenido intencionalmente ni reinicia el motor de trading por este motivo.
- Después de instalar 0.6.18, cierra y abre una vez la app que ya estuviera ejecutándose para cargar la mejora. Desde entonces, las siguientes instalaciones se sincronizan automáticamente mientras la app permanezca abierta.

## Actualización anterior 0.6.17 — controles del motor y primera ejecución Spot Testnet

- Menú Opciones → Modelo IA y motor: selección limitada a GPT-6 Luna o GPT-5.6 Luna y reinicio supervisado del motor PAPER. Windows comprueba la respuesta de IA antes de escribir el override local. La configuración privada sigue en la PC; el portal recibe solo el resultado. Retirados los botones redundantes de comprobación del indicador de Windows.
- Menú Opciones → Binance Testnet: compra manual BTC/USDT limitada a 25 USDT ficticios una vez al día; cierre manual de la posición registrada y conciliación por identificador de cliente. Ninguna orden va a Binance de producción. Una respuesta incierta bloquea nuevas órdenes hasta una consulta de conciliación y nunca dispara reintentos de escritura.
- Testnet y PAPER guardan registros separados. Esta primera etapa prueba ejecución y conciliación reales en Testnet, no migra la estrategia automática ni convierte el historial PAPER en P&L de Binance. El motor permanece PAPER y el uso de dinero real está deshabilitado.
- Después de instalar 0.6.17, usa Reparar conexión del portal en la PC para que el supervisor independiente reciba los nuevos controles. El estado de Testnet está disponible en el portal local y remoto, sin credenciales ni saldo privado en Cloudflare.

# Actualización 0.6.16 — controles PAPER compartidos

- El mismo panel local y remoto permite seleccionar mínimo, prudente o normal para nuevas entradas PAPER y solicitar el cierre de una posición PAPER concreta.
- El cierre exige posición idéntica, cotización nueva dentro del 2% de la vista y bloqueo de reentrada de 24 horas. No envía órdenes a Binance.
- Desde el portal remoto la solicitud permanece pendiente hasta que el supervisor de Windows confirme el resultado. El historial muestra completada, fallida o vencida.
- Después de instalar la versión firmada, el menú del indicador de Windows permite actualizar una vez los módulos verificados del supervisor independiente. El portal remoto habilita los controles cuando detecta la nueva capacidad.
- Las solicitudes remotas se guardan en la tabla de trabajos existente de D1, sin migración ni nuevos permisos para la credencial de publicación.

# Actualización 0.6.2 — estrategia fija, selector adaptativo y cash gate

## Cambios 0.6.2

- Separa el retorno fuera de muestra de la estrategia fija y del selector adaptativo.
- Corrige la ambigüedad visual que asociaba el OOS del selector con el candidato fijo.
- Añade efectivo USDT al 0% como benchmark obligatorio.
- El selector permanece en cash cuando el ganador de entrenamiento no tiene retorno, Sharpe y operaciones suficientes.
- Calcula portafolios separados para estrategias fijas y selector adaptativo con cash gate.
- Añade nueve puertas de promoción: efectivo, Sharpe OOS, consistencia, estabilidad de selección, Monte Carlo, Sharpe completo, sensibilidad, rotación y calidad de datos.
- El detalle por activo muestra resultados fijos/adaptativos, folds en cash y cada puerta aprobada o fallida.
- La exportación CSV distingue todos estos resultados.
- No modifica el motor operativo ni promueve candidatos automáticamente.

# Actualización 0.6.1 — robustez multi-régimen y portafolio

## Cambios 0.6.1

- Amplía el análisis predeterminado de 2,000 a 5,000 velas cerradas por activo.
- Usa ventanas walk-forward de 1,200 velas de entrenamiento y 400 fuera de muestra.
- Separa resultados en regímenes alcistas, laterales y bajistas.
- Añade retorno, benchmark, drawdown y Sharpe del portafolio combinado de cinco activos.
- Calcula la matriz de correlaciones con rendimientos alineados por fecha.
- Prueba sensibilidad del candidato con umbrales de entrada ±5 puntos.
- Añade vista detallada al pulsar cada activo y exportación del resumen a CSV.
- Ejecuta el trabajo pesado en un proceso separado y oculto para mantener fluidos el motor y el portal.
- Impide dos Research Labs simultáneos y detiene de forma segura una investigación antes de futuras actualizaciones.

# Actualización 0.6.0 — Research Lab multi-cripto

## Cambios 0.6.0

- Nuevo Research Lab dentro del portal para BTC, ETH, SOL, BNB y XRP.
- Compara cinco familias de estrategia por activo, sin promoción automática al motor.
- Backtesting conservador con ejecución en la vela siguiente, comisiones, slippage y resolución stop-first cuando una vela toca stop y objetivo.
- Walk-forward rodante, benchmark buy-and-hold, métricas Sharpe/Sortino/Calmar, profit factor, expectativa, exposición y rotación.
- Heurística explícita de selección/sobreajuste y 1,000 simulaciones Monte Carlo.
- Descarga paginada de hasta 10,000 velas cerradas por activo.
- Portal adaptable a móvil e instalable como aplicación web.
- Token del portal retirado de la URL y conservado solo durante la sesión del navegador.
- Cabeceras CSP, anti-framing, no-sniff y comprobación same-origin para acciones.
- El motor continúa bloqueado en PAPER y conserva exactamente sus reglas operativas actuales.

# Actualización 0.5.1 — permanencia e identidad visual de Windows

## Cambios 0.5.1

- La `X` y el botón de minimizar ocultan el Centro de Control, pero mantienen activo el indicador junto al reloj.
- La aplicación solo termina mediante `Salir del indicador` o cuando Windows cierra la sesión.
- Utiliza el bucle nativo de Windows Forms y fuerza el modo STA para mejorar la estabilidad en segundo plano.
- Activa automáticamente el inicio con Windows salvo que el usuario lo deshabilite expresamente.
- Asigna la identidad e icono propios al proceso, la ventana, la barra de tareas, el acceso de inicio y el indicador de estado.
- Reinicia el Centro de Control únicamente después de que la instancia anterior haya cerrado por completo.

# Actualización 0.5.0 — canal automático seguro

## Cambios principales

- El Centro de Control consulta automáticamente el canal estable al abrirse y cada seis horas.
- El botón de actualización descarga el paquete correcto sin pedir que el usuario busque un ZIP.
- Cada descarga se valida por HTTPS, origen, tamaño y huella SHA-256 antes de instalarse.
- La instalación siempre requiere confirmación: nunca se aplican cambios silenciosos.
- Si la red o la verificación fallan, el bot continúa ejecutando la versión instalada.
- El menú del área de notificaciones permite buscar actualizaciones o instalar un ZIP local de recuperación.
- Corrige el logotipo distorsionado del encabezado cargándolo desde PNG.
- Evita el falso aviso de error cuando el registro confirma que la actualización terminó correctamente.
- Rediseña completamente el Centro de Control con una interfaz más limpia y consistente con el portal.
- Añade tarjetas independientes para equity, rendimiento, efectivo, exposición y posiciones.
- Incorpora iconos visuales en las acciones principales.
- Añade un icono propio de Crypto AI Trader en la ventana y barra de tareas.
- El icono del área de notificaciones cambia entre verde, amarillo y rojo según el estado del motor.
- El menú del indicador muestra el estado operativo sin necesidad de abrir la aplicación.
- Corrige los caracteres españoles, acentos y símbolos en Windows PowerShell 5.1.
- Corrige el bloqueo del Centro de Control al esperar que termine el motor reiniciado.
- Reinicia automáticamente la aplicación después de instalar una versión nueva.
- Guarda registros de cada actualización dentro de `data` para facilitar diagnósticos.
- Semáforo de actividad basado en el último ciclo exitoso.
- Hora real del último ciclo, en vez de la hora de actualización del navegador.
- Precio spot y P&L no realizado estimado por posición.
- Equity calculado con el precio spot más reciente disponible.
- Stops y objetivos revisados con precio spot; las señales siguen usando velas cerradas.
- Las posiciones abiertas se vigilan aunque salgan del top de volumen.
- Panel con errores y advertencias recientes.
- Endpoint `/health` para integrar alertas externas posteriormente.

## Actualización segura en Windows

La carpeta `data` y el archivo `.env.local` no forman parte de este paquete. Al actualizar, consérvalos en la instalación existente: contienen el estado paper y las credenciales locales.

1. Detén el proceso actual `py -m trader run`.
2. Copia las carpetas `trader` y `web` de esta versión sobre las existentes.
3. Copia `tests`, `README.md` y `pyproject.toml`.
4. No reemplaces ni elimines `data`, `.env.local` o `config.toml`.
5. Ejecuta `py -m unittest discover -s tests -v`.
6. Reinicia con `py -m trader run` o vuelve a iniciar sesión para usar el arranque automático existente.

Tailscale Serve no necesita cambios: continuará apuntando a `127.0.0.1:8765`.

## Actualizador automático asistido

La versión 0.5.0 incorpora un canal estable en línea. El Centro de Control avisa cuando existe una versión nueva y puede descargarla, verificarla e instalarla con autorización del usuario. `ACTUALIZAR_BOT.cmd` y la opción de paquete local siguen disponibles como mecanismos de recuperación.

## Aplicación gráfica

`Crypto AI Trader.vbs` abre un centro de control sin mostrar PowerShell. Incluye estado, resumen de inversión, último ciclo y botones para abrir los portales, reiniciar, manejar el kill switch, configurar el inicio automático e instalar actualizaciones. Al minimizarlo queda como indicador en el área de notificaciones. El actualizador continúa disponible por consola como mecanismo alternativo de recuperación.
# 0.10.35 — Portfolio Guardian Observer and four-engine contracts

- Observes four separate ledger identities and scoped gross/net exposure,
  concentration, nominal stop distance, native status, existing budget and data
  quality. Missing/stale/overflow evidence stays unknown; bounded prioritized
  alerts cannot command orders, veto entries or modify risk.
- Quant identity remains NOT_STARTED, with no virtual wallet or execution.
- Optional authenticated `/api/platform` diagnostics, backward-compatible remote
  schema and isolated projection failures preserve the existing engine/updater.
- Guardian has no I/O or trading dependencies; no engine-cycle changes. Shared
  reservations, correlation/drawdown/liquidation analysis and Quant simulation
  remain future stages. Web/Windows four-card view is a separate next PR.
- Installed observation exposed Binance timestamps about 1.5 seconds ahead of
  Windows. Pulse freshness now matches the existing five-second ingestion bound
  while independently requiring receipt before decision, a recent eligible price
  and current depth. Old prices/future buckets remain blocked; coverage and risk
  hypotheses are unchanged. Protective simulation uses the same receipt check.
- Verify exact main CI, signed publication and Windows installation separately;
  this note is not deployment evidence.
# 0.10.36 — Four-engine portal and Windows control center

- Four responsive cards, Guardian Observer scopes/alerts/quality and Quant Funding
  Carry/Statistical Arbitrage folds share web assets locally and remotely.
- Quant remains NOT_STARTED. Null finances, unavailable controls and an explicit
  fourth comparison cohort avoid presenting a prepared identity as a running bot.
- Windows uses four compact cards in a 2x2 layout, optional async platform reads,
  Guardian status and portal links. Ownership, startup, watchdogs, trading and
  signed update/recovery functions are unchanged. PAPER protections are simulated;
  Testnet native protection remains separately evidenced.
- Missing/stale/disconnected Guardian evidence clears current valuations and
  qualifies recorded alerts/native statuses. It cannot veto or command trades.
- Android360px preview showed four cards,21 collapsed detail groups and no
  horizontal overflow. Full suites/CI/publication/install must be verified for
  this exact revision; visual draft tests alone are not installation evidence.


Validación final46 tras sincronizar el ensayo SQLite: **959/959 Python offline**
PASS en135.735s,20Oct2026 20:45:40.100180UTC, cero fallos/errores/skips, red externa
bloqueada y bot no iniciado. Producto y timeout global no se modificaron. Fixture
finito de capacidad separado de dos handoffs con barreras, comprobando ingreso de
otro motor mientras el consumidor está retenido, FULL/integridad y evidencia previa.
Foco97/97 PASS5.022s; misma demora controlada80ms/evento falla antes y pasa después.
Node223/223 PASS44.546s conserva validez: Worker/UI sin cambios posteriores.
La CI del nuevo head debe validarse antes del merge; no reutilizar el head5199e23.

## 0.10.54 candidate — 25 October 2026

Adds durable supervised cohort receipts, a finite preproduction status fold,
transactional risk/capital admission, dedicated DPAPI credentials, fixed-host
GET-only account audit and segregated prepared LIVE execution/reconciliation.
The operating engine explicitly refuses an uncommissioned LIVE adapter before
creating any financial files. No keys, activation records or numeric policy are
provisioned. Testnet Spot/Futures execution and native protections are preserved.

Pulse retains five RSS feeds and adds CFTC TFF BTC/ETH context plus a SEC EDGAR
metadata connector using the owner-authorized local contact. New context is bounded,
deduplicated, timestamped and frozen for replay; it does not add model calls,
change numeric score weights or claim daily ETF flows/parsed insider trades.
The shared portal provides a collapsible institutional panel. See
PREPRODUCTION_CLOSURE.md for exact implementation and commissioning boundaries.

Validación local final55:1427/1427 Python offline PASS303.641s a26Oct2026
20:50:20UTC, cero errores/fallos/saltos y fuentes sin cambios;293/293Node
PASS156.479s. PowerShell5.1 launcher,view/lifecycle y render sintético PASS,
sin consolas/motores reales. Revisión cruzada corrigió carrera de marcador
Windows y eco de argumentos rechazados; regresiones repetidas PASS. Paquete
allowlist294 archivos,8/8 probes privados excluidos. CI/firma/rollout55 pendientes.
