import math
import unittest

from trader.config import load_config
from trader.domain import Candle
from trader.research import build_research_report, default_profiles, monte_carlo


class ResearchTests(unittest.TestCase):
    def test_candidate_families_are_diverse_and_research_only(self):
        config = load_config()
        profiles = default_profiles(config)
        self.assertEqual(len(profiles), 5)
        self.assertGreaterEqual(len({profile.family for profile in profiles}), 5)

    def test_monte_carlo_is_repeatable(self):
        returns = [0.01, -0.006, 0.004, 0.008, -0.003]
        self.assertEqual(monte_carlo(returns, simulations=100, seed=42), monte_carlo(returns, simulations=100, seed=42))

    def test_walk_forward_report_never_auto_promotes(self):
        candles = []
        for index in range(500):
            close = 100 + index * 0.035 + math.sin(index / 8) * 2.5
            candles.append(Candle(
                open_time=index * 14_400_000,
                open=close - 0.2,
                high=close + 1.0,
                low=close - 1.0,
                close=close,
                volume=1000 + (index % 13) * 20,
                close_time=(index + 1) * 14_400_000 - 1,
            ))
        report = build_research_report({"BTCUSDT": candles}, load_config(), train_bars=180, test_bars=100)
        self.assertEqual(report["mode"], "RESEARCH_ONLY")
        self.assertFalse(report["auto_promotion"])
        self.assertEqual(len(report["assets"][0]["candidates"]), 5)
        self.assertGreaterEqual(report["assets"][0]["walk_forward"]["folds"], 3)
        self.assertIn("portfolio", report)
        self.assertIn("correlations", report)
        self.assertEqual(len(report["assets"][0]["parameter_sensitivity"]), 3)
        self.assertEqual(len(report["assets"][0]["regime_analysis"]), 3)
        asset = report["assets"][0]
        self.assertEqual(asset["walk_forward"], asset["fixed_strategy"])
        self.assertIn("adaptive_selector", asset)
        self.assertIn("cash_folds", asset["adaptive_selector"])
        self.assertEqual(len(asset["qualification"]["gates"]), 9)
        self.assertEqual(
            {fold["strategy"] for fold in asset["fixed_strategy"]["details"]},
            {asset["champion_candidate"]},
        )


if __name__ == "__main__":
    unittest.main()
