const money = value => `${Number(value || 0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} USDT`;
const num = (value, digits=6) => Number(value || 0).toLocaleString('en-US',{maximumFractionDigits:digits});
const token = new URLSearchParams(location.search).get('token') || '';
const headers = token ? {'X-Dashboard-Token': token} : {};
const esc = value => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));

async function api(path, options={}) {
  const response = await fetch(path, {...options, headers:{...headers,...(options.headers||{})}});
  if (!response.ok) throw new Error(`${path}: ${response.status}`);
  return response.json();
}

function renderChart(rows) {
  const canvas = document.getElementById('equityChart');
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  canvas.width = width * ratio; canvas.height = height * ratio;
  const ctx = canvas.getContext('2d'); ctx.scale(ratio,ratio); ctx.clearRect(0,0,width,height);
  if (!rows.length) { ctx.fillStyle='#8fa0ba'; ctx.font='14px system-ui'; ctx.fillText('La curva aparecerá después del primer ciclo.',16,height/2); return; }
  const values = rows.map(r=>Number(r.equity)); const min=Math.min(...values), max=Math.max(...values); const span=Math.max(max-min,1);
  const x=i=>18+(i/Math.max(values.length-1,1))*(width-36); const y=v=>18+(1-(v-min)/span)*(height-42);
  const gradient=ctx.createLinearGradient(0,0,0,height); gradient.addColorStop(0,'rgba(45,226,166,.28)'); gradient.addColorStop(1,'rgba(45,226,166,0)');
  ctx.beginPath(); values.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v))); ctx.lineTo(x(values.length-1),height-20); ctx.lineTo(x(0),height-20); ctx.closePath(); ctx.fillStyle=gradient; ctx.fill();
  ctx.beginPath(); values.forEach((v,i)=>i?ctx.lineTo(x(i),y(v)):ctx.moveTo(x(i),y(v))); ctx.strokeStyle='#2de2a6'; ctx.lineWidth=2; ctx.stroke();
}

function emptyRow(columns, text) { return `<tr><td colspan="${columns}" class="empty">${text}</td></tr>`; }
function feedEmpty(text) { return `<div class="empty">${text}</div>`; }
function shortTime(value) { return value ? new Date(value).toLocaleString('es-MX',{dateStyle:'short',timeStyle:'short'}) : '—'; }
function activityLabel(state) {
  return ({operational:'OPERATIVO',delayed:'RETRASADO',offline:'SIN ACTIVIDAD',starting:'INICIANDO'})[state] || 'DESCONOCIDO';
}
function ageLabel(seconds) {
  if (seconds === null || seconds === undefined) return 'sin ciclos registrados';
  if (seconds < 60) return `hace ${Math.round(seconds)} s`;
  if (seconds < 3600) return `hace ${Math.round(seconds/60)} min`;
  return `hace ${(seconds/3600).toFixed(1)} h`;
}

async function refresh() {
  try {
    const [status,positions,trades,reviews,equity,events] = await Promise.all([
      api('/api/status'),api('/api/positions'),api('/api/trades'),api('/api/ai-reviews'),api('/api/equity'),api('/api/events')
    ]);
    document.getElementById('equity').textContent=money(status.equity);
    document.getElementById('cash').textContent=money(status.cash);
    document.getElementById('exposure').textContent=money(status.exposure);
    document.getElementById('return').textContent=`${status.return_pct>=0?'+':''}${status.return_pct.toFixed(2)}% total`;
    document.getElementById('positionsCount').textContent=`${status.positions} de ${status.max_positions} posiciones`;
    document.getElementById('aiStatus').textContent=status.ai_enabled?'Activa':'Desactivada';
    document.getElementById('aiModel').textContent=status.ai_model;

    const state=document.getElementById('killState'), button=document.getElementById('killButton');
    state.textContent=status.killed?'DETENIDO':'Protecciones activas'; state.classList.toggle('killed',status.killed);
    button.textContent=status.killed?'Reanudar bot':'Activar kill switch'; button.dataset.killed=String(status.killed);

    const activity=status.activity || {state:'starting',age_seconds:null};
    const botState=document.getElementById('botState');
    botState.textContent=activityLabel(activity.state);
    botState.classList.toggle('warning',activity.state==='delayed');
    botState.classList.toggle('offline',activity.state==='offline');

    document.getElementById('positions').innerHTML=positions.length?positions.map(p=>`<tr><td><strong>${esc(p.symbol)}</strong></td><td>${num(p.quantity)}</td><td>${num(p.entry_price,4)}</td><td>${num(p.market_price,4)}</td><td class="${p.unrealized_pnl>=0?'positive':'negative'}">${p.unrealized_pnl>=0?'+':''}${num(p.unrealized_pnl,2)}</td><td class="${p.unrealized_pct>=0?'positive':'negative'}">${p.unrealized_pct>=0?'+':''}${num(p.unrealized_pct,2)}%</td><td>${num(p.stop_price,4)}</td><td>${num(p.take_profit,4)}</td><td>${num(p.high_water,4)}</td></tr>`).join(''):emptyRow(9,'Sin posiciones abiertas');
    document.getElementById('trades').innerHTML=trades.length?trades.slice(0,8).map(t=>`<div class="feed-item"><strong class="${esc(t.side.toLowerCase())}">${esc(t.side)}</strong><div><strong>${esc(t.symbol)} · ${num(t.quantity)}</strong><p>${esc(t.reason)}</p></div><time>${shortTime(t.created_at)}</time></div>`).join(''):feedEmpty('Aún no hay operaciones');
    document.getElementById('reviews').innerHTML=reviews.length?reviews.slice(0,8).map(r=>`<div class="feed-item"><strong class="${esc(r.verdict.toLowerCase())}">${esc(r.verdict)}</strong><div><strong>${esc(r.symbol)} · ${(r.confidence*100).toFixed(0)}%</strong><p>${esc(r.reason)}</p></div><time>${shortTime(r.created_at)}</time></div>`).join(''):feedEmpty('Aún no hay revisiones');
    const important=events.filter(e=>['WARN','ERROR','CRITICAL'].includes(e.level)).slice(0,10);
    document.getElementById('events').innerHTML=important.length?important.map(e=>`<div class="feed-item"><strong class="event-${esc(e.level.toLowerCase())}">${esc(e.level)}</strong><div><p>${esc(e.message)}</p></div><time>${shortTime(e.created_at)}</time></div>`).join(''):feedEmpty('Sin errores ni advertencias recientes');
    renderChart(equity);
    document.getElementById('updated').textContent=`Último ciclo ${ageLabel(activity.age_seconds)} · ${shortTime(activity.last_cycle_at)}`;
  } catch(error) {
    const botState=document.getElementById('botState');
    botState.textContent='PORTAL SIN CONEXIÓN'; botState.classList.add('offline');
    document.getElementById('updated').textContent='No fue posible consultar el motor';
  }
}

document.getElementById('killButton').addEventListener('click', async event => {
  const killed=event.currentTarget.dataset.killed==='true';
  const message=killed?'¿Reanudar la evaluación de nuevas operaciones?':'¿Detener inmediatamente toda nueva operación?';
  if (!confirm(message)) return;
  await api(killed?'/api/resume':'/api/kill',{method:'POST'}); await refresh();
});
window.addEventListener('resize',()=>api('/api/equity').then(renderChart).catch(()=>{}));
refresh(); setInterval(refresh,15000);
