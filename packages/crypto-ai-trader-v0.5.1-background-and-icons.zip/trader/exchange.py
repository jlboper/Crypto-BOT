from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from .domain import Candle


class ExchangeError(RuntimeError):
    pass


class BinanceClient:
    def __init__(self, base_url: str = "https://api.binance.com", timeout: int = 20) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.api_key = os.getenv("BINANCE_API_KEY", "")
        self.api_secret = os.getenv("BINANCE_API_SECRET", "")

    def _request(self, method: str, path: str, params: dict[str, Any] | None = None, signed: bool = False) -> Any:
        params = dict(params or {})
        headers = {"User-Agent": "CryptoAITradingBot/0.1"}
        if signed:
            if not self.api_key or not self.api_secret:
                raise ExchangeError("BINANCE_API_KEY and BINANCE_API_SECRET are required")
            params["timestamp"] = int(time.time() * 1000)
            params["recvWindow"] = 5000
            query = urllib.parse.urlencode(params)
            params["signature"] = hmac.new(self.api_secret.encode(), query.encode(), hashlib.sha256).hexdigest()
            headers["X-MBX-APIKEY"] = self.api_key
        encoded = urllib.parse.urlencode(params)
        url = f"{self.base_url}{path}"
        data = None
        if method in {"POST", "PUT", "DELETE"}:
            data = encoded.encode()
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        elif encoded:
            url = f"{url}?{encoded}"
        request = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:500]
            raise ExchangeError(f"Binance HTTP {exc.code}: {detail}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise ExchangeError(f"Binance connection failed: {exc}") from exc

    def server_time(self) -> int:
        return int(self._request("GET", "/api/v3/time")["serverTime"])

    def top_usdt_symbols(self, limit: int) -> list[str]:
        info = self._request("GET", "/api/v3/exchangeInfo")
        tickers = self._request("GET", "/api/v3/ticker/24hr")
        excluded_bases = {"USDC", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "TRY", "BRL", "MXN"}
        allowed: set[str] = set()
        for item in info.get("symbols", []):
            base = item.get("baseAsset", "")
            symbol = item.get("symbol", "")
            if (
                item.get("status") == "TRADING"
                and item.get("quoteAsset") == "USDT"
                and item.get("isSpotTradingAllowed", True)
                and base not in excluded_bases
                and not base.endswith(("UP", "DOWN", "BULL", "BEAR"))
            ):
                allowed.add(symbol)
        ranked = sorted(
            (item for item in tickers if item.get("symbol") in allowed),
            key=lambda item: float(item.get("quoteVolume", 0.0)),
            reverse=True,
        )
        symbols = [item["symbol"] for item in ranked[:limit]]
        if "BTCUSDT" not in symbols:
            symbols.insert(0, "BTCUSDT")
        return symbols

    def candles(self, symbol: str, interval: str, limit: int = 250) -> list[Candle]:
        payload = self._request("GET", "/api/v3/klines", {"symbol": symbol, "interval": interval, "limit": limit})
        now_ms = int(time.time() * 1000)
        candles = [
            Candle(
                open_time=int(row[0]),
                open=float(row[1]),
                high=float(row[2]),
                low=float(row[3]),
                close=float(row[4]),
                volume=float(row[5]),
                close_time=int(row[6]),
            )
            for row in payload
        ]
        return [candle for candle in candles if candle.close_time < now_ms]

    def latest_prices(self, symbols: set[str] | list[str] | tuple[str, ...]) -> dict[str, float]:
        wanted = set(symbols)
        if not wanted:
            return {}
        payload = self._request("GET", "/api/v3/ticker/price")
        return {
            str(item["symbol"]): float(item["price"])
            for item in payload
            if item.get("symbol") in wanted
        }

    def verify_testnet_credentials(self) -> dict[str, Any]:
        original = self.base_url
        self.base_url = "https://testnet.binance.vision"
        try:
            account = self._request("GET", "/api/v3/account", signed=True)
            return {
                "can_trade": bool(account.get("canTrade")),
                "account_type": account.get("accountType"),
                "permissions": account.get("permissions", []),
            }
        finally:
            self.base_url = original
