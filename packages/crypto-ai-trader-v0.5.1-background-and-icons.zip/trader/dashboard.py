from __future__ import annotations

import json
import mimetypes
import os
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .config import AppConfig, PROJECT_ROOT
from .database import Database
from .monitoring import activity_status, position_metrics


WEB_ROOT = PROJECT_ROOT / "web"


class DashboardServer:
    def __init__(self, config: AppConfig, database: Database) -> None:
        self.config = config
        self.db = database
        self.db.initialize_cash(config.paper.initial_cash_usdt)
        self.token = os.getenv("DASHBOARD_TOKEN", "")
        if config.dashboard.host not in {"127.0.0.1", "localhost", "::1"} and not self.token:
            raise ValueError("DASHBOARD_TOKEN is required when dashboard is exposed beyond localhost")

    def _handler(self):
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format: str, *args) -> None:
                return

            def _authorized(self) -> bool:
                if not outer.token:
                    return True
                query_token = parse_qs(urlparse(self.path).query).get("token", [""])[0]
                return self.headers.get("X-Dashboard-Token", "") == outer.token or query_token == outer.token

            def _json(self, payload, status=HTTPStatus.OK) -> None:
                body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self) -> None:
                path = urlparse(self.path).path
                if path == "/health":
                    equity_rows = outer.db.recent("equity", 1)
                    latest_at = equity_rows[0]["created_at"] if equity_rows else None
                    activity = activity_status(latest_at, outer.config.bot.cycle_seconds)
                    healthy = activity["state"] == "operational"
                    self._json(
                        {"ok": healthy, **activity},
                        HTTPStatus.OK if healthy else HTTPStatus.SERVICE_UNAVAILABLE,
                    )
                    return
                if path.startswith("/api/"):
                    if not self._authorized():
                        self._json({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
                        return
                    self._api(path)
                    return
                self._static(path)

            def do_POST(self) -> None:
                path = urlparse(self.path).path
                if not self._authorized():
                    self._json({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
                    return
                if path == "/api/kill":
                    outer.config.bot.kill_switch_path.parent.mkdir(parents=True, exist_ok=True)
                    outer.config.bot.kill_switch_path.write_text("manual kill switch\n", encoding="utf-8")
                    outer.db.event("CRITICAL", "Kill switch activated from dashboard")
                    self._json({"ok": True, "killed": True})
                elif path == "/api/resume":
                    outer.config.bot.kill_switch_path.unlink(missing_ok=True)
                    outer.db.event("INFO", "Kill switch cleared from dashboard")
                    self._json({"ok": True, "killed": False})
                else:
                    self._json({"error": "not found"}, HTTPStatus.NOT_FOUND)

            def _api(self, path: str) -> None:
                if path == "/api/status":
                    equity_rows = outer.db.recent("equity", 1)
                    latest = equity_rows[0] if equity_rows else {}
                    initial = outer.config.paper.initial_cash_usdt
                    current = float(latest.get("equity", initial))
                    activity = activity_status(latest.get("created_at"), outer.config.bot.cycle_seconds)
                    prices, prices_at = outer.db.market_snapshot()
                    self._json({
                        "mode": "PAPER",
                        "killed": outer.config.bot.kill_switch_path.exists(),
                        "ai_enabled": outer.config.ai.enabled,
                        "ai_model": outer.config.ai.model,
                        "equity": current,
                        "cash": float(latest.get("cash", outer.db.cash())),
                        "exposure": float(latest.get("exposure", 0)),
                        "return_pct": ((current / initial) - 1) * 100 if initial else 0,
                        "positions": len(outer.db.positions()),
                        "max_positions": outer.config.risk.max_positions,
                        "cycle_seconds": outer.config.bot.cycle_seconds,
                        "activity": activity,
                        "prices_at": prices_at,
                        "market_prices": len(prices),
                    })
                elif path == "/api/positions":
                    prices, prices_at = outer.db.market_snapshot()
                    rows = []
                    for position in outer.db.positions():
                        price = prices.get(position.symbol, position.entry_price)
                        row = position_metrics(position, price, outer.config.paper)
                        row["price_as_of"] = prices_at
                        rows.append(row)
                    self._json(rows)
                elif path == "/api/trades":
                    self._json(outer.db.recent("trades", 50))
                elif path == "/api/signals":
                    self._json(outer.db.recent("signals", 50))
                elif path == "/api/equity":
                    self._json(list(reversed(outer.db.recent("equity", 300))))
                elif path == "/api/events":
                    self._json(outer.db.recent("events", 50))
                elif path == "/api/ai-reviews":
                    self._json(outer.db.recent("ai_reviews", 50))
                else:
                    self._json({"error": "not found"}, HTTPStatus.NOT_FOUND)

            def _static(self, path: str) -> None:
                relative = "index.html" if path in {"", "/"} else path.lstrip("/")
                candidate = (WEB_ROOT / relative).resolve()
                if WEB_ROOT.resolve() not in candidate.parents and candidate != WEB_ROOT.resolve():
                    self.send_error(HTTPStatus.NOT_FOUND)
                    return
                if not candidate.is_file():
                    self.send_error(HTTPStatus.NOT_FOUND)
                    return
                body = candidate.read_bytes()
                content_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        return Handler

    def serve_forever(self) -> None:
        server = ThreadingHTTPServer((self.config.dashboard.host, self.config.dashboard.port), self._handler())
        server.serve_forever()

    def start_thread(self) -> threading.Thread:
        thread = threading.Thread(target=self.serve_forever, name="dashboard", daemon=True)
        thread.start()
        return thread
