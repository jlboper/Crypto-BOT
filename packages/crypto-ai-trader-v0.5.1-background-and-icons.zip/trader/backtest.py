from __future__ import annotations

from dataclasses import dataclass

from .config import AppConfig
from .domain import Candle
from .indicators import max_drawdown
from .strategy import SwingStrategy


@dataclass(frozen=True)
class BacktestResult:
    symbol: str
    start_cash: float
    end_equity: float
    return_pct: float
    max_drawdown_pct: float
    trades: int
    win_rate_pct: float


def run_backtest(symbol: str, candles: list[Candle], config: AppConfig) -> BacktestResult:
    strategy = SwingStrategy(config.strategy, config.risk)
    warmup = max(config.strategy.ema_slow + 5, config.strategy.breakout_period + 2)
    cash = config.paper.initial_cash_usdt
    quantity = 0.0
    entry = stop = target = 0.0
    wins = completed = 0
    curve: list[float] = [cash]
    for index in range(warmup, len(candles)):
        window = candles[: index + 1]
        price = candles[index].close
        if quantity > 0:
            if price <= stop or price >= target:
                exit_price = price * (1 - config.paper.slippage_rate)
                proceeds = exit_price * quantity
                fee = proceeds * config.paper.fee_rate
                pnl = (exit_price - entry) * quantity - fee
                wins += int(pnl > 0)
                completed += 1
                cash += proceeds - fee
                quantity = 0.0
            else:
                exit_signal, _ = strategy.should_exit(window)
                if exit_signal:
                    proceeds = price * quantity * (1 - config.paper.fee_rate)
                    wins += int(proceeds > entry * quantity)
                    completed += 1
                    cash += proceeds
                    quantity = 0.0
        if quantity == 0:
            signal = strategy.evaluate(symbol, window, btc_bullish=True)
            if signal.action == "BUY" and signal.stop_price is not None and signal.take_profit is not None:
                allocation = min(cash, cash * config.risk.max_position_pct)
                entry = price * (1 + config.paper.slippage_rate)
                fee = allocation * config.paper.fee_rate
                quantity = max(0.0, (allocation - fee) / entry)
                cash -= allocation
                stop = signal.stop_price
                target = signal.take_profit
        curve.append(cash + quantity * price)
    end_equity = cash + quantity * candles[-1].close
    return BacktestResult(
        symbol=symbol,
        start_cash=config.paper.initial_cash_usdt,
        end_equity=end_equity,
        return_pct=(end_equity / config.paper.initial_cash_usdt - 1) * 100,
        max_drawdown_pct=max_drawdown(curve) * 100,
        trades=completed,
        win_rate_pct=(wins / completed * 100) if completed else 0.0,
    )

