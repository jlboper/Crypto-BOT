import unittest
from unittest.mock import patch

from trader.exchange import BinanceClient


class ExchangeTests(unittest.TestCase):
    def test_latest_prices_filters_requested_symbols(self):
        payload = [
            {"symbol": "BTCUSDT", "price": "60000.5"},
            {"symbol": "ETHUSDT", "price": "2500.25"},
            {"symbol": "OTHERUSDT", "price": "1.0"},
        ]
        client = BinanceClient()
        with patch.object(client, "_request", return_value=payload):
            prices = client.latest_prices({"BTCUSDT", "ETHUSDT"})
        self.assertEqual(prices, {"BTCUSDT": 60000.5, "ETHUSDT": 2500.25})


if __name__ == "__main__":
    unittest.main()
