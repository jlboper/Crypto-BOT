import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from trader.remote_paper_controls import RemotePaperControls


class RemotePaperControlTests(unittest.TestCase):
    def test_market_pulse_pause_is_persisted_and_never_replayed(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            script = root / 'bot/scripts/execute_paper_control.py'
            script.parent.mkdir(parents=True)
            script.write_text('# signed installed code')
            agent = RemotePaperControls(root / 'supervisor', root / 'bot')
            item = {'id': 23, 'action': 'market_pulse_pause', 'expires': time.time() + 200, 'payload': {}}
            with patch('trader.remote_paper_controls.subprocess.run') as run:
                run.return_value.returncode = 0
                run.return_value.stdout = json.dumps({'ok': True, 'market_pulse': {'state': 'PAUSED'}})
                agent.apply(item)
                agent.apply(item)
                run.assert_called_once()
                self.assertIn('execute_paper_control.py', run.call_args.args[0][3])
                self.assertEqual(json.loads(run.call_args.kwargs['input']),
                                 {'action': 'market_pulse_pause', 'payload': {}})
            self.assertEqual(agent.results()[0]['status'], 'completed')
            self.assertIn('SHADOW', agent.results()[0]['message'])

    def test_persist_before_execution_and_replay_does_not_repeat_close(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            script = root / 'bot/scripts/execute_paper_control.py'
            script.parent.mkdir(parents=True)
            script.write_text('# signed installed code')
            agent = RemotePaperControls(root / 'supervisor', root / 'bot')
            item = {'id': 17, 'action': 'paper_close', 'expires': time.time() + 200,
                    'payload': {'symbol': 'BTCUSDT', 'opened_at': 'sample', 'reference_price': 100}}
            with patch('trader.remote_paper_controls.subprocess.run') as run:
                run.return_value.returncode = 0
                run.return_value.stdout = json.dumps({'ok': True, 'symbol': 'BTCUSDT'})
                agent.apply(item)
                agent.apply(item)
                run.assert_called_once()
            self.assertEqual(agent.results()[0]['status'], 'completed')
            with self.assertRaisesRegex(ValueError, 'conflict'):
                agent.apply({**item, 'payload': {**item['payload'], 'reference_price': 102}})


    def test_futures_failure_surfaces_safe_binance_detail(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            script = root / 'bot/scripts/execute_paper_control.py'
            script.parent.mkdir(parents=True)
            script.write_text('# signed installed code')
            agent = RemotePaperControls(root / 'supervisor', root / 'bot')
            item = {'id': 19, 'action': 'futures_testnet_check', 'expires': time.time() + 200,
                    'payload': {}}
            with patch('trader.remote_paper_controls.subprocess.run') as run:
                run.return_value.returncode = 1
                run.return_value.stdout = json.dumps({
                    'ok': False,
                    'reason': 'FUTURES_TESTNET_EXECUTION_FAILED',
                    'detail': 'Futures Demo HTTP 400 · Binance -4164: Order notional must be no smaller than 100'
                })
                agent.apply(item)
            result = agent.results()[0]
            self.assertEqual(result['status'], 'failed')
            self.assertIn('Binance -4164', result['message'])
            self.assertLessEqual(len(result['message']), 290)

    def test_uncertain_result_fails_closed(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            script = root / 'bot/scripts/execute_paper_control.py'
            script.parent.mkdir(parents=True)
            script.write_text('# signed installed code')
            agent = RemotePaperControls(root / 'supervisor', root / 'bot')
            item = {'id': 18, 'action': 'risk_profile', 'expires': time.time() + 200,
                    'payload': {'profile': 'prudente'}}
            with patch('trader.remote_paper_controls.subprocess.run',side_effect=TimeoutError):
                agent.apply(item)
            self.assertEqual(agent.results()[0]['status'], 'failed')
