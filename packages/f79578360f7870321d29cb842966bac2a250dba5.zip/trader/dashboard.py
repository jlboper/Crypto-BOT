from __future__ import annotations

import json
from dataclasses import asdict
import hmac
import mimetypes
import os
import socket
import subprocess
import sys
import threading
import time
import tomllib
from datetime import UTC, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .research_runtime import studied_symbols
from .config import AppConfig, PROJECT_ROOT
from .database import Database
from .monitoring import activity_status, position_metrics, usable_price, spot_cycle_status
from .risk_control import profile_name


WEB_ROOT = PROJECT_ROOT / "web"


class LocalHTTPServer(ThreadingHTTPServer):
    # Windows SO_REUSEADDR can let two servers bind the same port.
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        if os.name == "nt":
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class DashboardServer:
    def __init__(self, config: AppConfig, database: Database) -> None:
        self.config = config
        self.db = database
        self.db.initialize_cash(config.paper.initial_cash_usdt)
        self.token = os.getenv("DASHBOARD_TOKEN", "")
        from .research_runtime import ResearchScheduler
        self._lab = ResearchScheduler(config)
        self._lab_stop = threading.Event()
        self._research_lock = threading.Lock()
        self._research_state = {"running": False, "started_at": None, "error": None, "process_id": None}
        self._platform_lock = threading.Lock()
        self._platform_cache = None
        self._platform_cached_at = 0.0
        if config.dashboard.host not in {"127.0.0.1", "localhost", "::1"} and not self.token:
            raise ValueError("DASHBOARD_TOKEN is required when dashboard is exposed beyond localhost")

    def _platform_snapshot(self):
        """Optional read-only diagnostics, outside all entry/protection cycles."""
        from .portfolio_guardian import engine_catalog, guardian_unavailable, quant_not_started
        from .portal_snapshot import dashboard_snapshot, quant_projection
        with self._platform_lock:
            current = time.monotonic()
            if self._platform_cache is not None and current - self._platform_cached_at < 10:
                return self._platform_cache
            try:
                payload = dashboard_snapshot(self.config)
                result = {key: payload[key] for key in ('engine_catalog', 'portfolio_guardian', 'quant')}
            except Exception:
                # A broken optional projection neither touches state nor controls
                # Spot, Futures, Pulse, reconciliation or protective orders.
                try:
                    quant = quant_projection(self.config)
                except Exception as error:
                    # A failed broader dashboard is not evidence that Quant has
                    # never started. Independently unavailable ledgers stay unknown.
                    quant = quant_not_started()
                    quant.update(state='DEGRADED', health={'last_error': 'SHADOW_LEDGER_UNAVAILABLE',
                                                         'error_type': type(error).__name__[:80]})
                result = {'engine_catalog': engine_catalog({'status': {'mode': self.config.bot.mode.upper()},
                                                           'quant': quant}),
                          'portfolio_guardian': guardian_unavailable(), 'quant': quant}
            from .portal_snapshot import guardian_intelligence_projection, capital_lab_projection
            intelligence = guardian_intelligence_projection(self.config)
            if intelligence is not None:
                result['guardian_intelligence'] = intelligence
            capital_lab = capital_lab_projection(self.config)
            if capital_lab is not None:
                result['capital_lab'] = capital_lab
            self._platform_cache = result
            self._platform_cached_at = time.monotonic()
            return result

    def _handler(self):
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, format: str, *args) -> None:
                return

            def _authorized(self) -> bool:
                host = urlparse("//" + self.headers.get("Host", "")).hostname
                if outer.config.dashboard.host in {"127.0.0.1", "localhost", "::1"} and host not in {"127.0.0.1", "localhost", "::1"}:
                    return False
                if not outer.token:
                    return True
                return hmac.compare_digest(self.headers.get("X-Dashboard-Token", ""), outer.token)

            def _same_origin(self) -> bool:
                origin = self.headers.get("Origin")
                if not origin:
                    return True
                return urlparse(origin).netloc == self.headers.get("Host", "")

            def _common_headers(self) -> None:
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
                self.send_header(
                    "Content-Security-Policy",
                    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
                    "connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
                )

            def _json(self, payload, status=HTTPStatus.OK) -> None:
                body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self._common_headers()
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self) -> None:
                path = urlparse(self.path).path
                if path == "/health/runtime":
                    host = urlparse("//" + self.headers.get("Host", "")).hostname
                    if self.client_address[0] not in {"127.0.0.1", "::1"} or host not in {"127.0.0.1", "localhost", "::1"}:
                        self._json({"error": "loopback only"}, HTTPStatus.FORBIDDEN)
                    elif not hasattr(outer, "runtime_token"):
                        self._json({"error": "runtime not supervised"}, HTTPStatus.SERVICE_UNAVAILABLE)
                    else:
                        self._json({"pid": os.getpid(), "token": outer.runtime_token, "mode": outer.config.bot.mode})
                    return
                if path == "/health":
                    equity_rows = outer.db.recent("equity", 1)
                    latest_at = equity_rows[0]["created_at"] if equity_rows else None
                    activity = activity_status(latest_at, outer.config.bot.cycle_seconds)
                    healthy = activity["state"] == "operational"
                    self._json(
                        {"ok": healthy, **activity},
                        HTTPStatus.OK if healthy else HTTPStatus.SERVICE_UNAVAILABLE,
                    )
                    return
                if path.startswith("/api/"):
                    if not self._authorized():
                        self._json({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
                        return
                    self._api(path)
                    return
                self._static(path)

            def do_POST(self) -> None:
                path = urlparse(self.path).path
                if (outer.config.bot.database_path.parent / "UPDATE_MAINTENANCE.json").exists():
                    self._json({"error": "update maintenance in progress"}, HTTPStatus.SERVICE_UNAVAILABLE)
                    return
                if not self._authorized():
                    self._json({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
                    return
                if not self._same_origin():
                    self._json({"error": "origin not allowed"}, HTTPStatus.FORBIDDEN)
                    return
                if path in {"/api/local-update/check", "/api/local-update/install"}:
                    try:
                        if self.client_address[0] not in {"127.0.0.1", "::1"}:
                            raise ValueError("loopback only")
                        if self.headers.get("Content-Type", "").split(";", 1)[0].strip() != "application/json":
                            raise ValueError("JSON required")
                        length = int(self.headers.get("Content-Length", "0"))
                        if not 0 < length <= 512:
                            raise ValueError("Invalid request size")
                        payload = json.loads(self.rfile.read(length))
                        if not isinstance(payload, dict):
                            raise ValueError("Invalid request")
                        script = PROJECT_ROOT / "scripts" / "local_update.py"
                        python = Path(sys.executable)
                        if python.name.lower() == "pythonw.exe":
                            python = python.with_name("python.exe")
                        if path.endswith("/check"):
                            if payload:
                                raise ValueError("Check accepts no parameters")
                            result = subprocess.run(
                                [str(python), "-I", "-B", str(script), "--source", str(PROJECT_ROOT), "--check-online"],
                                cwd=PROJECT_ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL, timeout=60, check=False,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                            )
                            if result.returncode != 0 or len(result.stdout) > 8192:
                                raise RuntimeError("Local update verification failed")
                            verified = json.loads(result.stdout)
                            if verified.get("status") not in {"verified_local_package", "up_to_date"}:
                                raise RuntimeError("Local update verification failed")
                            self._json({**verified, "enabled": verified.get("status") == "verified_local_package"})
                        else:
                            release_id = payload.get("release_id")
                            if set(payload) != {"release_id"} or not isinstance(release_id, str) or len(release_id) != 64 or any(ch not in "0123456789abcdef" for ch in release_id):
                                raise ValueError("Invalid release approval")
                            log = PROJECT_ROOT / "data" / "local-update-http.log"
                            log.parent.mkdir(parents=True, exist_ok=True)
                            handle = log.open("ab")
                            try:
                                subprocess.Popen(
                                    [str(python), "-I", "-B", str(script), "--source", str(PROJECT_ROOT),
                                     "--delay-seconds", "1", "--install", release_id],
                                    cwd=PROJECT_ROOT, stdin=subprocess.DEVNULL, stdout=handle, stderr=subprocess.STDOUT,
                                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                                    close_fds=True,
                                )
                            finally:
                                handle.close()
                            self._json({"status": "pending", "release_id": release_id,
                                        "message": "Instalación local supervisada iniciada"}, HTTPStatus.ACCEPTED)
                    except ValueError:
                        self._json({"error": "Solicitud de actualización local inválida"}, HTTPStatus.CONFLICT)
                    except Exception:
                        self._json({"error": "No fue posible iniciar la actualización local"}, HTTPStatus.SERVICE_UNAVAILABLE)
                    return
                if path in {"/api/operations/model", "/api/operations/restart", "/api/operations/execution-mode", "/api/operations/testnet-smoke", "/api/operations/futures-check", "/api/operations/futures-smoke", "/api/operations/futures-reconcile", "/api/operations/futures-forward-pause", "/api/operations/futures-forward-resume", "/api/market-pulse/pause", "/api/market-pulse/resume", "/api/quant-arbitrage/pause", "/api/quant-arbitrage/resume"}:
                    try:
                        if self.headers.get('Content-Type', '').split(';', 1)[0].strip() != 'application/json':
                            raise ValueError('JSON required')
                        length = int(self.headers.get('Content-Length', '0'))
                        if not 0 < length <= 128:
                            raise ValueError('Invalid request size')
                        payload = json.loads(self.rfile.read(length))
                        if not isinstance(payload, dict):
                            raise ValueError('Invalid request')
                        action = ('ai_model' if path.endswith('/model') else
                                  'execution_mode' if path.endswith('/execution-mode') else
                                  'testnet_smoke' if path.endswith('/testnet-smoke') else
                                  'futures_testnet_check' if path.endswith('/futures-check') else
                                  'futures_testnet_smoke' if path.endswith('/futures-smoke') else
                                  'futures_testnet_reconcile' if path.endswith('/futures-reconcile') else
                                  'futures_forward_pause' if path.endswith('/futures-forward-pause') else
                                  'futures_forward_resume' if path.endswith('/futures-forward-resume') else
                                  'market_pulse_pause' if path == '/api/market-pulse/pause' else
                                  'market_pulse_resume' if path == '/api/market-pulse/resume' else
                                  'quant_arbitrage_pause' if path == '/api/quant-arbitrage/pause' else
                                  'quant_arbitrage_resume' if path == '/api/quant-arbitrage/resume' else
                                  'restart_engine')
                        invalid = (
                            (action == 'ai_model' and (set(payload) != {'model'} or payload['model'] not in {'gpt-5.6-luna','gpt-6-luna'}))
                            or (action == 'execution_mode' and (set(payload) != {'mode'} or payload['mode'] not in {'paper','testnet'}))
                            or (action in {'restart_engine','testnet_smoke','futures_testnet_check','futures_testnet_reconcile','futures_forward_pause','futures_forward_resume','market_pulse_pause','market_pulse_resume','quant_arbitrage_pause','quant_arbitrage_resume'} and bool(payload))
                            or (action == 'futures_testnet_smoke' and (
                                set(payload) != {'direction','leverage'}
                                or payload.get('direction') not in {'LONG','SHORT'}
                                or payload.get('leverage') not in {1,2,3}
                            ))
                        )
                        if invalid:
                            raise ValueError('Invalid operational request')
                        script = PROJECT_ROOT / 'scripts/execute_paper_control.py'
                        process = subprocess.Popen([sys.executable, '-I', '-B', str(script), str(PROJECT_ROOT)],
                            cwd=PROJECT_ROOT, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                        process.stdin.write(json.dumps({'action':action,'payload':payload}).encode('utf-8'))
                        process.stdin.close()
                        self._json({'status':'pending','message':'Windows está verificando el motor activo'}, HTTPStatus.ACCEPTED)
                    except (ValueError, OSError):
                        self._json({'error':'Acción no disponible'}, HTTPStatus.CONFLICT)
                    return
                if path in {"/api/paper/risk-profile", "/api/paper/close-position"}:
                    try:
                        if self.headers.get("Content-Type", "").split(";", 1)[0].strip() != "application/json":
                            raise ValueError("JSON required")
                        length = int(self.headers.get("Content-Length", "0"))
                        if not 0 < length <= 512:
                            raise ValueError("invalid body size")
                        data = json.loads(self.rfile.read(length))
                        if not isinstance(data, dict):
                            raise ValueError("object required")
                        from .paper_controls import execute
                        self._json(execute(outer.config, outer.db,
                            "risk_profile" if path == "/api/paper/risk-profile" else "paper_close", data))
                        return
                    except ValueError:
                        self._json({"error": "invalid or stale trading request"}, HTTPStatus.CONFLICT)
                        return
                    except Exception:
                        self._json({"error": "Trading action unavailable; no confirmation"}, HTTPStatus.SERVICE_UNAVAILABLE)
                        return
                if path == "/api/kill":
                    outer.config.bot.kill_switch_path.parent.mkdir(parents=True, exist_ok=True)
                    outer.config.bot.kill_switch_path.write_text("manual kill switch\n", encoding="utf-8")
                    outer.db.event("CRITICAL", "Kill switch activated from dashboard")
                    self._json({"ok": True, "killed": True})
                elif path == "/api/resume":
                    outer.config.bot.kill_switch_path.unlink(missing_ok=True)
                    outer.db.event("INFO", "Kill switch cleared from dashboard")
                    self._json({"ok": True, "killed": False})
                elif path == "/api/research/run":
                    from .research_runtime import lab_state
                    with outer._research_lock:
                        launched = outer._lab.tick(manual=True)
                    self._json({"ok": launched, **lab_state(outer.config.research.report_path)},
                               HTTPStatus.ACCEPTED if launched else HTTPStatus.CONFLICT)
                else:
                    self._json({"error": "not found"}, HTTPStatus.NOT_FOUND)

            def _api(self, path: str) -> None:
                if path == '/api/platform':
                    self._json(outer._platform_snapshot())
                    return
                if path == '/api/operations/last':
                    record = PROJECT_ROOT / 'data/operation-last.json'
                    try:
                        if record.stat().st_size > 2000:
                            raise ValueError('Oversized operation status')
                        self._json(json.loads(record.read_text(encoding='utf-8')))
                    except (OSError, ValueError):
                        self._json({'status':'unavailable'})
                    return
                if path == "/api/status":
                    from .native_protection import SPOT_KEY, projection
                    from .portal_snapshot import spot_observation_health
                    equity_rows = outer.db.recent("equity", 1)
                    latest = equity_rows[0] if equity_rows else {}
                    initial = outer.config.paper.initial_cash_usdt
                    current = float(latest.get("equity", initial))
                    activity = activity_status(latest.get("created_at"), outer.config.bot.cycle_seconds)
                    prices, prices_at = outer.db.market_snapshot()
                    self._json({
                        "mode": outer.config.bot.mode.upper(),
                        "installed_version": tomllib.loads((PROJECT_ROOT / "pyproject.toml").read_text(encoding="utf-8"))["project"]["version"],
                        "killed": outer.config.bot.kill_switch_path.exists(),
                        "ai_enabled": outer.config.ai.enabled,
                        "ai_model": outer.config.ai.model,
                        "equity": current,
                        "cash": float(latest.get("cash", outer.db.cash())),
                        "exposure": float(latest.get("exposure", 0)),
                        "return_pct": ((current / initial) - 1) * 100 if initial else 0,
                        "positions": len(outer.db.positions()),
                        "max_positions": outer.config.risk.max_positions,
                        "risk": asdict(outer.config.risk),
                        "paper_risk_profile": profile_name(outer.db),
                        "cycle_seconds": outer.config.bot.cycle_seconds,
                        "spot_cycle": spot_cycle_status(outer.db.setting("spot_last_cycle"), outer.config.bot.cycle_seconds),
                        "observation_health": spot_observation_health(outer.config),
                        "native_protection": projection(json.loads(outer.db.setting(SPOT_KEY) or '{}')) if outer.config.bot.mode == 'testnet' else None,
                        "native_protection_started_at": outer.db.setting("native_protection_started_at"),
                        "activity": activity,
                        "prices_at": prices_at,
                        "market_prices": len(prices),
                    })
                elif path == "/api/positions":
                    prices, prices_at = outer.db.market_snapshot()
                    rows = []
                    for position in outer.db.positions():
                        price = usable_price(prices.get(position.symbol), prices_at, outer.config.bot.cycle_seconds)
                        row = position_metrics(position, price, outer.config.paper)
                        row["price_as_of"] = prices_at
                        rows.append(row)
                    self._json(rows)
                elif path == "/api/trades":
                    self._json(outer.db.recent("trades", 50))
                elif path == "/api/signals":
                    self._json(outer.db.recent("signals", 50))
                elif path == "/api/equity":
                    self._json(list(reversed(outer.db.recent("equity", 300))))
                elif path == "/api/market-pulse":
                    from .portal_snapshot import market_pulse_projection
                    self._json(market_pulse_projection(outer.config))
                elif path == "/api/futures-forward":
                    from .futures_testnet_ledger import FuturesTestnetLedger
                    from .portal_snapshot import _futures_pause_diagnostics
                    ledger = FuturesTestnetLedger(outer.config.futures_testnet.database_path)
                    snapshot = ledger.forward_snapshot()
                    self._json({
                        "enabled": bool(outer.config.bot.mode == "testnet" and outer.config.futures_testnet.forward_enabled),
                        "killed": outer.config.futures_testnet.kill_switch_path.exists(),
                        "pause_diagnostics": _futures_pause_diagnostics(outer.config, ledger),
                        "observation_health": ledger.observation_health(outer.config.bot.cycle_seconds,
                            max_positions=outer.config.futures_testnet.forward_max_positions),
                        "cycle_diagnostic": ledger.setting('forward_last_cycle_diagnostic'),
                        "symbols": list(outer.config.futures_testnet.forward_symbols),
                        "automatic_leverage": outer.config.futures_testnet.forward_leverage,
                        "portfolio_budget": ledger.setting("forward_portfolio_budget"),
                        "guardrails": {"max_positions": outer.config.futures_testnet.forward_max_positions,
                            "forward_margin_usdt": outer.config.futures_testnet.forward_margin_usdt,
                            "forward_total_notional_usdt": outer.config.futures_testnet.forward_total_notional_usdt,
                            "forward_total_stop_loss_usdt": outer.config.futures_testnet.forward_total_stop_loss_usdt},
                        "leverage_trials": ledger.leverage_trial_status(
                            outer.config.futures_testnet.forward_leverage_trials, outer.config.futures_testnet.forward_margin_usdt),
                        "ai_model": outer.config.ai.model,
                        "last_ai_reviews": {symbol: ledger.setting(f"forward_last_ai_review_{symbol}") for symbol in outer.config.futures_testnet.forward_symbols},
                        "symbol_health": ledger.setting("forward_symbol_health") or {},
                        "last_auto_recovery": ledger.setting("forward_last_auto_recovery"),
                        "recovery": {
                            "durable_order_journal": True,
                            "startup_position_reconciliation": True,
                            "separate_kill_switch": True,
                            "automatic_config_repair": True,
                            "automatic_safe_resume": True,
                            "native_exchange_stop_orders": True,
                        },
                        "live_readiness": {
                            "enabled": False,
                            "reason": "LIVE remains disabled. Native orders require per-position exchange confirmation and Demo observation.",
                        },
                        **snapshot,
                    })
                elif path == "/api/paper-scorecard":
                    import sqlite3
                    from contextlib import closing
                    from .paper_scorecard import paper_scorecard
                    with closing(sqlite3.connect(outer.config.bot.database_path.resolve().as_uri()+'?mode=ro', uri=True, timeout=3)) as connection:
                        prices, prices_at = outer.db.market_snapshot()
                        self._json(paper_scorecard(connection, prices=prices, prices_at=prices_at,
                            cycle_seconds=outer.config.bot.cycle_seconds, paper=outer.config.paper, mode=outer.config.bot.mode,
                            research_symbols=studied_symbols(outer.config.research.report_path, outer.config.research.symbols)))
                elif path == "/api/events":
                    self._json(outer.db.recent("events", 50))
                elif path == "/api/ai-reviews":
                    self._json(outer.db.recent("ai_reviews", 50))
                elif path == "/api/research/status":
                    from .research_runtime import lab_state
                    self._json(lab_state(outer.config.research.report_path, automatic=outer.config.research.automatic))
                elif path == "/api/research":
                    report_path = outer.config.research.report_path
                    if not report_path.is_file():
                        self._json({
                            "version": "0.6.2",
                            "mode": "RESEARCH_ONLY",
                            "status": "NOT_RUN",
                            "assets": [],
                        })
                        return
                    try:
                        from .research_runtime import project_report
                        self._json(project_report(json.loads(report_path.read_text(encoding="utf-8"))))
                    except (OSError, json.JSONDecodeError):
                        self._json({"error": "research report unavailable"}, HTTPStatus.SERVICE_UNAVAILABLE)
                else:
                    self._json({"error": "not found"}, HTTPStatus.NOT_FOUND)

            def _static(self, path: str) -> None:
                relative = "index.html" if path in {"", "/"} else path.lstrip("/")
                candidate = (WEB_ROOT / relative).resolve()
                if WEB_ROOT.resolve() not in candidate.parents and candidate != WEB_ROOT.resolve():
                    self.send_error(HTTPStatus.NOT_FOUND)
                    return
                if not candidate.is_file():
                    self.send_error(HTTPStatus.NOT_FOUND)
                    return
                body = candidate.read_bytes()
                content_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
                if candidate.suffix == ".webmanifest":
                    content_type = "application/manifest+json"
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", content_type)
                self.send_header("Cache-Control", "no-cache")
                self._common_headers()
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        return Handler

    def _start_lab_scheduler(self) -> None:
        def scheduled():
            while not self._lab_stop.wait(30):
                try:
                    with self._research_lock:
                        self._lab.tick()
                except Exception as error:
                    self.db.event('WARN', 'Research scheduling: '+type(error).__name__)
        threading.Thread(target=scheduled, name='research-scheduler', daemon=True).start()

    def serve_forever(self) -> None:
        server = LocalHTTPServer((self.config.dashboard.host, self.config.dashboard.port), self._handler())
        self.server = server
        self._start_lab_scheduler()
        server.serve_forever()

    def start_thread(self) -> threading.Thread:
        # Bind synchronously so callers cannot report healthy after a bind failure.
        server = LocalHTTPServer((self.config.dashboard.host, self.config.dashboard.port), self._handler())
        self.server = server
        thread = threading.Thread(target=server.serve_forever, name="dashboard", daemon=True)
        thread.start()
        self._start_lab_scheduler()
        return thread

    def close(self):
        self._lab_stop.set()
        server = getattr(self, "server", None)
        if server is not None:
            server.shutdown()
            server.server_close()
