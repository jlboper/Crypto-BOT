/* One UI, local APIs or authenticated remote snapshots. No credentials in URLs. */
const remotePortal = !['127.0.0.1','localhost','[::1]','::1'].includes(location.hostname);
let portalCsrf = '', portalPending, portalCache, portalCacheAt = 0, portalEpoch=0;
const portalBusyButtons=new Set();
function setPortalBusy(id,busy,label){
  const button=document.getElementById(id);
  if(!button)return;
  if(busy){
    portalBusyButtons.add(id);
    if(button.dataset.busyOriginal===undefined)button.dataset.busyOriginal=button.textContent;
    button.disabled=true;
    if(label)button.textContent=label;
  }else{
    portalBusyButtons.delete(id);
    if(button.dataset.busyOriginal!==undefined){
      button.textContent=button.dataset.busyOriginal;
      delete button.dataset.busyOriginal;
    }
  }
}
window.portalButtonBusy=id=>portalBusyButtons.has(id);
const portalRoute = {'/api/status':'status','/api/positions':'positions','/api/trades':'trades','/api/ai-reviews':'reviews','/api/equity':'equity','/api/events':'events','/api/research':'research','/api/research/status':'research_state','/api/updates':'updates','/api/paper-scorecard':'paper_scorecard','/api/futures-forward':'futures_forward'};
async function portalPasswordProof(password,parameters){
  if(parameters.scheme==='initial-key')return password;
  if(parameters.scheme!=='pbkdf2-sha256'||parameters.iterations!==600000||!/^[A-Za-z0-9_-]{43}$/.test(parameters.salt||''))throw new Error('Parámetros de acceso inválidos');
  const encoder=new TextEncoder();
  const key=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',iterations:600000,salt:encoder.encode(parameters.salt)},key,256);
  return Array.from(new Uint8Array(bits),b=>b.toString(16).padStart(2,'0')).join('');
}
function portalLocked(){
  portalEpoch++;
  portalCsrf='';portalPending=null;portalCache=null;portalCacheAt=0;
  const menu=document.getElementById('optionsMenu');menu.hidden=true;
  document.getElementById('optionsButton').setAttribute('aria-expanded','false');
  document.getElementById('portalLogin').hidden=false;
  document.querySelector('.shell').hidden=true;
  document.getElementById('passwordPanel').hidden=true;
  document.getElementById('historyPanel').hidden=true;
  document.getElementById('historyRows').replaceChildren();
  for(const id of ['currentPassword','newPassword','confirmPassword'])document.getElementById(id).value='';
}
async function portalRequest(path,body){
  const headers={Accept:'application/json'};
  if(body!==undefined){headers['Content-Type']='application/json';headers['X-CSRF-Token']=portalCsrf;}
  const response=await fetch(path,{method:body===undefined?'GET':'POST',credentials:'same-origin',cache:'no-store',headers,...(body===undefined?{}:{body:JSON.stringify(body)})});
  let data;
  try{data=await response.json();}catch{throw new Error(response.ok?'Respuesta inválida del portal':'Error de conexión');}
  if(!response.ok){if(response.status===401)portalLocked();throw new Error(data.error||'Error de conexión');}
  return data;
}
const activityActions={research:'Evaluar estrategias',update_check:'Buscar actualización',update_install:'Actualizar bot',update_restore:'Restaurar bot',kill:'Pausar bot',resume:'Reanudar bot',risk_profile:'Perfil de riesgo',paper_close:'Cerrar posición',ai_model:'Cambiar modelo IA',restart_engine:'Reiniciar motor',execution_mode:'Cambiar entorno',testnet_smoke:'Prueba Spot Testnet',futures_testnet_check:'Verificar Futures',futures_testnet_smoke:'Prueba Futures',futures_testnet_reconcile:'Reconciliar Futures',futures_forward_pause:'Pausar Futures automático',futures_forward_resume:'Reanudar Futures automático',testnet_buy:'Comprar Testnet',testnet_close:'Cerrar Testnet',testnet_reconcile:'Conciliar Testnet',testnet_audit:'Comprobar Testnet en Binance'};
const activityStatuses={pending:'Pendiente',applied:'Confirmado por Windows',expired:'Vencido',superseded:'Sustituido',running:'En curso',completed:'Completado',failed:'Falló'};
function renderActivity(list,items){
  for(const item of items){
    const row=document.createElement('li');
    row.className=item.status==='failed'?'failed':'';
    row.textContent=`${activityActions[item.action]||item.action} · ${activityStatuses[item.status]||item.status}`;
    if(item.message){const detail=document.createElement('small');detail.textContent=item.message;row.append(detail);}
    if(item.created){const time=document.createElement('small');time.textContent=new Date(item.created*1000).toLocaleString('es-MX');row.append(time);}
    list.append(row);
  }
}
function setUpdateCenterState(kind,headline,message,candidate=null){
  const hero=document.getElementById('updateHero');
  const icon=document.getElementById('updateHeroIcon');
  const title=document.getElementById('updateHeadline');
  const check=document.getElementById('checkAllUpdates');
  const install=document.getElementById('installBotUpdate');
  hero.classList.remove('is-searching','has-update','has-warning');
  if(kind==='searching'){hero.classList.add('is-searching');icon.textContent='…';}
  else if(kind==='update'){hero.classList.add('has-update');icon.textContent='↓';}
  else if(kind==='warning'){hero.classList.add('has-warning');icon.textContent='!';}
  else {icon.textContent='✓';}
  title.textContent=headline;
  document.getElementById('botUpdateMessage').textContent=message;
  const canInstall=kind==='update'&&candidate?.enabled===true;
  install.hidden=!canInstall;
  install.disabled=!canInstall;
  install.textContent=canInstall?`Instalar v${candidate.version}`:'Instalar actualización';
  check.hidden=canInstall;
  check.textContent=kind==='current'?'Comprobar de nuevo':'Comprobar ahora';
}
async function portalState(force=false){
  if(force){
    portalCacheAt=0;
    if(portalPending){try{await portalPending;}catch{}}
  }
  if(!force && portalCache && Date.now()-portalCacheAt<5000)return portalCache;
  const epoch=portalEpoch;
  if(!portalPending)portalPending=portalRequest('/v1/status').then(state=>{
    if(epoch!==portalEpoch)throw new Error('Sesión finalizada');
    portalCsrf=state.csrf;portalCache=state;portalCacheAt=Date.now();
    document.getElementById('portalConnection').textContent=state.stale?'Windows sin conexión reciente':'Windows conectado · sincronización HTTPS';
    const commands=document.getElementById('portalCommands');commands.replaceChildren();
    const recent=(state.activity||[...(state.jobs||[]),...(state.paper_controls||[]),...(state.commands||[])]).slice(0,3);
    renderActivity(commands,recent);
    if(!recent.length){const row=document.createElement('li');row.textContent='Sin solicitudes recientes.';commands.append(row);}
    const candidate=state.snapshot?.bot_update;
    const activeJob=(state.jobs||[]).some(j=>['pending','running'].includes(j.status));
    const usable=candidate&&!state.stale&&candidate.expires>Date.now()/1000;
    const restore=state.snapshot?.bot_restore;
    document.getElementById('restoreBotVersion').disabled=!(restore?.enabled&&!state.stale&&!activeJob);
    const latestUpdateCheck=(state.jobs||[]).find(job=>job.action==='update_check');
    if(state.stale){
      setUpdateCenterState('warning','Windows sin conexión','Reconecta Windows para verificar o instalar una actualización.');
    }else if(usable&&candidate.enabled&&!activeJob){
      setUpdateCenterState('update',`Nueva versión disponible · v${candidate.version}`,
        'Paquete firmado y supervisor verificados. Puedes instalarlo de forma supervisada.',candidate);
    }else if(usable&&!candidate.enabled){
      setUpdateCenterState('warning','Actualización pendiente de reparación',
        `La versión ${candidate.version} está firmada, pero el supervisor de Windows debe sincronizarse antes de instalar.`);
    }else if(latestUpdateCheck?.status==='completed'){
      setUpdateCenterState('current','Estás actualizado',latestUpdateCheck.message||'La versión instalada coincide con la última release firmada.');
    }else if(latestUpdateCheck?.status==='failed'){
      setUpdateCenterState('warning','No se pudo comprobar','La última comprobación no terminó correctamente. Puedes volver a intentarlo.');
    }else{
      setUpdateCenterState('idle','Listo para comprobar','Windows verificará firma, versión y supervisor antes de ofrecer una instalación.');
    }
    document.getElementById('portalLogin').hidden=true;document.querySelector('.shell').hidden=false;
    return state;
  }).finally(()=>{portalPending=null;});
  return portalPending;
}
window.portalApi=async(path,options={})=>{
  if(!remotePortal){
    const response=await fetch(path,{...options,cache:'no-store'});
    if(!response.ok)throw new Error(`API local: ${response.status}`);
    return response.json();
  }
  if(options.method==='POST'){
    if(['/api/paper/risk-profile','/api/paper/close-position','/api/operations/model','/api/operations/restart','/api/operations/execution-mode','/api/operations/testnet-smoke','/api/operations/futures-check','/api/operations/futures-smoke','/api/operations/futures-reconcile','/api/operations/futures-forward-pause','/api/operations/futures-forward-resume'].includes(path)){
      const state=await portalState(true);
      if(state.stale||state.snapshot?.paper_controls!==true)throw new Error('Controles del motor pendientes de conexión de Windows');
      if((path.startsWith('/api/operations/'))&&state.snapshot?.operations_controls!==true)throw new Error('Actualiza y repara el agente de Windows antes de usar esta opción');
      let payload;
      try{payload=JSON.parse(options.body);}catch{throw new Error('Solicitud de control inválida');}
      const result=await portalRequest('/v1/paper-controls',{
        action:({
          '/api/paper/risk-profile':'risk_profile','/api/paper/close-position':'paper_close',
          '/api/operations/model':'ai_model','/api/operations/restart':'restart_engine','/api/operations/execution-mode':'execution_mode','/api/operations/testnet-smoke':'testnet_smoke','/api/operations/futures-check':'futures_testnet_check','/api/operations/futures-smoke':'futures_testnet_smoke','/api/operations/futures-reconcile':'futures_testnet_reconcile','/api/operations/futures-forward-pause':'futures_forward_pause','/api/operations/futures-forward-resume':'futures_forward_resume'
        })[path],payload,request_id:crypto.randomUUID()});
      portalCacheAt=0;return result;
    }
    if(path==='/api/research/run'){
      const state=await portalState(true);
      if(state.stale)throw new Error('Windows sin conexión reciente');
      const result=await portalRequest('/v1/jobs',{action:'research',request_id:crypto.randomUUID()});
      portalCacheAt=0;return result;
    }
    if(path==='/api/kill'||path==='/api/resume'){
      const state=await portalState();
      if(state.stale && path==='/api/resume')throw new Error('Windows sin conexión reciente');
      const result=await portalRequest('/v1/commands',{action:path==='/api/kill'?'kill':'resume',request_id:crypto.randomUUID()});
      portalCacheAt=0;return result;
    }
    throw new Error('Esta acción aún requiere el servicio supervisado de Windows');
  }
  const state=await portalState();
  if(path==='/api/research/status'){
    const job=(state.jobs||[]).find(item=>item.action==='research');
    const error=job?.status==='failed'?job.message:(job?.status==='expired'?'La solicitud venció antes de llegar a Windows':null);
    return {running:!!job&&['pending','running'].includes(job.status),error};
  }
  const data=state.snapshot?.dashboard;
  if(!data)throw new Error('Esperando la primera sincronización del panel completo');
  if(!portalRoute[path])throw new Error('Ruta no disponible');
  return structuredClone(data[portalRoute[path]]??{});
};
window.paperControlsAvailable=()=>!remotePortal || !!(portalCache&&!portalCache.stale&&portalCache.snapshot?.paper_controls===true);
document.addEventListener('DOMContentLoaded',()=>{
  if(!remotePortal)document.getElementById('installBotUpdate').disabled=false;
  if(!remotePortal)document.getElementById('restoreBotVersion').disabled=false;
  document.getElementById('portalLogin').hidden=!remotePortal;
  document.querySelector('.shell').hidden=remotePortal;
  document.getElementById('portalLogout').hidden=!remotePortal;
  if(!remotePortal)document.querySelector('.activity-strip').hidden=true;
  document.getElementById('portalConnection').textContent=remotePortal?'Conectando al portal':'Conexión local · datos directos de Windows';
  const optionsButton=document.getElementById('optionsButton'),optionsMenu=document.getElementById('optionsMenu');
  function showOptions(open){optionsMenu.hidden=!open;optionsButton.setAttribute('aria-expanded',String(open));}
  optionsButton.onclick=()=>showOptions(optionsMenu.hidden);
  document.getElementById('diagnosticsButton').onclick=()=>{
    showOptions(false);
    const panel=document.getElementById('diagnosticsPanel');
    panel.open=true;
    panel.scrollIntoView({behavior:'smooth',block:'start'});
  };
  document.getElementById('modelSettingsButton').onclick=()=>{
    showOptions(false);
    const panel=document.getElementById('modelSettingsPanel');panel.hidden=false;
    panel.scrollIntoView({behavior:'smooth',block:'start'});
  };
  document.getElementById('closeModelSettings').onclick=()=>document.getElementById('modelSettingsPanel').hidden=true;
  async function operationalAction(path,payload,question){
    if(!confirm(question))return;
    const startedAt=Date.now()/1000;
    const buttonId=path.endsWith('model')?'applyAiModel':
      path.endsWith('execution-mode')?'applyExecutionMode':
      path.endsWith('testnet-smoke')?'testTestnetExecution':
      path.endsWith('futures-check')?'checkFuturesTestnet':
      path.endsWith('futures-smoke')?'testFuturesExecution':
      path.endsWith('futures-reconcile')?'reconcileFutures':
      path.endsWith('futures-forward-pause')?'pauseFuturesForward':
      path.endsWith('futures-forward-resume')?'resumeFuturesForward':'restartMotor';
    const futures=path.includes('/futures-');
    const button=document.getElementById(buttonId);
    const message=document.getElementById(futures?'futuresMessage':'modelSettingsMessage');
    if(portalBusyButtons.has(buttonId))return;
    setPortalBusy(buttonId,true,'Procesando…');
    message.textContent='Enviando solicitud a Windows…';
    try{
      const result=await window.portalApi(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      message.textContent=result.status==='pending'?
        'Solicitud recibida · esperando confirmación de Windows…':
        'Windows confirmó la operación.';
      if(remotePortal && result.status==='pending'){
        const action=({
          '/api/operations/model':'ai_model','/api/operations/restart':'restart_engine',
          '/api/operations/execution-mode':'execution_mode','/api/operations/testnet-smoke':'testnet_smoke',
          '/api/operations/futures-check':'futures_testnet_check','/api/operations/futures-smoke':'futures_testnet_smoke',
          '/api/operations/futures-reconcile':'futures_testnet_reconcile',
          '/api/operations/futures-forward-pause':'futures_forward_pause',
          '/api/operations/futures-forward-resume':'futures_forward_resume'
        })[path];
        const deadline=Date.now()+90000;
        while(Date.now()<deadline){
          await new Promise(resolve=>setTimeout(resolve,1500));
          portalCacheAt=0;
          const state=await portalState(true);
          const row=(state.paper_controls||[]).find(item=>item.action===action && (item.created||0)>=startedAt-2)
            || (state.activity||[]).find(item=>item.action===action && (item.created||0)>=startedAt-2);
          if(row?.status==='completed'){message.textContent=row.message||'Windows confirmó la operación.';break;}
          if(row?.status==='failed'){message.textContent=row.message||'Windows no completó la acción.';break;}
          if(row?.status==='expired'){message.textContent='La solicitud venció antes de completarse.';break;}
        }
      }else if(!remotePortal)setTimeout(async()=>{
        try{const state=await window.portalApi('/api/operations/last');
          if(state.at&&state.at>startedAt)message.textContent=state.status==='completed'?'Windows confirmó la operación.':
            `Windows no completó la acción (${state.reason||'revisar estado'}).`;}
        catch{}
      },4500);
    }catch(error){message.textContent=error.message;}
    finally{
      setPortalBusy(buttonId,false);
      portalCacheAt=0;
    }
  }
  document.getElementById('applyAiModel').onclick=()=>operationalAction('/api/operations/model',
    {model:document.getElementById('aiModelChoice').value},'¿Verificar el modelo seleccionado y reiniciar el motor activo?');
  document.getElementById('restartMotor').onclick=()=>operationalAction('/api/operations/restart',{},
    '¿Reiniciar el motor? Puede interrumpir la vigilancia durante unos segundos.');
  document.getElementById('applyExecutionMode').onclick=()=>{
    const mode=document.getElementById('executionModeChoice').value;
    const label=mode==='testnet'?'Binance Spot Testnet':'PAPER';
    operationalAction('/api/operations/execution-mode',{mode},
      `¿Cambiar el único motor a ${label}? Windows reiniciará el motor de forma supervisada. LIVE seguirá bloqueado.`);
  };
  document.getElementById('testTestnetExecution').onclick=()=>operationalAction(
    '/api/operations/testnet-smoke',{},
    '¿Ejecutar una prueba real en Binance Spot Testnet? Usará fondos ficticios, abrirá una posición pequeña de BTCUSDT, la conciliará, la cerrará y reiniciará el motor. LIVE seguirá bloqueado.'
  );
  document.getElementById('checkFuturesTestnet').onclick=()=>operationalAction(
    '/api/operations/futures-check',{},
    '¿Verificar la cuenta separada de Binance USDⓈ-M Futures Demo? Esta comprobación es de solo lectura.'
  );
  document.getElementById('testFuturesExecution').onclick=()=>{
    const direction=document.getElementById('futuresDirection').value;
    const leverage=Number(document.getElementById('futuresLeverage').value);
    operationalAction('/api/operations/futures-smoke',{direction,leverage},
      `¿Probar ${direction} en Futures Demo con ${leverage}x, margen ISOLATED y fondos ficticios? La posición se cerrará con reduceOnly y LIVE seguirá bloqueado.`);
  };
  document.getElementById('reconcileFutures').onclick=()=>operationalAction(
    '/api/operations/futures-reconcile',{},
    '¿Reconciliar una prueba Futures pendiente y cerrar únicamente su posición técnica con reduceOnly si todavía existe?'
  );
  document.getElementById('pauseFuturesForward').onclick=()=>operationalAction(
    '/api/operations/futures-forward-pause',{},
    '¿Pausar nuevas decisiones del motor automático Futures Demo? Spot Testnet seguirá funcionando y una posición Futures abierta conservará su protección.'
  );
  document.getElementById('resumeFuturesForward').onclick=()=>operationalAction(
    '/api/operations/futures-forward-resume',{},
    '¿Reanudar el forward test automático de BTCUSDT Futures Demo a 1x?'
  );
  let nextHistoryPage=0,historyBusy=false;
  async function loadHistory(reset=false){
    if(historyBusy)return;
    if(reset){nextHistoryPage=0;document.getElementById('historyRows').replaceChildren();}
    if(nextHistoryPage===null)return;
    historyBusy=true;
    const more=document.getElementById('loadMoreHistory'),message=document.getElementById('historyMessage');
    more.disabled=true;message.textContent='Cargando historial…';
    try{
      const page=nextHistoryPage,epoch=portalEpoch;
      const data=await portalRequest(`/v1/activity/${page}`);
      if(epoch!==portalEpoch)return;
      renderActivity(document.getElementById('historyRows'),data.items);
      nextHistoryPage=data.next_page;
      more.hidden=nextHistoryPage===null;
      message.textContent=page===0&&!data.items.length?'Aún no hay actividad.':`Historial disponible durante ${data.retention_days} días.`;
    }catch(error){message.textContent=error.message;}
    finally{historyBusy=false;more.disabled=false;}
  }
  document.getElementById('historyButton').onclick=async()=>{
    showOptions(false);document.getElementById('passwordPanel').hidden=true;document.getElementById('updatePanel').hidden=true;
    if(!remotePortal){window.open('https://crypto-paper-private-portal.jlboper.workers.dev/','_blank','noopener');return;}
    document.getElementById('historyPanel').hidden=false;
    document.getElementById('historyPanel').scrollIntoView({behavior:'smooth',block:'start'});
    await loadHistory(true);
  };
  document.getElementById('loadMoreHistory').onclick=()=>loadHistory();
  document.getElementById('closeHistory').onclick=()=>{document.getElementById('historyPanel').hidden=true;};
  document.getElementById('portalLogin').onsubmit=async e=>{
    e.preventDefault();const button=document.getElementById('portalLoginButton');button.disabled=true;
    try{const parameters=await portalRequest('/v1/auth-parameters');const proof=await portalPasswordProof(document.getElementById('portalPassword').value,parameters);const result=await portalRequest('/v1/login',{password:proof});portalCsrf=result.csrf;document.getElementById('portalPassword').value='';portalCacheAt=0;await portalState();window.dispatchEvent(new Event('portal-ready'));}
    catch(error){document.getElementById('portalLoginMessage').textContent=error.message;}
    finally{button.disabled=false;}
  };
  document.getElementById('portalLogout').onclick=async()=>{showOptions(false);await portalRequest('/v1/logout',{});portalLocked();};
  document.getElementById('portalPasswordButton').onclick=()=>{
    showOptions(false);document.getElementById('updatePanel').hidden=true;
    if(!remotePortal){window.open('https://crypto-paper-private-portal.jlboper.workers.dev/#password','_blank','noopener');return;}
    document.getElementById('passwordPanel').hidden=false;
    document.getElementById('passwordMessage').textContent='';
  };
  document.getElementById('cancelPassword').onclick=()=>{
    document.getElementById('passwordPanel').hidden=true;
    for(const id of ['currentPassword','newPassword','confirmPassword'])document.getElementById(id).value='';
  };
  document.getElementById('passwordForm').onsubmit=async event=>{
    event.preventDefault();const button=document.getElementById('savePassword'),message=document.getElementById('passwordMessage');
    const current=document.getElementById('currentPassword'),next=document.getElementById('newPassword'),confirmation=document.getElementById('confirmPassword');
    if(next.value!==confirmation.value){message.textContent='Las contraseñas nuevas no coinciden';return;}
    if(next.value.length<16||next.value.length>128||next.value.trim()!==next.value){message.textContent='Usa de 16 a 128 caracteres, sin espacios al principio o al final';return;}
    if(next.value===current.value){message.textContent='Elige una contraseña diferente';return;}
    button.disabled=true;message.textContent='Guardando…';
    try{
      await portalState();const parameters=await portalRequest('/v1/auth-parameters');
      const salt=btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32)))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
      const currentProof=await portalPasswordProof(current.value,parameters);
      const newProof=await portalPasswordProof(next.value,{scheme:'pbkdf2-sha256',salt,iterations:600000});
      await portalRequest('/v1/password',{current_password:currentProof,new_password:newProof,salt});
      portalLocked();document.getElementById('portalLoginMessage').textContent='Contraseña cambiada. Entra con tu nueva contraseña.';
    }catch(error){message.textContent=error.message;}
    finally{current.value='';next.value='';confirmation.value='';button.disabled=false;}
  };
  window.addEventListener('portal-ready',()=>{if(location.hash==='#password')document.getElementById('passwordPanel').hidden=false;if(location.hash==='#updates')checkAllUpdates(false);});
  let updatePending=false,lastUpdatesAt=0;
  async function checkAllUpdates(force=true){
    if(!remotePortal){
      const output=document.getElementById('updateMessage');
      if(updatePending){output.textContent='La comprobación ya está en curso; no necesitas pulsar de nuevo.';return;}
      updatePending=true;
      const button=document.getElementById('checkAllUpdates');button.disabled=true;
      setUpdateCenterState('searching','Buscando actualización','Windows está descargando y verificando la última release firmada…');
      try{
        const candidate=await window.portalApi('/api/local-update/check',{
          method:'POST',headers:{'Content-Type':'application/json'},body:'{}'
        });
        candidate.enabled=true;
        window.localUpdateCandidate=candidate;
        setUpdateCenterState('update',`Versión firmada disponible · v${candidate.version}`,
          'Verificada localmente. Puedes instalarla desde 127.0.0.1 sin abrir el portal remoto.',candidate);
        output.textContent=`Revisión ${candidate.commit||'verificada'} · paquete firmado listo.`;
      }catch(error){
        setUpdateCenterState('warning','No se pudo comprobar',error.message);
        output.textContent=error.message;
      }finally{updatePending=false;button.disabled=false;}
      return;
    }
    const output=document.getElementById('updateMessage');
    if(updatePending){
      output.textContent='La comprobación ya está en curso; no necesitas pulsar de nuevo.';
      return;
    }
    if(!force && Date.now()-lastUpdatesAt<30000)return;
    updatePending=true;const button=document.getElementById('checkAllUpdates');button.disabled=true;
    const releases=document.getElementById('updateReleases'),botOutput=document.getElementById('botUpdateMessage');
    releases.replaceChildren();output.textContent='';
    setUpdateCenterState('searching','Buscando actualizaciones','Verificando publicación, firma y supervisor de Windows…');
    const epoch=portalEpoch;
    try{
      const state=await portalState(true);
      const [portalResult,botResult]=await Promise.allSettled([
        portalRequest('/v1/updates'),
        state.stale?Promise.reject(new Error('Windows debe estar conectado')):
          portalRequest('/v1/jobs',{action:'update_check',request_id:crypto.randomUUID()}),
      ]);
      if(epoch!==portalEpoch)return;
      if(portalResult.status==='fulfilled'){
        const data=portalResult.value;output.textContent=data.message;
        for(const run of data.runs){
        const card=document.createElement('article'),title=document.createElement('h3'),detail=document.createElement('p'),link=document.createElement('a');
        title.textContent=run.title;
        detail.textContent=`Portal y paquete del bot · commit ${run.sha} · autor ${run.actor} · intento ${run.attempt} · ${run.conclusion||run.status}`;
        link.href=run.url;link.textContent='Ver cambios y pruebas en GitHub';link.target='_blank';link.rel='noopener';
        const commit=document.createElement('a');commit.href=run.commit_url;commit.textContent='Ver commit exacto';commit.target='_blank';commit.rel='noopener';
        card.append(title,detail,commit,link);
        if(run.blocked){const message=document.createElement('p');message.textContent=run.blocked;card.append(message);}
        if(run.published){const published=document.createElement('p');published.textContent='Esta revisión ya está publicada.';card.append(published);}
        if(run.review_on_github){
          const approve=document.createElement('a');approve.className='primary';approve.textContent='Revisar y autorizar publicación en GitHub';
          approve.href=run.url;approve.target='_blank';approve.rel='noopener';card.append(approve);
        }
          releases.append(card);
        }
      }else output.textContent=botResult.status==='fulfilled'?
        'No se pudieron consultar temporalmente los detalles de publicación en GitHub; Windows continúa verificando el bot.':
        portalResult.reason.message;
      if(botResult.status==='fulfilled'){
        portalCacheAt=0;setUpdateCenterState('searching','Verificando en Windows','La firma y el supervisor se están comprobando. El estado se actualizará automáticamente.');
      }else setUpdateCenterState('warning','No se pudo comprobar',botResult.reason.message);
      if(portalResult.status==='fulfilled'||botResult.status==='fulfilled')lastUpdatesAt=Date.now();
    }catch(error){output.textContent=error.message;}
    finally{updatePending=false;button.disabled=false;}
  }
  function showUpdateCenter(){
    showOptions(false);document.getElementById('passwordPanel').hidden=true;document.getElementById('historyPanel').hidden=true;
    const panel=document.getElementById('updatePanel');panel.hidden=false;
    if(remotePortal&&document.querySelector('.shell').hidden){
      document.getElementById('updateMessage').textContent='Inicia sesión para revisar las versiones disponibles.';
    }else{
      panel.scrollIntoView({behavior:'smooth',block:'start'});
      checkAllUpdates(false);
    }
  }
  async function installBotUpdate(){
    const output=document.getElementById('botUpdateMessage');
    const button=document.getElementById('installBotUpdate');
    if(!remotePortal){
      const candidate=window.localUpdateCandidate;
      if(!candidate?.release_id){output.textContent='Primero comprueba la actualización firmada.';return;}
      if(!confirm(`¿Instalar v${candidate.version} desde esta PC? El supervisor independiente reiniciará y validará el motor automáticamente.`))return;
      setPortalBusy('installBotUpdate',true,'Procesando…');
      try{
        const result=await window.portalApi('/api/local-update/install',{
          method:'POST',headers:{'Content-Type':'application/json'},
          body:JSON.stringify({release_id:candidate.release_id})
        });
        output.textContent=result.message||'Instalación local iniciada. El portal puede desconectarse unos segundos mientras Windows reinicia el motor.';
        setUpdateCenterState('searching','Instalando actualización','Windows está aplicando el paquete firmado y comprobará el arranque automáticamente.');
        document.getElementById('updateDetails').open=false;
      }catch(error){output.textContent=error.message;setPortalBusy('installBotUpdate',false);}
      return;
    }
    if(portalBusyButtons.has('installBotUpdate'))return;
    let submitted=false;setPortalBusy('installBotUpdate',true,'Procesando…');
    try{
      const state=await portalState(true);if(state.stale)throw new Error('Windows debe estar conectado');
      const candidate=state.snapshot?.bot_update;
      if(!candidate?.enabled||candidate.expires<=Date.now()/1000)throw new Error('Primero verifica una versión disponible');
      if(!confirm(`¿Instalar el bot ${candidate.version}, revisión ${candidate.commit}? El motor activo se reiniciará y se recuperará la versión anterior si falla el arranque.`))return;
      const body={action:'update_install',request_id:crypto.randomUUID(),release_id:candidate.release_id};
      await portalRequest('/v1/jobs',body);submitted=true;portalCacheAt=0;
      output.textContent='Instalación solicitada · esperando confirmación de Windows…';
      setUpdateCenterState('searching','Instalación solicitada','Windows recibió la solicitud. No necesitas volver a pulsar el botón.');
      document.getElementById('updateDetails').open=false;
    }catch(error){output.textContent=error.message;}
    finally{
      if(!submitted)setPortalBusy('installBotUpdate',false);
    }
  }
  async function restoreBotVersion(){
    showOptions(false);
    if(!remotePortal){window.open('https://crypto-paper-private-portal.jlboper.workers.dev/','_blank','noopener');return;}
    const button=document.getElementById('restoreBotVersion');
    button.disabled=true;
    let submitted=false;
    try{
      const state=await portalState();
      const offer=state.snapshot?.bot_restore;
      if(state.stale||!offer?.enabled||(state.jobs||[]).some(j=>['pending','running'].includes(j.status)))throw new Error('Windows aún no ofrece una versión anterior verificable');
      if(!confirm(`¿Restaurar el código del bot de ${offer.current_version} a ${offer.version}? El motor activo se reiniciará. Se conservarán los saldos y las operaciones actuales.`))return;
      await portalRequest('/v1/jobs',{action:'update_restore',request_id:crypto.randomUUID(),release_id:offer.restore_id});
      submitted=true;
      portalCacheAt=0;
      document.getElementById('botUpdateMessage').textContent='Restauración solicitada. Windows comprobará el arranque y conservará los datos financieros.';
    }catch(error){document.getElementById('botUpdateMessage').textContent=error.message;}
    finally{portalCacheAt=0;if(!submitted)button.disabled=false;}
  }
  document.getElementById('checkAllUpdates').onclick=()=>checkAllUpdates(true);
  document.getElementById('installBotUpdate').onclick=installBotUpdate;
  document.getElementById('restoreBotVersion').onclick=restoreBotVersion;
  document.getElementById('updateButton').onclick=showUpdateCenter;
  document.getElementById('closeUpdatePanel').onclick=()=>{document.getElementById('updatePanel').hidden=true;};
  if(location.hash==='#updates')showUpdateCenter();
  window.addEventListener('hashchange',()=>{if(location.hash==='#updates')showUpdateCenter();});
  window.addEventListener('portal-ready',()=>{if(location.hash==='#updates'){lastUpdatesAt=0;showUpdateCenter();}});
});
