"""Supervised trading-engine activation. Run from the stable agent, outside the target.

Never kills a discovered PID: only a child created by this supervisor may be
terminated. An existing engine must implement the cooperative maintenance gate.
"""
from __future__ import annotations

import json
import os
import secrets
import subprocess
import sys
import time
import tomllib
import urllib.request

from .runtime import single_instance
from .runtime_control import RuntimeControl
from .update_manager import atomic_json, release_id, verify
from .native_protection_compat import require_native_compatible


def _unlink_with_retry(path, attempts=20, delay=0.05):
    for attempt in range(attempts):
        try:
            path.unlink()
            return
        except FileNotFoundError:
            return
        except PermissionError:
            if attempt + 1 >= attempts:
                raise
            time.sleep(delay)


class ProcessRuntime:
    def __init__(self, root, python=None):
        self.root = root
        self.python = python or sys.executable

    def start(self, token=None):
        environment = dict(os.environ)
        environment.pop("CRYPTO_UPDATE_TOKEN", None)
        if token is not None:
            environment["CRYPTO_UPDATE_TOKEN"] = token
        return subprocess.Popen(
            [self.python, "-m", "trader", "--config", str(self.root/'config.toml'), "run"],
            cwd=self.root, env=environment, stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))

    @staticmethod
    def stop_owned(child):
        if child is not None and child.poll() is None:
            child.terminate()
            child.wait(timeout=20)

    def health(self, child, token):
        from .remote_agent import NoRedirect
        config = tomllib.loads((self.root/'config.toml').read_text())
        dashboard = config.get('dashboard', {})
        host, port = dashboard.get('host'), dashboard.get('port')
        if host not in {'127.0.0.1', 'localhost', '::1'} or type(port) is not int or not 1 <= port <= 65535:
            return False
        address = '[::1]' if host == '::1' else '127.0.0.1'
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        try:
            with opener.open(f'http://{address}:{port}/health/runtime', timeout=2) as response:
                payload = json.loads(response.read(4097))
            return (
                isinstance(payload, dict)
                and payload.get('pid') == child.pid
                and payload.get('token') == token
                and payload.get('mode') in {'paper', 'testnet'}
                and child.poll() is None
            )
        except (OSError, ValueError):
            return False


class UpdateSupervisor:
    def __init__(self, manager, runtime=None, timeout=120):
        self.manager = manager
        self.runtime = runtime or ProcessRuntime(manager.root)
        self.control = RuntimeControl(manager.database_path().parent)
        self.record = manager.state/'supervisor.json'
        self.lock = manager.root/'data/update-supervisor.lock'
        self.timeout = timeout

    def wait_stopped(self):
        deadline = time.monotonic()+self.timeout
        while True:
            try:
                with self.manager.locks():
                    return
            except RuntimeError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Engine or another writer did not stop cooperatively")
                time.sleep(0.1)

    def ready(self, child, token, version, phase):
        if child.poll() is not None:
            return False
        try:
            status = json.loads(self.control.status.read_text())
        except (OSError, ValueError):
            return False
        return (status.get('pid') == child.pid and status.get('token') == token
                and status.get('version') == version and status.get('phase') == phase
                and status.get('mode') in {'paper', 'testnet'} and status.get('protocol') == 1
                and status.get('dashboard_ready') is True and self.runtime.health(child, token))

    def wait_ready(self, child, token, version, phase):
        deadline = time.monotonic()+self.timeout
        while not self.ready(child, token, version, phase):
            if child.poll() is not None:
                raise RuntimeError("Owned engine exited before readiness")
            if time.monotonic() >= deadline:
                raise TimeoutError("Engine readiness deadline exceeded")
            time.sleep(0.1)

    def phase(self, token, phase):
        atomic_json(self.control.maintenance, {'token': token, 'phase': phase})

    def restart_previous(self, version):
        self.control.maintenance.unlink(missing_ok=True)
        child = None
        try:
            child = self.runtime.start()
            self.wait_ready(child, None, version, 'running')
        except BaseException:
            self.phase(secrets.token_hex(32), 'recovery_failed')
            self.runtime.stop_owned(child)
            raise

    def install(self, package, envelope, approved, *, job_id=None):
        if job_id is not None and (type(job_id) is not int or job_id <= 0):
            raise ValueError("Invalid update job identifier")
        with single_instance(self.lock):
            if self.control.maintenance.exists():
                raise RuntimeError("Recover previous maintenance before installing")
            minimum = json.loads(self.manager.sequence.read_text())['sequence'] if self.manager.sequence.exists() else 0
            manifest = verify(package, envelope, self.manager.public_key, minimum)
            if release_id(manifest) != approved:
                raise ValueError("Approved release changed")
            if manifest.get('runtime_protocol') != 1 or 'trader/runtime_control.py' not in manifest['files']:
                raise ValueError("Candidate lacks supervised runtime protocol")
            installed = tomllib.loads((self.manager.root/'pyproject.toml').read_text())['project']['version']
            if tuple(map(int, manifest['version'].split('.'))) <= tuple(map(int, installed.split('.'))):
                raise ValueError('Version upgrade required before stopping engine')
            if not (self.manager.root/'trader/runtime_control.py').is_file():
                raise RuntimeError("Existing installation requires one-time supervised bootstrap")
            original = json.loads(self.control.status.read_text())
            if original.get('protocol') != 1 or original.get('phase') != 'running' or original.get('mode') not in {'paper', 'testnet'}:
                raise RuntimeError("Existing engine has no cooperative runtime status")
            # Do not turn a stopped installation into an active trading process.
            try:
                with single_instance(self.control.directory/'engine.lock'):
                    pass
            except RuntimeError:
                pass
            else:
                raise RuntimeError("Existing engine is stopped; supervised installation requires a running engine")
            token = secrets.token_hex(32)
            state = {'token': token, 'release_id': approved, 'old_version': original['version'],
                     'version': manifest['version'], 'phase': 'stopping', 'job_id': job_id}
            atomic_json(self.record, state)
            self.phase(token, 'stopping')
            child = None
            applied = False
            try:
                self.wait_stopped()
                self.manager.apply(package, envelope, expected_release=approved, defer_commit=True)
                applied = True
                require_native_compatible(self.manager.root, self.manager.root)
                self.phase(token, 'candidate')
                child = self.runtime.start(token)
                self.wait_ready(child, token, manifest['version'], 'candidate')
                self.manager.commit_pending(approved, lambda: self.ready(child, token, manifest['version'], 'candidate'))
                # The durable commit precedes permission to execute financial cycles.
                atomic_json(self.control.activation, {'token': token, 'release_id': approved})
                _unlink_with_retry(self.control.maintenance)
                self.wait_ready(child, token, manifest['version'], 'running')
                atomic_json(self.record, {**state, 'phase': 'completed'})
                return {'status': 'installed_healthy', 'version': manifest['version'], 'release_id': approved}
            except BaseException:
                journal = json.loads(self.manager.journal.read_text()) if self.manager.journal.exists() else {}
                if journal.get('phase') == 'committed' and journal.get('release_id') == approved:
                    # Financial cycles may already have executed. Never restore an old balance.
                    atomic_json(self.record, {**state, 'phase': 'committed_restart_required'})
                    raise
                self.phase(token, 'cancelled')
                self.runtime.stop_owned(child)
                self.wait_stopped()
                if applied or journal.get('phase') in {'applying', 'pending_health'}:
                    self.manager.recover()
                self.restart_previous(original['version'])
                atomic_json(self.record, {**state, 'phase': 'rolled_back'})
                raise

    def available_restore(self):
        if self.control.maintenance.exists():
            return None
        offer = self.manager.restore_offer()
        if offer is None:
            return None
        if not (self.manager.state/'backup/trader/runtime_control.py').is_file():
            return None
        try:
            require_native_compatible(self.manager.root, self.manager.state/'backup')
        except (OSError, ValueError, RuntimeError):
            return None
        try:
            status = json.loads(self.control.status.read_text())
        except (OSError, ValueError):
            return None
        if (status.get('protocol') != 1 or status.get('phase') != 'running'
                or status.get('mode') not in {'paper', 'testnet'} or status.get('version') != offer['current_version']):
            return None
        try:
            with single_instance(self.control.directory/'engine.lock'):
                return None
        except RuntimeError:
            pass
        return {**offer, 'enabled': True}

    def restore(self, approved, *, job_id=None):
        """Restore a verified previous code snapshot; retain active ledger data and sequence."""
        if job_id is not None and (type(job_id) is not int or job_id <= 0):
            raise ValueError('Invalid restoration job identifier')
        with single_instance(self.lock):
            offer = self.available_restore()
            if offer is None or offer['restore_id'] != approved:
                raise ValueError('Approved restore target changed')
            original = json.loads(self.control.status.read_text())
            if (original.get('protocol') != 1 or original.get('phase') != 'running'
                    or original.get('mode') not in {'paper', 'testnet'} or original.get('version') != offer['current_version']):
                raise RuntimeError('Existing engine has no matching cooperative runtime status')
            try:
                with single_instance(self.control.directory/'engine.lock'):
                    pass
            except RuntimeError:
                pass
            else:
                raise RuntimeError('Restoration requires a running trading engine')
            token = secrets.token_hex(32)
            state = {'action':'restore', 'token':token, 'release_id':offer['current_release_id'],
                     'restore_id':approved, 'old_version':offer['current_version'],
                     'version':offer['version'], 'phase':'restore_stopping', 'job_id':job_id}
            atomic_json(self.record,state)
            self.phase(token,'stopping')
            child = None
            try:
                self.wait_stopped()
                require_native_compatible(self.manager.root, self.manager.state/'backup')
                self.manager.snapshot_current()
                atomic_json(self.record,{**state,'phase':'restore_applying'})
                self.manager.swap_previous(approved)
                self.phase(token,'candidate')
                child = self.runtime.start(token)
                self.wait_ready(child,token,offer['version'],'candidate')
                # Once financial cycles can resume, the previous code is committed.
                atomic_json(self.record,{**state,'phase':'restore_committed'})
                self.manager.finish_restore(approved)
                atomic_json(self.control.activation,{'token':token,'release_id':approved})
                self.control.maintenance.unlink()
                self.wait_ready(child,token,offer['version'],'running')
                atomic_json(self.record,{**state,'phase':'completed'})
                return {'status':'restored_healthy','version':offer['version'],'restore_id':approved}
            except BaseException:
                saved = json.loads(self.record.read_text())
                if saved['phase'] == 'restore_committed':
                    atomic_json(self.record,{**state,'phase':'committed_restart_required'})
                    raise
                self.phase(token,'cancelled')
                self.runtime.stop_owned(child)
                self.wait_stopped()
                if saved['phase'] == 'restore_applying':
                    self.manager.rollback_restore()
                self.restart_previous(offer['current_version'])
                atomic_json(self.record,{**state,'phase':'rolled_back'})
                raise

    def recover(self):
        """After supervisor/PC failure: cooperative stop, then journal recovery.

        A committed release keeps its data. A pending candidate restores code
        and database together. No process is killed by a PID read from disk.
        """
        with single_instance(self.lock):
            state = json.loads(self.record.read_text())
            if state['phase'] in {'completed', 'rolled_back'}:
                return {'status': state['phase']}
            self.phase(state['token'], 'cancelled')
            self.wait_stopped()
            if state.get('action') == 'restore':
                committed = state['phase'] in {'restore_committed','committed_restart_required'}
                if committed:
                    self.manager.finish_restore(state['restore_id'])
                elif state['phase'] == 'restore_applying':
                    self.manager.rollback_restore()
                version = state['version'] if committed else state['old_version']
                self.restart_previous(version)
                result = 'completed' if committed else 'rolled_back'
                atomic_json(self.record,{**state,'phase':result})
                return {'status':result,'version':version}
            journal = json.loads(self.manager.journal.read_text()) if self.manager.journal.exists() else {}
            committed = journal.get('phase') == 'committed' and journal.get('release_id') == state['release_id']
            self.manager.recover()
            version = state['version'] if committed else state['old_version']
            self.restart_previous(version)
            status = 'completed' if committed else 'rolled_back'
            atomic_json(self.record, {**state, 'phase': status})
            return {'status': status, 'version': version}
