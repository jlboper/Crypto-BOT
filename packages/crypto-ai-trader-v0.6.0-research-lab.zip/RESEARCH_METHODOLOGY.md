# Metodología del Research Lab 0.6

## Objetivo

Comparar ideas de estrategia de forma reproducible y conservadora. El laboratorio busca evidencia para descartar ideas débiles; no demuestra que una estrategia vaya a ganar dinero.

## Separación operacional

- El laboratorio solo lee datos públicos de mercado y escribe `data/research/latest.json`.
- No puede enviar órdenes, cambiar `config.toml`, mover capital ni sustituir la estrategia del motor.
- Todo resultado se etiqueta `RESEARCH_ONLY`.

## Supuestos de ejecución

- Las señales calculadas con una vela cerrada se ejecutan en la apertura siguiente.
- Se cobran comisión y slippage configurados en entrada y salida.
- Stops y objetivos usan OHLC intravela. Si ambos pudieron ocurrir en la misma vela y no hay datos de menor frecuencia, se registra primero el stop.
- El tamaño de posición respeta riesgo por operación, máximo por posición y efectivo disponible.

## Validación

Para cada activo se usan ventanas rodantes de entrenamiento y prueba. La estrategia ganadora en entrenamiento se evalúa en el bloque siguiente, no visto. El informe muestra retorno compuesto fuera de muestra, buy-and-hold equivalente, porcentaje de bloques positivos y la frecuencia con que la selección terminó en la mitad inferior fuera de muestra.

Monte Carlo remuestrea los retornos de operaciones fuera de muestra 1,000 veces para estimar rango de resultados, drawdown adverso y probabilidad de terminar en pérdida. Es una prueba de incertidumbre, no una predicción.

## Limitaciones conocidas

- OHLC de cuatro horas no revela el orden exacto de eventos dentro de cada vela.
- El modelo actual es long-only y no modela profundidad del libro, latencia variable, impuestos ni fallas de exchange.
- Cinco candidatos reducen la búsqueda indiscriminada, pero no eliminan sesgos de selección.
- El historial de un régimen no representa necesariamente el siguiente.
- La heurística de sobreajuste no equivale a una implementación formal de Probability of Backtest Overfitting.

## Puertas antes de cambiar el motor

1. Calidad de datos aprobada.
2. Múltiples folds fuera de muestra y ventaja estable frente al benchmark.
3. Drawdown compatible con los límites definidos.
4. Resultado Monte Carlo tolerable bajo escenarios adversos.
5. Revisión humana de operaciones y sensibilidad a costos.
6. Forward test separado durante varias semanas.
7. Cambio versionado, nuevas pruebas y autorización explícita.
