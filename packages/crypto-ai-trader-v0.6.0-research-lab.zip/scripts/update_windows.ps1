﻿[CmdletBinding()]
param(
    [string]$PackagePath,
    [string]$TargetProjectRoot,
    [switch]$SkipConfirmation
)

$ErrorActionPreference = "Stop"
$ProjectRoot = if ($TargetProjectRoot) {
    (Resolve-Path $TargetProjectRoot).Path
} else {
    (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
}
$BackupPath = $null
$TempRoot = $null
$BotWasStopped = $false
$ChangesStarted = $false

function Select-UpdatePackage {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = "Selecciona la actualización de Crypto AI Trader"
    $dialog.Filter = "Actualizaciones Crypto AI Trader (*.zip)|*.zip"
    $dialog.CheckFileExists = $true
    $dialog.Multiselect = $false
    $downloads = Join-Path $env:USERPROFILE "Downloads"
    if (Test-Path $downloads) {
        $dialog.InitialDirectory = $downloads
    }
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        throw "Actualización cancelada: no se seleccionó ningún paquete."
    }
    return $dialog.FileName
}

function Stop-TradingBot {
    $processes = @(
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -like "*-m trader run*" }
    )
    foreach ($process in $processes) {
        Stop-Process -Id $process.ProcessId -Force -ErrorAction SilentlyContinue
    }
    if ($processes.Count -gt 0) {
        Start-Sleep -Seconds 2
    }
    return $processes.Count
}

function Start-TradingBot {
    $launcher = (Get-Command py -ErrorAction Stop).Source
    Start-Process `
        -FilePath $launcher `
        -ArgumentList @("-3", "-m", "trader", "run") `
        -WorkingDirectory $ProjectRoot `
        -WindowStyle Hidden
}

function Copy-DirectoryContents {
    param([string]$Source, [string]$Destination)
    if (-not (Test-Path $Source)) {
        return
    }
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Destination -Recurse -Force
    }
}

function Test-DashboardPort {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $task = $client.ConnectAsync("127.0.0.1", 8765)
        return $task.Wait(2000) -and $client.Connected
    }
    catch {
        return $false
    }
    finally {
        $client.Dispose()
    }
}

function Restore-CodeBackup {
    param([string]$Path)
    foreach ($directory in @("trader", "web", "tests", "scripts")) {
        $source = Join-Path $Path $directory
        if (Test-Path $source) {
            Copy-DirectoryContents $source (Join-Path $ProjectRoot $directory)
        }
    }
    foreach ($file in @("README.md", "RESEARCH_METHODOLOGY.md", "pyproject.toml", "UPDATE_NOTES.md", "ACTUALIZAR_BOT.cmd", "INSTALAR_CENTRO_CONTROL.cmd", "Crypto AI Trader.vbs", ".env.example", ".gitignore")) {
        $source = Join-Path $Path $file
        if (Test-Path $source) {
            Copy-Item -LiteralPath $source -Destination (Join-Path $ProjectRoot $file) -Force
        }
    }
}

try {
    Write-Host "" 
    Write-Host "Crypto AI Trader - Actualizador seguro" -ForegroundColor Cyan
    Write-Host "Proyecto: $ProjectRoot"

    if (-not $PackagePath) {
        $PackagePath = Select-UpdatePackage
    }
    $PackagePath = (Resolve-Path $PackagePath).Path
    if ([IO.Path]::GetExtension($PackagePath) -ne ".zip") {
        throw "El paquete seleccionado no es un archivo ZIP."
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($PackagePath)
    try {
        $entries = @($archive.Entries | ForEach-Object { $_.FullName.Replace("\", "/") })
    }
    finally {
        $archive.Dispose()
    }

    foreach ($entry in $entries) {
        if ($entry.StartsWith("/") -or $entry -match "(^|/)\.\.(/|$)" -or $entry -match "^[A-Za-z]:") {
            throw "El ZIP contiene una ruta no permitida: $entry"
        }
        if ($entry -match "(^|/)\.env\.local$" -or $entry -match "(^|/)\.env$" -or $entry -match "(^|/)data/") {
            throw "El ZIP intenta incluir datos o credenciales locales y fue bloqueado."
        }
    }

    $required = @(
        "trader/__main__.py",
        "web/index.html",
        "pyproject.toml",
        "scripts/update_windows.ps1",
        "scripts/manager_windows.ps1",
        "Crypto AI Trader.vbs"
    )
    foreach ($item in $required) {
        if ($entries -notcontains $item) {
            throw "Paquete inválido: falta $item"
        }
    }

    Write-Host "Paquete: $PackagePath" -ForegroundColor Yellow
    if (-not $SkipConfirmation) {
        $answer = Read-Host "Escribe SI para instalar esta actualización"
        if ($answer.Trim().ToUpperInvariant() -ne "SI") {
            throw "Actualización cancelada por el usuario."
        }
    }

    $TempRoot = Join-Path ([IO.Path]::GetTempPath()) ("crypto-ai-update-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Path $TempRoot -Force | Out-Null
    Expand-Archive -LiteralPath $PackagePath -DestinationPath $TempRoot -Force

    Write-Host "Deteniendo el motor..."
    $BotWasStopped = (Stop-TradingBot) -gt 0

    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $BackupPath = Join-Path $ProjectRoot ("backup\before-update-" + $stamp)
    New-Item -ItemType Directory -Path $BackupPath -Force | Out-Null
    foreach ($item in @("trader", "web", "tests", "scripts", "data", "config.toml", "README.md", "RESEARCH_METHODOLOGY.md", "pyproject.toml", "UPDATE_NOTES.md", "ACTUALIZAR_BOT.cmd", "INSTALAR_CENTRO_CONTROL.cmd", "Crypto AI Trader.vbs", ".env.example", ".gitignore")) {
        $source = Join-Path $ProjectRoot $item
        if (Test-Path $source) {
            Copy-Item -LiteralPath $source -Destination $BackupPath -Recurse -Force
        }
    }
    Write-Host "Respaldo: $BackupPath"

    $ChangesStarted = $true
    foreach ($directory in @("trader", "web", "tests", "scripts")) {
        Copy-DirectoryContents (Join-Path $TempRoot $directory) (Join-Path $ProjectRoot $directory)
    }
    foreach ($file in @("README.md", "RESEARCH_METHODOLOGY.md", "pyproject.toml", "UPDATE_NOTES.md", "ACTUALIZAR_BOT.cmd", "INSTALAR_CENTRO_CONTROL.cmd", "Crypto AI Trader.vbs", ".env.example", ".gitignore")) {
        $source = Join-Path $TempRoot $file
        if (Test-Path $source) {
            Copy-Item -LiteralPath $source -Destination (Join-Path $ProjectRoot $file) -Force
        }
    }

    Write-Host "Ejecutando pruebas..."
    Push-Location $ProjectRoot
    try {
        & py -m unittest discover -s tests -v
        if ($LASTEXITCODE -ne 0) {
            throw "Las pruebas automáticas fallaron."
        }
    }
    finally {
        Pop-Location
    }

    Write-Host "Iniciando el motor actualizado..."
    Start-TradingBot
    $ready = $false
    for ($attempt = 1; $attempt -le 12; $attempt++) {
        Start-Sleep -Seconds 5
        $running = @(
            Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
                Where-Object { $_.CommandLine -like "*-m trader run*" }
        )
        if ($running.Count -eq 0) {
            throw "El proceso actualizado se cerró inesperadamente."
        }
        if (Test-DashboardPort) {
            $ready = $true
            break
        }
    }
    if (-not $ready) {
        throw "El portal no respondió después de 60 segundos."
    }

    Write-Host "" 
    Write-Host "ACTUALIZACION COMPLETADA CORRECTAMENTE" -ForegroundColor Green
    Write-Host "El motor y el portal están funcionando."
    Write-Host "Tus datos, config.toml y .env.local fueron preservados."
}
catch {
    $message = $_.Exception.Message
    Write-Host "" 
    Write-Host "La actualización no pudo completarse: $message" -ForegroundColor Red
    if ($ChangesStarted -and $BackupPath -and (Test-Path $BackupPath)) {
        Write-Host "Restaurando el código anterior..." -ForegroundColor Yellow
        Stop-TradingBot | Out-Null
        Restore-CodeBackup $BackupPath
    }
    if ($BotWasStopped) {
        try {
            Start-TradingBot
            Write-Host "El bot anterior fue reiniciado."
        }
        catch {
            Write-Host "No fue posible reiniciar automáticamente. Usa scripts\start_windows.ps1." -ForegroundColor Red
        }
    }
    if ($BackupPath) {
        Write-Host "Respaldo disponible en: $BackupPath"
    }
    exit 1
}
finally {
    if ($TempRoot -and (Test-Path $TempRoot)) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
