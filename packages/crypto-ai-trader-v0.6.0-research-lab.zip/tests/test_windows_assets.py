import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class WindowsAssetTests(unittest.TestCase):
    def test_windows_scripts_keep_utf8_bom(self):
        for relative in ("scripts/manager_windows.ps1", "scripts/update_windows.ps1"):
            with self.subTest(relative=relative):
                self.assertTrue((PROJECT_ROOT / relative).read_bytes().startswith(b"\xef\xbb\xbf"))

    def test_status_icons_are_valid_ico_files(self):
        for name in (
            "crypto-ai-trader.ico",
            "crypto-ai-trader-warning.ico",
            "crypto-ai-trader-offline.ico",
        ):
            with self.subTest(name=name):
                payload = (PROJECT_ROOT / "web" / name).read_bytes()
                self.assertTrue(payload.startswith(b"\x00\x00\x01\x00"))
                self.assertGreater(len(payload), 1024)

    def test_manager_waits_only_for_the_updater_process(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("$process.WaitForExit()", source)
        self.assertIn("$process.Refresh()", source)
        self.assertIn("ACTUALIZACION COMPLETADA CORRECTAMENTE", source)
        self.assertNotIn("-Wait `", source)

    def test_manager_uses_public_github_update_channel(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        self.assertIn(
            "https://raw.githubusercontent.com/jlboper/Crypto-BOT/main/latest.json",
            source,
        )
        self.assertIn('$UpdateRepositoryPath = "/jlboper/Crypto-BOT/"', source)
        self.assertIn("Install-RemoteUpdate -Update $available", source)
        self.assertIn("Get-FileHash -LiteralPath $packagePath -Algorithm SHA256", source)

    def test_header_logo_is_a_valid_png(self):
        payload = (PROJECT_ROOT / "web" / "crypto-ai-trader-icon.png").read_bytes()
        self.assertTrue(payload.startswith(b"\x89PNG\r\n\x1a\n"))

    def test_portal_includes_installable_research_lab(self):
        html = (PROJECT_ROOT / "web" / "index.html").read_text(encoding="utf-8")
        manifest = (PROJECT_ROOT / "web" / "manifest.webmanifest").read_text(encoding="utf-8")
        script = (PROJECT_ROOT / "web" / "app.js").read_text(encoding="utf-8")
        self.assertIn("RESEARCH LAB · V0.6", html)
        self.assertIn('"display": "standalone"', manifest)
        self.assertIn("/api/research/run", script)
        self.assertIn("serviceWorker", script)

    def test_manager_uses_verified_remote_update_channel(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("https://raw.githubusercontent.com/jlboper/Crypto-BOT/main/latest.json", source)
        self.assertIn("Get-FileHash -LiteralPath $packagePath -Algorithm SHA256", source)
        self.assertIn("$packageUri.Host -ne $manifestUri.Host", source)
        self.assertIn("[TimeSpan]::FromHours(6)", source)
        self.assertIn("Instalar actualización local...", source)

    def test_manager_stays_in_background_until_explicit_exit(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        launcher = (PROJECT_ROOT / "Crypto AI Trader.vbs").read_text(encoding="utf-8-sig")
        self.assertIn("-STA", launcher)
        self.assertIn("[System.Windows.Forms.Application]::Run($form)", source)
        self.assertIn("CloseReason]::UserClosing", source)
        self.assertIn("$eventArgs.Cancel = $true", source)
        self.assertIn("Hide-ManagerWindow", source)
        self.assertIn('$notifyMenu.Items.Add("Salir del indicador")', source)

    def test_windows_uses_branded_icons_and_persistent_startup(self):
        source = (PROJECT_ROOT / "scripts" / "manager_windows.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("SetCurrentProcessExplicitAppUserModelID", source)
        self.assertIn('$form.Icon = $script:FormIcon', source)
        self.assertIn('$notifyIcon.Icon = $script:OperationalIcon', source)
        self.assertIn('$shortcut.IconLocation = $OperationalIconPath + ",0"', source)
        self.assertIn("DISABLE_AUTO_START", source)


if __name__ == "__main__":
    unittest.main()
